import random

class FetishSystem:
    def __init__(self):
        self.fetishes = {}

    def assign_fetishes(self, npc_id):
        self.fetishes[npc_id] = {
            "foot": round(random.uniform(0.0, 1.0), 2),
            "bondage": round(random.uniform(0.0, 1.0), 2),
            "roleplay": round(random.uniform(0.0, 1.0), 2),
            "rituals": round(random.uniform(0.0, 1.0), 2),
        }

    def get_fetishes(self, npc_id):
        return self.fetishes.get(npc_id, {})

    def train_fetish(self, npc_id, fetish_type):
        npc_fetishes = self.fetishes.setdefault(npc_id, {})
        level = npc_fetishes.get(fetish_type, 0.0)
        increase = round(random.uniform(0.01, 0.05), 2)
        npc_fetishes[fetish_type] = min(1.0, level + increase)

    def is_fetish_triggered(self, npc_id, fetish_type):
        threshold = self.fetishes.get(npc_id, {}).get(fetish_type, 0.0)
        return random.random() < threshold