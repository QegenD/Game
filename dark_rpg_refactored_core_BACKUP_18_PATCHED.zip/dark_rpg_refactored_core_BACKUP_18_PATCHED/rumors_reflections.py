# Слухи и отражения NPC

class RumorSystem:
    pass
