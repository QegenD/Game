
# holy_magic.py — святая магия, очищение, защита от демонов

class HolyMagic:
    def __init__(self):
        self.spells = {
            "Banish Evil": "Exiles demonic entities",
            "Bless": "Heals and boosts morale",
            "Truthfire": "Reveals lies and hidden cultist marks",
            "Ward of Light": "Protects from mental corruption"
        }

    def cast(self, spell_name, target):
        effect = self.spells.get(spell_name, "Unknown effect")
        print(f"Holy spell '{spell_name}' cast on {target.name}: {effect}")
        target.status_effects.append(spell_name)
