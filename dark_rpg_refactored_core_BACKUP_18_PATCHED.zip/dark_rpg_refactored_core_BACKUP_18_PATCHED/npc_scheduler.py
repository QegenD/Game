# Планирование действий NPC
class NPCSchedule:
    def __init__(self, npc):
        self.npc = npc
        self.plan = []
