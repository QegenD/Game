
# saint_status.py — становление NPC и игроков святыми, мучениками, пророками

class SaintStatus:
    def __init__(self, npc):
        self.npc = npc
        self.title = None
        self.honors = []

    def ascend(self, title="saint"):
        self.title = title
        self.npc.tags.add("holy")
        self.npc.status_effects.append("revered")
        self.npc.journal.append(f"Was granted the title: {title}")
        return f"{self.npc.name} was declared {title}!"

    def add_honor(self, honor):
        self.honors.append(honor)
        self.npc.journal.append(f"Received holy honor: {honor}")
