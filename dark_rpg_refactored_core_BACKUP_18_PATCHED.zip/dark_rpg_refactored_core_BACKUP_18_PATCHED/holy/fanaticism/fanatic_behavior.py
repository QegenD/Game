
# fanatic_behavior.py — NPC с религиозным фанатизмом

from random import randint

class ReligiousFanatic:
    def __init__(self, npc):
        self.npc = npc
        self.aggression_threshold = 7

    def update_behavior(self, nearby_npcs):
        self.npc.mood = "zealous"
        for other in nearby_npcs:
            if "cultist" in other.tags or "tainted" in other.status_effects:
                if randint(0, 10) > self.aggression_threshold:
                    self.npc.attack(other)
                    self.npc.journal.append(f"Attacked {other.name} for heresy.")
