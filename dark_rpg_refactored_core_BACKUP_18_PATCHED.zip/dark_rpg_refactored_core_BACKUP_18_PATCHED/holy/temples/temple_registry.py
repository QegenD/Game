
# temple_registry.py — регистрация храмов, святых мест и их влияния

class Temple:
    def __init__(self, name, location, patron_saint=None):
        self.name = name
        self.location = location
        self.patron_saint = patron_saint
        self.blessings = []

    def bless(self, npc):
        if self.patron_saint:
            npc.reputation[self.patron_saint] = npc.reputation.get(self.patron_saint, 0) + 10
        npc.status_effects.append("blessed")
        npc.journal.append(f"Received blessing at {self.name}")
