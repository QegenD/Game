
# inquisition_trial.py — Инквизиционные суды NPC и игрока

from random import choice, randint

class InquisitionTrial:
    def __init__(self, target):
        self.target = target
        self.verdict = None

    def conduct_trial(self):
        evidence = randint(0, 10)
        defense = self.target.stats.get('charisma', 5)
        roll = defense + randint(-3, 3)

        if evidence > roll:
            self.verdict = choice(["burned", "imprisoned", "banished"])
            self.target.journal.append(f"Tried by Inquisition and {self.verdict}")
            self.target.status_effects.append("trauma")
        else:
            self.verdict = "absolved"
            self.target.journal.append("Tried by Inquisition and absolved")
            self.target.reputation["Holy Order"] += 5
