
# prophet_engine.py — NPC становятся пророками и видят сны

from random import choice, randint

class Prophet:
    def __init__(self, npc):
        self.npc = npc
        self.prophecies = []

    def receive_vision(self):
        vision = choice([
            "The sun shall turn black, and blood shall flood the fields.",
            "A child of shadow and light shall decide the fate of kings.",
            "The holy ground shall tremble under the heretic's feet.",
            "Flames shall purge the impure — one town shall burn."
        ])
        self.prophecies.append(vision)
        self.npc.journal.append(f"Received vision: '{vision}'")
        self.npc.tags.append("prophet")
        self.npc.mood = "troubled"
