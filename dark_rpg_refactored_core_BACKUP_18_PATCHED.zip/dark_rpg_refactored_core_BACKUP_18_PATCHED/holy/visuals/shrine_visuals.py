
# shrine_visuals.py — визуализация святых мест и паломничеств

def generate_shrine_image(site, npc=None):
    prompt = f"holy shrine named {site.name}, glowing, divine aura, ancient architecture, sacred atmosphere"
    if site.is_corrupted:
        prompt += ", corrupted, dark mist, decayed symbols, eerie"
    if npc:
        prompt += f", visited by {npc.race} pilgrim in humble clothes"

    return {
        "prompt": prompt,
        "context": "holy_site",
        "filename": f"shrine_{site.name.replace(' ', '_')}.png"
    }
