
# holy_event_engine.py — праздники, небесные явления, святой календарь

from random import choice

class HolyDay:
    def __init__(self):
        self.name = choice([
            "Day of Flame", "Feast of Mercy", "Night of Silence",
            "Moon of Ascension", "Festival of Saints"
        ])
        self.effect = choice([
            "bless all temples", "cause visions", "attract pilgrims",
            "spawn relic traders", "weaken demonic cults"
        ])

    def trigger(self, world):
        world.log.append(f"Holy Day triggered: {self.name} — {self.effect}")
        return f"{self.name} celebrated: {self.effect}"
