
# vision_engine.py — видения, сны, откровения для NPC и игрока

from random import choice

class Vision:
    def __init__(self, recipient):
        self.recipient = recipient
        self.content = choice([
            "A child of ash will bring light in darkness.",
            "A crimson moon bleeds over the holy city.",
            "The dead whisper truths beneath the altar.",
            "Your hand shall bear both salvation and doom.",
            "Follow the silent star — it knows the path."
        ])

    def deliver(self):
        self.recipient.journal.append(f"Vision: {self.content}")
        return f"{self.recipient.name} received a divine vision: {self.content}"
