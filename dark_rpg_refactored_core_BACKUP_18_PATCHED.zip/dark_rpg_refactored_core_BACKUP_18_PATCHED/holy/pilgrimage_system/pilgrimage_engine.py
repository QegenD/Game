
# pilgrimage_engine.py — NPC и игроки совершают паломничество

from random import choice
from holy.holy_sites.holy_sites import HOLY_SITES

class Pilgrimage:
    def __init__(self, npc):
        self.npc = npc
        self.target_site = choice(HOLY_SITES)

    def begin(self):
        self.npc.move_to(self.target_site.location_name)
        self.npc.mood = "devout"

    def arrive(self):
        self.target_site.bless(self.npc)
        self.npc.journal.append(f"Pilgrimage to {self.target_site.name} completed.")
