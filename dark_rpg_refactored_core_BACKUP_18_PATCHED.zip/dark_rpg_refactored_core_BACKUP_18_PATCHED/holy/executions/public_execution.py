
# public_execution.py — Публичные казни в городах

from random import choice

class ExecutionEvent:
    def __init__(self, npc, reason="heresy"):
        self.npc = npc
        self.reason = reason
        self.method = choice(["burning", "hanging", "beheading", "stoning"])

    def execute(self):
        self.npc.is_alive = False
        self.npc.journal.append(f"Executed by {self.method} for {self.reason}")
        self.npc.status_effects.append("dead")
        return f"{self.npc.name} was {self.method} for {self.reason}"
