import tkinter as tk
from tkinter import ttk, messagebox
import json
import requests
from config import llm_endpoint

ATTRIBUTE_POINTS = 10

class CharacterCreatorApp:
    def __init__(self, master):
        self.master = master
        master.title("Создание персонажа")
        master.geometry("500x600")

        self.points_left = ATTRIBUTE_POINTS
        self.attributes = {"Сила": 0, "Интеллект": 0, "Харизма": 0, "Магия": 0}

        # Имя
        ttk.Label(master, text="Имя:").pack()
        self.name_entry = ttk.Entry(master)
        self.name_entry.pack()

        # Пол
        ttk.Label(master, text="Пол:").pack()
        self.gender_var = tk.StringVar()
        ttk.Combobox(master, textvariable=self.gender_var, values=["Мужской", "Женский"]).pack()

        # Класс
        ttk.Label(master, text="Происхождение:").pack()
        self.origin_var = tk.StringVar()
        self.origin_box = ttk.Combobox(master, textvariable=self.origin_var,
                                       values=["Крестьянин", "Шпион", "Изгнанный маг", "Аристократ", "Разбойник"])
        self.origin_box.pack()

        # Фракция
        ttk.Label(master, text="Фракция:").pack()
        self.faction_var = tk.StringVar()
        self.faction_box = ttk.Combobox(master, textvariable=self.faction_var,
                                        values=["Совет магов", "Повстанцы", "Одинокий отшельник", "Империя"])
        self.faction_box.pack()

        # Характеристики
        ttk.Label(master, text=f"Очки характеристик (осталось: {self.points_left}):").pack()
        self.attr_labels = {}
        self.attr_vars = {}

        for attr in self.attributes:
            frame = ttk.Frame(master)
            frame.pack()
            label = ttk.Label(frame, text=f"{attr}: 0")
            label.pack(side="left")
            self.attr_labels[attr] = label
            self.attr_vars[attr] = 0
            plus_btn = ttk.Button(frame, text="+", command=lambda a=attr: self.modify_attr(a, 1))
            plus_btn.pack(side="left")
            minus_btn = ttk.Button(frame, text="-", command=lambda a=attr: self.modify_attr(a, -1))
            minus_btn.pack(side="left")

        # Кнопка создания
        ttk.Button(master, text="Создать персонажа", command=self.finalize).pack(pady=10)

    def modify_attr(self, attr, delta):
        if delta == 1 and self.points_left > 0:
            self.attr_vars[attr] += 1
            self.points_left -= 1
        elif delta == -1 and self.attr_vars[attr] > 0:
            self.attr_vars[attr] -= 1
            self.points_left += 1
        self.attr_labels[attr].config(text=f"{attr}: {self.attr_vars[attr]}")
        self.update_attr_label()

    def update_attr_label(self):
        label = [w for w in self.master.pack_slaves() if isinstance(w, ttk.Label)][4]
        label.config(text=f"Очки характеристик (осталось: {self.points_left}):")

    def finalize(self):
        name = self.name_entry.get()
        gender = self.gender_var.get()
        origin = self.origin_var.get()
        faction = self.faction_var.get()
        if not name or not gender or not origin or not faction:
            messagebox.showerror("Ошибка", "Заполни все поля.")
            return

        attributes = {k.lower(): v for k, v in self.attr_vars.items()}
        bio = self.generate_biography(name, origin, faction)

        player_data = {
            "name": name,
            "gender": gender,
            "origin": origin,
            "faction": faction,
            "attributes": attributes,
            "bio": bio
        }

        with open("player_data.json", "w", encoding="utf-8") as f:
            json.dump(player_data, f, ensure_ascii=False, indent=2)

        messagebox.showinfo("Успех", f"Персонаж создан!\n\n{bio}")
        self.master.destroy()

    def generate_biography(self, name, origin, faction):
        prompt = f"Придумай краткую биографию персонажа по имени {name}, " \
                 f"который по происхождению {origin} и связан с фракцией '{faction}'."
        try:
            res = requests.post(llm_endpoint, json={"prompt": prompt, "stream": False})
            return res.json().get("response", "").strip()
        except Exception as e:
            return "Не удалось сгенерировать биографию."

def run_gui():
    root = tk.Tk()
    app = CharacterCreatorApp(root)
    root.mainloop()

def open_image_viewer(title, image_dir):
    viewer = Toplevel()
    viewer.title(title)

    canvas = Canvas(viewer)
    scrollbar = Scrollbar(viewer, orient="vertical", command=canvas.yview)
    scrollable_frame = Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    from PIL import Image, ImageTk
    import os

    for filename in os.listdir(image_dir):
        if filename.endswith(".png"):
            path = os.path.join(image_dir, filename)
            img = Image.open(path).resize((128, 192))
            img_tk = ImageTk.PhotoImage(img)
            label = Label(scrollable_frame, image=img_tk, text=filename, compound="top")
            label.image = img_tk
            label.pack(padx=5, pady=5)