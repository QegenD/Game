
# combat_engine.py — базовая система боя

import random

class CombatEngine:
    def __init__(self, attacker, defender):
        self.attacker = attacker
        self.defender = defender

    def roll_hit(self, attacker):
        return random.randint(1, 20) + attacker.dexterity

    def roll_damage(self, attacker):
        return random.randint(1, attacker.strength)

    def perform_turn(self):
        if self.roll_hit(self.attacker) > self.defender.dexterity + 5:
            dmg = self.roll_damage(self.attacker)
            self.defender.hp -= dmg
            print(f"{self.attacker.name} hits {self.defender.name} for {dmg} damage!")
        else:
            print(f"{self.attacker.name} misses.")

        # Проверка смерти
        if self.defender.hp <= 0:
            self.defender.status = "dead"
            print(f"{self.defender.name} has died.")
            return True  # combat over
        return False  # continue
