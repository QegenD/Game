import logging

logger = logging.getLogger(__name__)

def show_internal_data(world_state):
    if not getattr(world_state, "debug", False):
        return ""

    try:
        npc_count = len(getattr(world_state, "npcs", []))
        secret_count = len(getattr(world_state, "secrets", []))

        debug_info = (
            f"🛠 DEBUG INFO:\n"
            f"👤 NPCs: {npc_count}\n"
            f"📜 Secrets: {secret_count}"
        )

        logger.debug("Developer panel data prepared successfully.")
        return debug_info

    except Exception as e:
        logger.exception("Failed to generate developer panel debug info.")
        return "⚠️ Error in developer panel."
