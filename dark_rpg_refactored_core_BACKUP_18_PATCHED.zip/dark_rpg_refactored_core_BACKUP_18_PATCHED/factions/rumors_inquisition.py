
# rumors_inquisition.py — Инквизиция узнаёт о культах через слухи и доносы

def process_rumors_and_reports(world_state, npcs, player):
    for npc in npcs:
        if npc.faction == "cult" and "rumors" in npc.traits:
            if npc.traits["rumors"] > 3:
                npc.exposed = True

    if player.faction == "cult" and player.traits.get("rumors", 0) > 5:
        player.exposed = True
