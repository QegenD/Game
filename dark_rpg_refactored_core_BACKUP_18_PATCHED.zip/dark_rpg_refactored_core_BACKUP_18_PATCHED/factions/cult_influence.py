
# cult_influence.py — влияние культов на NPC и города

import random

def update_cult_influence(world_state, npcs, cults):
    cult_spread_chance = 0.2

    for cult in cults:
        if random.random() < cult_spread_chance:
            candidate_npcs = [npc for npc in npcs if cult['region'] == npc.get('region') and not npc.get('cult_member')]
            if candidate_npcs:
                chosen = random.choice(candidate_npcs)
                chosen['cult_member'] = True
                chosen['cult_id'] = cult['id']
                cult['members'].append(chosen['id'])

    # Влияние на города
    for region in world_state.get("regions", []):
        influence = sum(1 for npc in npcs if npc.get('region') == region and npc.get('cult_member'))
        if influence > 3:
            world_state.setdefault('cult_control', {})[region] = "опасно заражён"
        elif influence > 1:
            world_state.setdefault('cult_control', {})[region] = "под подозрением"
        else:
            world_state.setdefault('cult_control', {})[region] = "чист"
