
# double_agent.py — двойной агент: игрок внутри культа, но информатор Инквизиции

def update_double_agent_status(player, world_state):
    if player.faction == "cult" and player.traits.get("informant"):
        world_state.setdefault("double_agents", []).append(player.name)
        player.reputation["inquisition"] = 10
        player.reputation["cultists"] -= 5
        return True
    return False
