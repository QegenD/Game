
# cult_generator.py — генерация культов ИИ на основе состояния мира

import random
import uuid

CULT_THEMES = [
    "эротическое слияние", "пожирание памяти", "огненное очищение",
    "священное подчинение", "восхождение плоти", "воссоединение душ", "забвение через боль"
]

SYMBOL_PARTS = ["глаз", "череп", "сердце", "алтарь", "маска", "верёвка", "пламя", "нож"]
GOALS = ["разрушить мораль", "воскрешение древнего", "слияние с богами", "получить бессмертие", "уничтожить свет"]

def generate_cult(region_id):
    theme = random.choice(CULT_THEMES)
    name = f"Культ {theme.title()}"
    symbol = f"{random.choice(SYMBOL_PARTS)} в {random.choice(SYMBOL_PARTS)}"
    goal = random.choice(GOALS)
    secrecy = random.choice(["открытый", "скрытый", "глубоко подпольный"])
    rituals = [f"{theme.title()} #{i}" for i in range(1, random.randint(2, 4))]

    return {
        "id": str(uuid.uuid4()),
        "region": region_id,
        "name": name,
        "symbol": symbol,
        "theme": theme,
        "goal": goal,
        "secrecy": secrecy,
        "rituals": rituals,
        "members": [],
        "created_by_ai": True
    }
