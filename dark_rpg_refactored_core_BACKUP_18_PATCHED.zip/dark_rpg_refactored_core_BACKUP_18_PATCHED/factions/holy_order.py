
# holy_order.py — Светлый Орден и его влияние

class HolyOrder:
    def __init__(self):
        self.name = "Ordo Lux"
        self.reputation = {}
        self.active_miracles = []

    def bless_npc(self, npc):
        npc.status_effects.append("blessed")
        npc.mood = "inspired"
        npc.health = min(npc.health + 20, 100)

    def heal_npc(self, npc):
        npc.status_effects.append("healed")
        npc.health = 100

    def perform_miracle(self, location):
        miracle = {
            "location": location.name,
            "effect": "disease_purged",
            "timestamp": location.world_time
        }
        location.status_effects.append("miracle_happened")
        self.active_miracles.append(miracle)

    def take_oath(self, npc, oath_type):
        npc.traits["oath"] = oath_type
        npc.mood = "pious"
