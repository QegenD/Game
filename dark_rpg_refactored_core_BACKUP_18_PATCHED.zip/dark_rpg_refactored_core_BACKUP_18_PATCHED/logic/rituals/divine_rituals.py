
# divine_rituals.py — проведение ритуалов, жертвоприношения, влияние на мир

import random

RITUAL_TYPES = [
    "кровавое жертвоприношение", 
    "огненное очищение", 
    "песнопение на заре", 
    "жертвенная охота", 
    "ритуал плоти"
]

def perform_ritual(god, fanatic_level):
    ritual = random.choice(RITUAL_TYPES)
    intensity = "экстатический" if fanatic_level > 0.8 else "сдержанный"
    description = f"{intensity.capitalize()} ритуал «{ritual}» во славу {god['name']}."
    effect = determine_effect(ritual, fanatic_level)
    return {
        "description": description,
        "effect": effect
    }

def determine_effect(ritual, fanatic_level):
    if "жертва" in ritual or "кровь" in ritual or "плоть" in ritual:
        corruption_gain = round(fanatic_level * 10)
        return f"Мир ощущает вибрации тьмы. +{corruption_gain} к Порче."
    elif "очищение" in ritual:
        return "Районы очищены от скверны. Минус 1 уровень Порчи."
    else:
        return "Вера укрепляется. Лояльность верующих усилилась."
