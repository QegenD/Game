
# conflict_engine.py — фанатизм, конфликты религий и священные войны

import random

class ReligiousFaction:
    def __init__(self, religion):
        self.religion = religion
        self.name = religion['name']
        self.tenets = religion['tenets']
        self.fanaticism = random.uniform(0.3, 1.0)  # от умеренных до радикалов
        self.in_conflict_with = []

    def evaluate_conflict(self, other_faction):
        shared = set(self.tenets) & set(other_faction.tenets)
        ideological_distance = 1.0 - len(shared) / max(len(self.tenets), 1)
        hostility = ideological_distance * self.fanaticism * other_faction.fanaticism

        if hostility > 0.6:
            self.in_conflict_with.append(other_faction.name)
            return True
        return False

    def is_fanatic(self):
        return self.fanaticism > 0.75

def generate_factions_from_religions(religions):
    return [ReligiousFaction(r) for r in religions]

def find_religious_conflicts(factions):
    conflicts = []
    for i, f1 in enumerate(factions):
        for f2 in factions[i+1:]:
            if f1.evaluate_conflict(f2):
                conflicts.append((f1.name, f2.name))
    return conflicts
