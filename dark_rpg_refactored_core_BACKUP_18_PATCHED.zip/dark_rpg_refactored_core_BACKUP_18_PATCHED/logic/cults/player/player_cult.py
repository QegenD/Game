
# player_cult.py — создание и развитие собственного культа игрока

class PlayerCult:
    def __init__(self, founder_name):
        self.name = f"Культ {founder_name}"
        self.symbol = "🔺"
        self.doctrine = []
        self.followers = []
        self.sanctuaries = []

    def add_doctrine(self, tenet):
        self.doctrine.append(tenet)

    def recruit_follower(self, npc):
        self.followers.append(npc)

    def build_sanctuary(self, location):
        self.sanctuaries.append(location)

    def summary(self):
        return {
            "name": self.name,
            "followers": [f.name for f in self.followers],
            "doctrine": self.doctrine,
            "sanctuaries": self.sanctuaries
        }
