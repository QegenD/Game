
# cult_leader.py — игрок или NPC становится лидером культа

class CultLeader:
    def __init__(self, character, cult_name):
        self.character = character
        self.cult_name = cult_name
        self.followers = []

    def recruit_follower(self, npc):
        self.followers.append(npc)
        npc.set_loyalty(self.character)
        npc.traits.add("поклонник " + self.cult_name)

    def give_order(self, npc, order):
        if npc in self.followers:
            npc.execute_order(order)
