
# temple_manager.py — генерация храмов культов

class TempleManager:
    def __init__(self, world):
        self.world = world
        self.temples = []

    def build_temple(self, region, cult_name, effect):
        temple = {
            "region": region,
            "cult": cult_name,
            "effect": effect
        }
        self.temples.append(temple)
        self.world.log_event(f"🏛️ Храм культа '{cult_name}' построен в {region} с эффектом: {effect}")
        region.add_temple(cult_name, effect)
