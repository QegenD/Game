
# inquisition_hunt.py — охота инквизиции на ритуалистов и храмы

class InquisitionHunt:
    def __init__(self, world):
        self.world = world

    def investigate(self, region):
        if region.has_cult_activity():
            suspects = region.get_suspected_cultists()
            for npc in suspects:
                if npc.reputation.get("ересь", 0) > 5:
                    self.world.log_event(f"🕵️ Инквизиция задержала {npc.name} по подозрению в ереси в регионе {region.name}")
                    npc.arrest()
                    region.reduce_cult_influence()
