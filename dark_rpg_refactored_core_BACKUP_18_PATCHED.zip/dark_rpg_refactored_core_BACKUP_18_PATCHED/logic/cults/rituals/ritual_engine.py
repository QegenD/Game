
# ritual_engine.py — ритуалы культов с последствиями

import random

class RitualEngine:
    def __init__(self, world):
        self.world = world

    def perform_ritual(self, cult_name, domain, region):
        effects = {
            "blood": ["сумасшествие", "резня", "усиление тел"],
            "lust": ["соблазнение NPC", "эротическое влияние", "разврат"],
            "death": ["призыв теней", "болезни", "некромантия"],
            "light": ["просветление", "исцеление", "отпущение"]
        }
        outcome = random.choice(effects.get(domain, ["ничего не произошло"]))
        self.world.log_event(f"🔮 Культ {cult_name} провёл ритуал в {region}: {outcome}")
        self._apply_consequences(region, outcome)

    def _apply_consequences(self, region, effect):
        # Упрощённая модель последствий
        region.effects.append(effect)
