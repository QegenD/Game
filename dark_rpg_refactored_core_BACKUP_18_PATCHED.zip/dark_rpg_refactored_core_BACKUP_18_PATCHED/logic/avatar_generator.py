
# --- Генерация аватаров NPC (псевдо) ---

import random

def generate_avatar_data(npc):
    # Простейшее определение внешности
    base_faces = ["round", "oval", "square", "heart", "long"]
    eyes = ["green", "blue", "brown", "hazel", "grey"]
    hair = ["blonde", "brown", "black", "red", "white"]
    skin = ["pale", "tan", "dark", "olive"]

    return {
        "face_shape": random.choice(base_faces),
        "eye_color": random.choice(eyes),
        "hair_color": random.choice(hair),
        "skin_tone": random.choice(skin),
        "npc_id": npc.get("id"),
        "tags": npc.get("tags", []),
        "style": npc.get("style", "common")
    }

def save_avatar_data(npc, path="data/avatar_data.json"):
    import json
    data = generate_avatar_data(npc)
    try:
        with open(path, "r", encoding="utf-8") as f:
            existing = json.load(f)
    except Exception:
        existing = []

    existing.append(data)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2)
