
# logic/emotion_memory.py

class EmotionMemory:
    def __init__(self):
        self.memory = {}

    def record(self, player_action, impact):
        self.memory[player_action] = self.memory.get(player_action, 0) + impact

    def recall(self):
        return sorted(self.memory.items(), key=lambda x: -abs(x[1]))

    def get_attitude(self):
        score = sum(self.memory.values())
        if score > 10:
            return "доверие"
        elif score < -10:
            return "враждебность"
        else:
            return "нейтральность"


# --- Расширения эмоций и влечений ---

class EmotionProfile:
    def __init__(self):
        self.emotions = {}  # {target_name: {"fear": 0, "desire": 0, "anger": 0, ...}}

    def set_emotion(self, target, emotion, value):
        if target not in self.emotions:
            self.emotions[target] = {}
        self.emotions[target][emotion] = value

    def get_emotion(self, target, emotion):
        return self.emotions.get(target, {}).get(emotion, 0)

    def modify_emotion(self, target, emotion, delta):
        current = self.get_emotion(target, emotion)
        self.set_emotion(target, emotion, current + delta)

    def describe_emotions(self, target):
        return self.emotions.get(target, {})

    def top_targets_by_emotion(self, emotion, top_n=3):
        ranked = sorted([(t, e.get(emotion, 0)) for t, e in self.emotions.items()], key=lambda x: -x[1])
        return ranked[:top_n]
