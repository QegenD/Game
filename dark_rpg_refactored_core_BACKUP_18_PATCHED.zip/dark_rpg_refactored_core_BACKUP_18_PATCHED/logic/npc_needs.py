
# --- Система потребностей и эмоций NPC ---

import random

class NPCNeeds:
    def __init__(self):
        self.hunger = 0
        self.thirst = 0
        self.fatigue = 0

        self.fear = 0
        self.anger = 0
        self.arousal = 0
        self.happiness = 50
        self.boredom = 0

    def tick(self):
        # Увеличиваем базовые потребности
        self.hunger += random.randint(1, 3)
        self.thirst += random.randint(1, 2)
        self.fatigue += random.randint(0, 2)

        # Актуализируем эмоции
        self.boredom += 1
        self.happiness -= 0.5
        self.arousal += random.randint(0, 2)

        # Ограничения
        self._clamp_all()

    def _clamp_all(self):
        for attr in ["hunger", "thirst", "fatigue", "fear", "anger", "arousal", "happiness", "boredom"]:
            value = getattr(self, attr)
            setattr(self, attr, max(0, min(100, value)))

    def mood(self):
        if self.fear > 60:
            return "scared"
        elif self.anger > 60:
            return "angry"
        elif self.arousal > 70:
            return "horny"
        elif self.happiness > 70:
            return "happy"
        elif self.boredom > 70:
            return "bored"
        else:
            return "neutral"

    def is_urgent(self):
        return self.hunger > 80 or self.thirst > 80 or self.fatigue > 80
