
# --- Система маскировки и обмана ---

class Disguise:
    def __init__(self, real_name, fake_name, appearance_override=None, role=None):
        self.real_name = real_name
        self.fake_name = fake_name
        self.appearance_override = appearance_override
        self.role = role
        self.active = True

    def deactivate(self):
        self.active = False

    def get_visible_identity(self):
        return self.fake_name if self.active else self.real_name

    def __repr__(self):
        status = "ACTIVE" if self.active else "INACTIVE"
        return f"Disguise({self.real_name} -> {self.fake_name}) [{status}]"
