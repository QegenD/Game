
# --- Глубокие тайны и скрытые личности ---

import random
import json
from datetime import datetime

SECRETS_PATH = "data/deep_secrets.json"

class DeepSecret:
    TYPES = [
        "Тайный культ", "Двойной агент", "Запретная техника",
        "Бессмертный", "Похищение королевской крови", "Древний демон внутри"
    ]

    def __init__(self, npc_id):
        self.npc_id = npc_id
        self.secret_type = random.choice(self.TYPES)
        self.risk_level = random.randint(1, 5)
        self.is_revealed = False
        self.added = datetime.utcnow().isoformat()

    def to_dict(self):
        return {
            "npc_id": self.npc_id,
            "secret_type": self.secret_type,
            "risk_level": self.risk_level,
            "revealed": self.is_revealed,
            "time_added": self.added
        }

def assign_secret(npc_id):
    secret = DeepSecret(npc_id)
    try:
        with open(SECRETS_PATH, "r", encoding="utf-8") as f:
            existing = json.load(f)
    except:
        existing = []

    existing.append(secret.to_dict())
    with open(SECRETS_PATH, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2)

    return secret
