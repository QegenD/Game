
# logic/clan_influence.py

import random

class ClanReputation:
    def __init__(self):
        self.reputation = {}  # {имя_клана: -100 до +100}

    def initialize_for_clans(self, clans):
        for clan in clans:
            self.reputation[clan.name] = random.randint(-20, 20)

    def adjust(self, clan_name, amount):
        if clan_name in self.reputation:
            self.reputation[clan_name] = max(-100, min(100, self.reputation[clan_name] + amount))

    def get(self, clan_name):
        return self.reputation.get(clan_name, 0)

    def get_all(self):
        return self.reputation


# --- Влияние кланов и влияние во времени ---

class ClanInfluence:
    def __init__(self, clan_name):
        self.clan_name = clan_name
        self.reputation = 50
        self.influence_map = {}

    def change_reputation(self, delta):
        self.reputation = max(0, min(100, self.reputation + delta))

    def adjust_influence(self, region, delta):
        self.influence_map[region] = self.influence_map.get(region, 0) + delta

    def get_influence(self, region):
        return self.influence_map.get(region, 0)

    def __repr__(self):
        return f"{self.clan_name}: reputation={self.reputation}, influence={self.influence_map}"
