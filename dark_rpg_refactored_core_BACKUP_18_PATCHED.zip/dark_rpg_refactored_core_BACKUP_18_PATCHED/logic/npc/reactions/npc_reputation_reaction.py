
# npc_reputation_reaction.py — NPC реагируют на боевую репутацию

def react_to_combat_reputation(npc, target):
    if not hasattr(target, 'reputation'):
        return

    rep = target.reputation.get("combat", 0)
    if rep > 50:
        npc.set_attitude("fear")
        npc.avoid(target)
    elif rep < -30:
        npc.set_attitude("disgust")
        npc.confront(target)
    elif rep > 20:
        npc.set_attitude("respect")
        npc.observe(target)
