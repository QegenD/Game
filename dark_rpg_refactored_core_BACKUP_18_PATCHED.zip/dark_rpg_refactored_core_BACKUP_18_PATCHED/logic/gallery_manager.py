
# --- Управление галереей сцен и изображений ---

import os
import json
from datetime import datetime

GALLERY_PATH = "data/gallery.json"

def save_gallery_entry(npc_ids, scene_type, tags=None, image_path=None):
    entry = {
        "time": datetime.utcnow().isoformat(),
        "npc_ids": npc_ids,
        "scene_type": scene_type,
        "tags": tags or [],
        "image_path": image_path
    }
    try:
        with open(GALLERY_PATH, "r", encoding="utf-8") as f:
            gallery = json.load(f)
    except Exception:
        gallery = []

    gallery.append(entry)
    with open(GALLERY_PATH, "w", encoding="utf-8") as f:
        json.dump(gallery, f, indent=2)
