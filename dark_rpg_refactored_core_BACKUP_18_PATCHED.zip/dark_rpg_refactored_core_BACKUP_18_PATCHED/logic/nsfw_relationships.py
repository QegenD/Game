
# --- Система NSFW-отношений и доверия ---

class AffinityLevel:
    levels = ["Neutral", "Acquaintance", "Friend", "Lust", "Love", "Fanatic"]

    def __init__(self, level="Neutral"):
        self.index = self.levels.index(level)

    def increase(self):
        if self.index < len(self.levels) - 1:
            self.index += 1

    def decrease(self):
        if self.index > 0:
            self.index -= 1

    def current(self):
        return self.levels[self.index]

class TrustMeter:
    def __init__(self, value=0):
        self.value = value

    def add(self, amount):
        self.value = min(100, self.value + amount)

    def reduce(self, amount):
        self.value = max(0, self.value - amount)

    def level(self):
        if self.value >= 80:
            return "Deep Trust"
        elif self.value >= 50:
            return "Moderate Trust"
        elif self.value >= 20:
            return "Weak Trust"
        else:
            return "No Trust"

class NSFWRelationship:
    def __init__(self, npc_id):
        self.npc_id = npc_id
        self.affinity = AffinityLevel()
        self.trust = TrustMeter()
        self.shared_experience = 0
        self.flirt_count = 0
        self.flags = {
            "virgin": False,
            "romantic": True,
            "jealous": False,
            "dominant": False,
            "submissive": False
        }

    def flirt(self):
        self.trust.add(5)
        self.flirt_count += 1
        if self.flirt_count >= 3:
            self.affinity.increase()

    def share_experience(self):
        self.shared_experience += 1
        self.trust.add(10)

    def allow_nsfw_level(self):
        if self.trust.value >= 80 and self.affinity.current() in ["Lust", "Love", "Fanatic"]:
            return "Full Scene"
        elif self.trust.value >= 50:
            return "Mild Scene"
        else:
            return "Refusal"
