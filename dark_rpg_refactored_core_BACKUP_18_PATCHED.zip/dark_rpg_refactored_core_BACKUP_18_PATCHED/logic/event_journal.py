
# logic/event_journal.py

class EventJournal:
    def __init__(self):
        self.entries = []

    def log(self, entry):
        self.entries.append(entry)

    def get_log(self, limit=10):
        return self.entries[-limit:]


import json
from datetime import datetime

LOG_FILE = "world_log.json"

def log_event(description, involved_npcs=None, factions=None, event_type="general"):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "description": description,
        "npcs": involved_npcs or [],
        "factions": factions or [],
        "type": event_type
    }
    try:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            log_data = json.load(f)
    except FileNotFoundError:
        log_data = []

    log_data.append(entry)

    # Ограничим лог до последних 500 событий
    log_data = log_data[-500:]

    with open(LOG_FILE, "w", encoding="utf-8") as f:
        json.dump(log_data, f, indent=2, ensure_ascii=False)

def get_recent_events(limit=20):
    try:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            log_data = json.load(f)
        return log_data[-limit:]
    except FileNotFoundError:
        return []
