
# injury_system.py — боевые травмы и последствия

from random import choice, randint

class InjurySystem:
    def __init__(self, character):
        self.character = character
        self.injuries = []

    def apply_damage(self, severity):
        effects = {
            'light': ["царапина", "ушиб", "синяк"],
            'medium': ["порез", "перелом", "рана"],
            'heavy': ["ампутация", "пролом черепа", "внутреннее кровотечение"]
        }
        injury = choice(effects[severity])
        self.injuries.append(injury)
        self.character.stats["health"] -= randint(5, 30)
        self.character.update_status()
        return injury

    def describe_injuries(self):
        if not self.injuries:
            return "Персонаж не имеет видимых ран."
        return f"Травмы: {', '.join(self.injuries)}"
