
# vision_generator.py — галлюцинации, фантомные голоса, откровения и искажение реальности

import random

VISION_TYPES = [
    "огненное око на небе",
    "шепоты в крови",
    "вспышка прошлого века",
    "искажённое лицо бога",
    "сияющий череп",
    "откровение о конце света"
]

def generate_vision(npc):
    intensity = random.uniform(0.3, 1.0)
    vision = random.choice(VISION_TYPES)
    return {
        "npc": npc.name,
        "type": vision,
        "intensity": intensity,
        "text": interpret_vision(vision, intensity)
    }

def interpret_vision(vision, intensity):
    if intensity > 0.8:
        return f"⚠️ Явление: {vision.upper()}! Мир содрогается от безумия."
    elif intensity > 0.5:
        return f"Предвестие тревожит разум: {vision}"
    else:
        return f"Слабая вспышка разума: {vision.lower()}"
