
# --- Династии и генетика NPC ---

import random

class GeneSet:
    def __init__(self, traits=None, fetishes=None):
        self.traits = traits or []
        self.fetishes = fetishes or []

    def mix(self, other):
        # Простейшее скрещивание
        new_traits = list(set(random.sample(self.traits, k=len(self.traits)//2) +
                              random.sample(other.traits, k=len(other.traits)//2)))
        new_fetishes = list(set(random.sample(self.fetishes, k=len(self.fetishes)//2) +
                                random.sample(other.fetishes, k=len(other.fetishes)//2)))
        return GeneSet(new_traits, new_fetishes)

class DynasticNPC:
    def __init__(self, name, genes=None, dynasty=None, parents=None):
        self.name = name
        self.genes = genes or GeneSet()
        self.dynasty = dynasty
        self.parents = parents or []

    def give_birth(self, partner, child_name):
        new_genes = self.genes.mix(partner.genes)
        child = DynasticNPC(name=child_name, genes=new_genes, dynasty=self.dynasty or partner.dynasty, parents=[self, partner])
        return child

    def describe_lineage(self):
        return f"{self.name} из дома {self.dynasty}, потомок {[p.name for p in self.parents]}"
