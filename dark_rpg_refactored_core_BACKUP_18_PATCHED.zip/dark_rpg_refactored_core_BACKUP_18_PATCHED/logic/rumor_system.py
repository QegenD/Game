
# --- Система слухов, отражений и сплетен ---

import random
import json
from datetime import datetime

RUMOR_LOG = "data/rumors.json"

class Rumor:
    def __init__(self, text, target_npc, truth=True, origin_npc=None, timestamp=None):
        self.text = text
        self.target = target_npc
        self.truth = truth
        self.origin = origin_npc
        self.time = timestamp or datetime.utcnow().isoformat()

    def to_dict(self):
        return {
            "text": self.text,
            "target": self.target,
            "truth": self.truth,
            "origin": self.origin,
            "time": self.time
        }

def spread_rumor(rumor: Rumor):
    try:
        with open(RUMOR_LOG, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = []

    data.append(rumor.to_dict())
    with open(RUMOR_LOG, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def generate_random_rumor(npc_list):
    npc = random.choice(npc_list)
    rumor_type = random.choice(["romance", "fetish", "crime", "nobility", "affair", "scandal"])
    truth = random.random() < 0.6
    text = f"{npc['name']} якобы замешан в {rumor_type}..."
    return Rumor(text=text, target_npc=npc["id"], truth=truth, origin_npc="Unknown")
