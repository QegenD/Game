
# npc_nsfw_memory_reaction.py — NPC вспоминают сцены, где участвовали

class NPCMemoryReactor:
    def __init__(self, npc, memory_engine):
        self.npc = npc
        self.memory_engine = memory_engine  # NSFWFlashbackMemory

    def react_to_player(self, player):
        for scene in self.memory_engine.scenes:
            if player.name in scene.get("description", ""):
                if "романтика" in scene["tags"]:
                    self.npc.set_mood("nostalgic")
                    self.npc.increase_trust(player, 5)
                elif "унизительность" in scene["tags"]:
                    self.npc.set_mood("bitter")
                    self.npc.decrease_trust(player, 7)
                elif "жесткость" in scene["tags"]:
                    self.npc.set_mood("tense")
                elif "одержимость" in scene["tags"]:
                    self.npc.set_mood("uneasy")
