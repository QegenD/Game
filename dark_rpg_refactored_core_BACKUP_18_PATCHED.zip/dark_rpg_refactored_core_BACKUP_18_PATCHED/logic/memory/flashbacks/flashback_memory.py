
# flashback_memory.py — Запись важных флешбеков и поддержка позитивных воспоминаний

class FlashbackMemory:
    def __init__(self, character):
        self.character = character
        self.memory_log = []

    def log_flashback(self, flashback_scene, mood="neutral"):
        entry = {
            "text": flashback_scene.get("text", ""),
            "impact": flashback_scene.get("impact", []),
            "mood": mood
        }
        self.memory_log.append(entry)

    def get_summary(self):
        return [f"[{entry['mood'].upper()}] {entry['text']}" for entry in self.memory_log]

def generate_positive_flashback(context=""):
    return {
        "text": "Ты вспоминаешь нежные руки, тепло голоса... Вдохновение находит тебя.",
        "options": ["Улыбнуться", "Прикоснуться к амулету", "Промолчать"],
        "impact": [("sanity", +10), ("hope", +5)]
    }
