
# npc_memory_behavior.py — поведение NPC на основе воспоминаний

class NPCFlashbackBehavior:
    def __init__(self, npc, memory_engine):
        self.npc = npc
        self.memory_engine = memory_engine
        self.repressed_scenes = set()

    def evaluate_player_interaction(self, player):
        # Оценивает, как NPC реагирует на игрока, если есть общее NSFW-прошлое.
        for scene in self.memory_engine.scenes:
            if player.name not in scene.get("description", ""):
                continue
            if scene['id'] in self.repressed_scenes:
                continue

            tags = scene.get("tags", [])

            # Изменение поведения
            if "романтика" in tags:
                self.npc.set_behavior("affectionate")
            elif "унизительность" in tags:
                self.npc.set_behavior("avoidant")
            elif "одержимость" in tags:
                self.npc.set_behavior("clingy")
            elif "жесткость" in tags:
                self.npc.set_behavior("defensive")

            # Возможно вытеснение травматичной сцены
            if "травма" in tags or "унизительность" in tags:
                if self.npc.traits.get("willpower", 5) < 4:
                    self.repressed_scenes.add(scene['id'])

    def generate_flashback_dialogue(self, player):
        if self.npc.trust.get(player.name, 0) > 70:
            for scene in self.memory_engine.scenes:
                if player.name in scene.get("description", ""):
                    tags = ", ".join(scene.get("tags", []))
                    return f"Иногда я вспоминаю то, что было между нами... ({tags})"
        return None
