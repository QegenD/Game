
# seduction_engine.py — пошаговая система соблазнения NPC

import random

def attempt_seduction(npc, player, context):
    seduction_score = 0
    log = []

    if npc["mood"] in ["flirty", "curious"]:
        seduction_score += 2
        log.append("NPC в открытом настроении.")

    if player.get("charm", 0) > 5:
        seduction_score += 1
        log.append("Очарование игрока сработало.")

    if npc.get("trust", 0) > 6:
        seduction_score += 2
        log.append("NPC доверяет игроку.")

    if context.get("place") in ["tavern", "bedroom", "ritual_site"]:
        seduction_score += 1
        log.append(f"Атмосфера располагает ({context['place']}).")

    if npc.get("fear", 0) > 5:
        seduction_score -= 3
        log.append("NPC чувствует страх — минус к соблазнению.")

    success = seduction_score >= random.randint(3, 7)
    result = "успех" if success else "провал"

    return {
        "success": success,
        "score": seduction_score,
        "log": log,
        "result": result
    }
