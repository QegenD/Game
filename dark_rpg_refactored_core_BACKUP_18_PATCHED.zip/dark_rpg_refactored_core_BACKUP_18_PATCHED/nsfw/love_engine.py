
# love_engine.py — отношения, разрывы, гаремы

def evaluate_relationship(npc, player, context):
    if npc.get("bonded_to_player") and context == "betrayal":
        if npc.get("personality") in ["jealous", "shy"]:
            npc["bonded_to_player"] = False
            npc["mood"] = "betrayed"
            npc.setdefault("rumors", []).append("Player betrayed me with another...")
            return "breakup"
        elif npc.get("personality") in ["bold", "dominant"]:
            npc["mood"] = "furious"
            return "angry_confrontation"
        else:
            npc["mood"] = "hurt"
            return "disappointed"

    elif context == "reconciliation":
        if npc["mood"] in ["hurt", "betrayed"] and player.get("charisma", 5) >= 6:
            npc["bonded_to_player"] = True
            npc["mood"] = "hopeful"
            return "reunited"
        else:
            return "rejected"

    return "no_change"

def attempt_harem_addition(npc, player, harem_list):
    if npc.get("jealousy", 0) > 5:
        return "refuses"

    if npc.get("personality") in ["open", "curious"]:
        harem_list.append(npc["name"])
        npc["bonded_to_player"] = True
        npc["mood"] = "accepted"
        return "accepted"

    if player.get("charisma", 0) >= 8:
        harem_list.append(npc["name"])
        npc["bonded_to_player"] = True
        npc["mood"] = "surrendered"
        return "accepted_by_charm"

    return "refuses"
