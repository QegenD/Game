
# nsfw_revolution_engine.py — революции и реакции мира

def update_nsfw_heat(location, nsfw_level):
    if nsfw_level > 8:
        location.setdefault("tags", []).append("nsfw_hotspot")
        location["features"] = location.get("features", []) + ["underground_club"]
        location["nsfw_reputation"] = "infamous"
        return "club_created"
    elif nsfw_level > 5:
        location["nsfw_reputation"] = "notorious"
        return "gossip"
    return "stable"

def faction_reacts(faction, world):
    if faction.get("morality", "neutral") == "strict":
        faction["attitude_to_player"] = "hostile"
        world.setdefault("events", []).append(f"{faction['name']} declared war on decadence!")
    elif faction.get("morality") == "hedonist":
        faction["attitude_to_player"] = "admiring"
        world.setdefault("events", []).append(f"{faction['name']} sent gifts in honor of your boldness.")
