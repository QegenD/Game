
# emotional_flashbacks.py — эмоциональные флешбеки и последствия

from random import randint, choice
from nsfw.memories.nsfw_memories import get_recent_memories, find_memories_by_npc

def trigger_flashback(npc):
    if randint(0, 100) < 30:  # 30% шанс флешбека
        memories = find_memories_by_npc(npc.name)
        if memories:
            memory = choice(memories)
            effect = interpret_flashback_effect(memory, npc)
            return f"⚡ {npc.name} вспоминает: '{memory['description']}'\n🎭 Эмоциональный эффект: {effect}"
    return None

def interpret_flashback_effect(memory, npc):
    if "ritual" in memory["scene_type"]:
        if "pain" in memory["description"] or "жертвоприношение" in memory["description"]:
            return "страх, подавленность"
        elif "orgasm" in memory["description"] or "слияние" in memory["description"]:
            return "возбуждение, зависимость"
    return "ностальгия"
