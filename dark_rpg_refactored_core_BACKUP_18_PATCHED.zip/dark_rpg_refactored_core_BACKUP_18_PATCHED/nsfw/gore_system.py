
# gore_system.py — кровавые сцены, расчленения, NSFW-гибель

import random

death_scenes = [
    "was split in two by a massive axe",
    "had their head crushed like a melon",
    "bled out slowly, screaming curses",
    "was torn apart by maddened beasts",
    "exploded into a mist of gore and pain"
]

def generate_gore_scene(npc):
    scene = random.choice(death_scenes)
    description = f"{npc.name} {scene}."
    npc.status = "dead"
    npc.status_effects.append("gore_scene")
    print(description)
    return description
