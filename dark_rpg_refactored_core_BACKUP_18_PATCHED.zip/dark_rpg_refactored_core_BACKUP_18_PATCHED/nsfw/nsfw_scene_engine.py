
# nsfw_scene_engine.py — ИИ NSFW сцены и SD изображения по стадиям

from auto_image_generator import generate_image
from ai.ai_content_generator import generate_nsfw_scene_description

def run_nsfw_scene(actor, partner, location, fetishes):
    log = []
    stages = ["flirt", "undress", "foreplay", "climax", "afterplay"]
    for stage in stages:
        desc = generate_nsfw_scene_description(actor, partner, stage, fetishes, location)
        log.append(desc)
        generate_image(desc, context="nsfw")
    return log


from nsfw.nsfw_memory_engine import record_nsfw_interaction

def run_nsfw_scene_with_memory(actor, partner, location, fetishes, world):
    log = run_nsfw_scene(actor, partner, location, fetishes)
    # Предположим оценку удовольствия
    outcome = {
        "pleasure": actor.get("lewd_level", 5) + partner.get("lewd_level", 5) // 3,
        "tags": fetishes,
        "public": location in ["public_bath", "street"]
    }
    record_nsfw_interaction(partner, actor, outcome, world)
    record_nsfw_interaction(actor, partner, outcome, world)
    return log
