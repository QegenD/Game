
# nsfw_emotion_shift_engine.py — трансформация эмоций в процессе сцены

EMOTION_TRANSITIONS = {
    "nervous": ["curious", "tender", "lustful"],
    "angry": ["dominant", "lustful"],
    "tender": ["lustful", "happy"],
    "lustful": ["ecstatic", "overwhelmed"],
    "submissive": ["tender", "overwhelmed"],
    "dominant": ["possessive", "focused"]
}

def evolve_emotion(current_mood):
    options = EMOTION_TRANSITIONS.get(current_mood, [])
    if options:
        from random import choice
        return choice(options)
    return current_mood
