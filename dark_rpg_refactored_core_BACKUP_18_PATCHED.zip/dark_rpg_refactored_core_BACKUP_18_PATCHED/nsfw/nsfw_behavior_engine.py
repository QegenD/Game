
# nsfw_behavior_engine.py — фазы, позы, инициатива, предпочтения, фетиши

import random

POSITIONS = [
    "миссионерская", "наездница", "догги-стайл", "69", "на коленях", "стоя"
]

INITIATIVE = ["игрок", "npc", "взаимная"]

PREFERENCES = {
    "vanilla": ["миссионерская", "наездница"],
    "submissive": ["догги-стайл", "на коленях"],
    "dominant": ["стоя", "наездница"],
    "kinky": ["69", "догги-стайл", "на коленях"]
}

def choose_position(npc):
    fetish = npc.get("fetish", "vanilla")
    options = PREFERENCES.get(fetish, POSITIONS)
    return random.choice(options)

def choose_initiative(npc, player):
    npc_dominance = npc.get("dominance", 0)
    player_dominance = player.get("dominance", 0)

    if abs(npc_dominance - player_dominance) < 2:
        return "взаимная"
    return "npc" if npc_dominance > player_dominance else "игрок"
