
# nsfw_memory_cards.py — персональные карточки памяти и альбомы NPC

import uuid

class NSFWMemoryCard:
    def __init__(self, npc_id, player_id, scene):
        self.id = str(uuid.uuid4())
        self.npc_id = npc_id
        self.player_id = player_id
        self.scene_id = scene.get("id")
        self.image_path = scene.get("image_path")
        self.description = scene.get("summary", "Момент, оставшийся в памяти...")
        self.mood = scene.get("mood")
        self.position = scene.get("position")
        self.tags = [scene.get("initiative"), self.mood, self.position]

    def to_dict(self):
        return {
            "id": self.id,
            "npc_id": self.npc_id,
            "player_id": self.player_id,
            "scene_id": self.scene_id,
            "image_path": self.image_path,
            "description": self.description,
            "mood": self.mood,
            "position": self.position,
            "tags": self.tags
        }

class NSFWMemoryGallery:
    def __init__(self):
        self.cards_by_npc = {}

    def add_card(self, npc_id, card):
        if npc_id not in self.cards_by_npc:
            self.cards_by_npc[npc_id] = []
        self.cards_by_npc[npc_id].append(card)

    def get_gallery(self, npc_id):
        return self.cards_by_npc.get(npc_id, [])
