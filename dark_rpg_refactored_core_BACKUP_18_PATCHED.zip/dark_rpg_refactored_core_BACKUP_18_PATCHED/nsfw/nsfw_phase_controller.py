
# nsfw_phase_controller.py — контроллер фаз NSFW-сцены и SD-генерации

from nsfw.nsfw_scene_contextualizer import generate_nsfw_scene_phase

def play_nsfw_scene(npc, player, context, sd_generator_callback):
    phases = ["prelude", "foreplay", "main_act", "climax", "afterglow"]
    full_log = []

    for phase in phases:
        scene = generate_nsfw_scene_phase(npc, player, context, phase)
        full_log.append(scene["description"])

        # Генерация изображения через callback
        if sd_generator_callback:
            sd_generator_callback(scene["image_prompt"])

    return full_log
