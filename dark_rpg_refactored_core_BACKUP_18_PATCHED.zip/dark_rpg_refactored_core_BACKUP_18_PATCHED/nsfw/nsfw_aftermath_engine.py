
# nsfw_aftermath_engine.py — последствия сцены (визуальные и описательные)

def get_aftermath_prompt(npc, player, scene_history):
    parts = []

    if scene_history:
        phases = len(scene_history)
        if phases >= 3:
            parts.append("растрёпанные волосы, потное тело")
        if "dominant" in [s.get("initiative") for s in scene_history[-2:]]:
            parts.append("следы поцелуев, покрасневшая кожа")
        if any("position" in s and "kneeling" in s["position"].lower() for s in scene_history):
            parts.append("следы на коленях")
        if npc.get("mood") == "overwhelmed":
            parts.append("усталый, зачарованный взгляд")

    if not parts:
        parts.append("лёгкая усталость и расслабленное выражение лица")

    return ", ".join(parts)
