
# nsfw_instructors.py — обучение NSFW-навыкам

import random

def train_nsfw_skill(trainer, student, skill):
    if "instructor_nsfw" not in trainer.get("tags", []):
        return False
    student_tree = student.get("nsfw_skill_tree")
    if student_tree:
        amount = random.randint(1, 2)
        student_tree.gain_xp(skill, amount)
        return True
    return False
