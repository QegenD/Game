import argparse
import logging
import os
from config import settings
from character_creation_gui import run_gui
from logic.world_initializer import initialize_world
from core.npc_faction_dynamics import NPCFactionManager
from core.world_crisis_manager import WorldCrisisManager
from core.rumor_system import RumorSystem
from world_master import run_world_director_tick
from prophecies import generate_prophecy
from social_network import connections
from game_loop import game_loop

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

def main():
    logging.info("🔧 Инициализация мира...")
    initialize_world()

    if not os.path.exists(settings["player_data_path"]):
        logging.info("👤 Создание нового персонажа...")
        run_gui()

    logging.info("🚀 Запуск игрового цикла...")
    faction_manager = NPCFactionManager()
    crisis_manager = WorldCrisisManager()
    rumor_system = RumorSystem()

    game_loop(
        faction_manager,
        crisis_manager,
        rumor_system,
        run_world_director_tick,
        generate_prophecy,
        connections,
        settings["update_interval_seconds"]
    )

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dark RPG Launcher")
    parser.add_argument("--debug", action="store_true", help="Включить режим отладки")
    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    main()
