import random
import logging
from config import settings

logger = logging.getLogger(__name__)

# Конфигурация по умолчанию (можно перенести в config.py)
DEFAULT_PERSONALITIES = ["jealous", "curious", "dominant", "shy", "bold", "open"]
DEFAULT_FETISHES = ["bondage", "voyeurism", "oral", "dominance", "submission"]

def enrich_with_relationship_traits(npc):
    npc["jealousy"] = random.randint(0, 10)
    npc["bonded_to_player"] = False
    npc["personality"] = npc.get("personality") or random.choice(DEFAULT_PERSONALITIES)
    return npc

def generate_npc_profile(npc):
    npc = enrich_with_relationship_traits(npc)
    npc["name"] = f"{npc.get('race', 'Unknown')}_{npc.get('class', 'Adventurer')}_{random.randint(100,999)}"
    npc["description"] = f"Представитель расы {npc.get('race', 'неизвестной')} класса {npc.get('class', 'неизвестного')}, загадочный и уникальный."
    npc["fetishes"] = random.sample(DEFAULT_FETISHES, k=2)
    npc["mood"] = "neutral"
    logger.debug(f"Сгенерирован NPC-профиль: {npc['name']}")
    return npc

def generate_nsfw_scene_description(actor, partner, stage, fetishes, location):
    if not settings.get("enable_nsfw", True):
        return "NSFW контент отключён в настройках."

    base = f"{actor['name']} и {partner['name']} находятся в {location} (этап: {stage}). "

    stage_map = {
        "flirt": f"{actor['name']} заигрывает, удерживая пристальный взгляд.",
        "undress": f"{partner['name']} медленно снимает одежду, оголяя кожу.",
        "foreplay": f"Их тела переплетаются в чувственных прикосновениях.",
        "climax": f"Кульминация страсти сопровождается стонами и жаром.",
        "afterplay": f"Они отдыхают, обмениваясь ласками и взглядами."
    }

    base += stage_map.get(stage, "Сцена развивается...")

    if "bondage" in fetishes:
        base += " В этой сцене используются верёвки и ограничения."
    if "dominance" in fetishes:
        base += f" {actor['name']} доминирует с командным тоном."

    logger.debug(f"Сцена NSFW: {base}")
    return base
