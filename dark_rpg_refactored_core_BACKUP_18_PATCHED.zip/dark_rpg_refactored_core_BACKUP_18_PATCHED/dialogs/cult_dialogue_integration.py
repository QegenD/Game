
# cult_dialogue_integration.py — Проповеди и пропаганда культов в диалогах

def generate_cult_dialogue(npc):
    if getattr(npc, 'is_cultist', False):
        messages = [
            "Ты слышал Глас Пропасти? Он зовёт нас!",
            "Настанет день, когда всё старое сгорит в ритуальном пламени.",
            "Печать Агонии уже треснула...",
            "Лишь через боль приходит истинное знание.",
            "Мы служим Истинной Тени, а ты?"
        ]
        return npc.name + " говорит: " + random.choice(messages)
    return None
