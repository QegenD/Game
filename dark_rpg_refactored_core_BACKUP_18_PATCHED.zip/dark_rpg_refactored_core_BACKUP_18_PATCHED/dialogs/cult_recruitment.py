
# cult_recruitment.py — Игрок может быть завербован в культ или отказаться

def attempt_cult_recruitment(player, npc):
    if not getattr(npc, 'is_cultist', False):
        return None

    lines = [
        "Вижу в тебе пылающий огонь. Присоединись к нам...",
        "Ты можешь стать частью величия. Прими печать.",
        "Ты достоин служить Тени. Преклонись.",
        "Ты в поисках смысла? Мы дадим тебе Истину."
    ]

    offer = {
        "npc": npc.name,
        "message": npc.name + " говорит: '" + random.choice(lines) + "'",
        "choices": ["Принять", "Отказаться", "Задать вопрос"]
    }

    return offer

def handle_recruitment_choice(player, choice):
    if choice == "Принять":
        player.faction = "cult"
        player.perks.append("ritual_access")
        return "Ты стал частью Тени. Твои глаза открылись."
    elif choice == "Отказаться":
        player.reputation["cultists"] = -5
        return "Ты отверг Тень. Они запомнят это."
    elif choice == "Задать вопрос":
        return "Вопросов будет много. Ответы — позже. Теперь решай."
    return "Ты ушёл в молчании..."
