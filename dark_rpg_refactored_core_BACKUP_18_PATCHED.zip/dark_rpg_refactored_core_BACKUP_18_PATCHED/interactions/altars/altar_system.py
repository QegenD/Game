
# altar_system.py — взаимодействие с алтарями и последствия

import random

ALTAR_ACTIONS = [
    "помолиться",
    "принести в дар кровь",
    "предложить артефакт",
    "пожертвовать плоть",
    "взывать к божеству"
]

def interact_with_altar(player, god, action):
    if action not in ALTAR_ACTIONS:
        return "Непонятное действие. Алтарь безмолвствует."

    result = calculate_outcome(player, god, action)
    return result

def calculate_outcome(player, god, action):
    favor = random.randint(0, 100)
    if "взывать" in action or "плоть" in action:
        if favor > 70:
            return f"{god['name']} дарует тьму и силу. Получено усиление."
        elif favor > 30:
            return f"{god['name']} слышит, но молчит."
        else:
            return f"{god['name']} гневается. Получено проклятие."
    elif "помолиться" in action:
        return f"Вы ощущаете тёплый свет. {god['name']} удовлетворён."
    elif "артефакт" in action:
        return f"{god['name']} принимает дар. Благосклонность +1."
    else:
        return "Вы ощущаете вибрации магии вокруг алтаря..."
