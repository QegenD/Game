import time
import random
import logging
from world_log import log_event
from config import settings

logger = logging.getLogger(__name__)

def game_loop(faction_manager, crisis_manager, rumor_system,
              run_world_director_tick, generate_prophecy, connections,
              max_ticks=None):

    tick = 0
    max_ticks = max_ticks or settings.get("max_game_ticks", 5)
    delay = settings.get("tick_delay_seconds", 1)

    factions = list(faction_manager.factions)

    while tick < max_ticks:
        logger.info(f"[TICK {tick + 1}]")

        time.sleep(delay)

        npc = f"NPC_{random.randint(100, 999)}"
        faction = random.choice(factions)
        faction_manager.assign_npc(npc, faction)
        logger.info(f"{npc} присоединился к фракции {faction}")
        log_event("join_faction", [npc, faction], f"{npc} присоединился к {faction}")

        try:
            result = crisis_manager.evaluate_crisis(npc, alert_level=5, recent_events=["магическая буря"])
            logger.info(f"[КРИЗИС] {result}")
            log_event("crisis_check", [npc], result)
        except Exception as e:
            logger.exception("Ошибка при обработке кризиса.")

        try:
            rumor = rumor_system.generate_rumor(npc)
            logger.info(f"[СЛУХ] {rumor}")
            log_event("rumor", [npc], rumor)
        except Exception as e:
            logger.exception("Ошибка при генерации слуха.")

        if tick % 2 == 0:
            logger.debug("[AI-ДИРИЖЁР] Управление миром...")
            try:
                run_world_director_tick(factions)
            except Exception as e:
                logger.exception("Ошибка при обновлении AI-дирижёра.")

        if tick % 3 == 0:
            try:
                prophecy = generate_prophecy(npc)
                logger.info(f"[ПРОРОЧЕСТВО] {prophecy}")
            except Exception as e:
                logger.exception("Ошибка при генерации пророчества.")

        # Надёжное обновление социальных связей
        if random.random() < 0.5:
            target = f"NPC_{random.randint(100, 999)}"
            if npc not in connections:
                connections[npc] = {"friends": []}
            elif "friends" not in connections[npc]:
                connections[npc]["friends"] = []

            connections[npc]["friends"].append(target)
            logger.info(f"{npc} подружился с {target}")
            log_event("relationship_update", [npc, target], f"{npc} подружился с {target}")

        tick += 1
