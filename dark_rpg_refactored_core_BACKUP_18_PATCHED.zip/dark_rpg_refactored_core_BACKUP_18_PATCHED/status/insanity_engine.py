
# insanity_engine.py — постепенное сумасшествие от 'corruption'

def update_insanity(player, world_state):
    if "corruption" in player.status_effects:
        player.sanity = max(player.sanity - 1, 0)

        if player.sanity < 30 and "whispers" not in player.status_effects:
            player.status_effects.append("whispers")
        if player.sanity < 15 and "visions" not in player.status_effects:
            player.status_effects.append("visions")
        if player.sanity <= 0 and "madness" not in player.status_effects:
            player.status_effects.append("madness")

        return True
    return False
