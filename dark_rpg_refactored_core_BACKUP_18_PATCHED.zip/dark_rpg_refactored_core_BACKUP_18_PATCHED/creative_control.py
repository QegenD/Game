# creative_control.py

CREATIVE_FLAGS = {
    "full_creative": True,
    "no_repeat_npc": True,
    "no_repeat_scene": True,
    "personality_driven": True,
    "deep_emotion_context": True,
    "goal_based_story": True
}
