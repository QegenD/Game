import random

class PsycheProgression:
    def __init__(self):
        self.psyche_map = {}

    def init_psyche(self, npc_id):
        self.psyche_map[npc_id] = {
            "taboo_level": round(random.uniform(0.2, 0.8), 2),
            "adaptability": round(random.uniform(0.3, 0.7), 2),
            "trauma_memory": [],
        }

    def register_event(self, npc_id, event):
        self.psyche_map.setdefault(npc_id, {}).setdefault("trauma_memory", []).append(event)

    def update_psyche(self, npc_id, player_action_intensity):
        psyche = self.psyche_map.get(npc_id)
        if not psyche:
            return

        change_chance = psyche["adaptability"]
        if random.random() < change_chance:
            delta = random.uniform(-0.05, 0.05)
            psyche["taboo_level"] = max(0.0, min(1.0, psyche["taboo_level"] + delta))

    def is_taboo_triggered(self, npc_id, action_intensity):
        psyche = self.psyche_map.get(npc_id, {})
        return action_intensity > psyche.get("taboo_level", 1.0)