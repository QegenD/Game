
# --- Главный UI-хаб мира ---

import tkinter as tk
from tkinter import ttk
from gui.panels import npc_status, faction_control, world_log_ui, gallery_viewer

class WorldHubUI:
    def __init__(self, root):
        self.root = root
        self.root.title("World Master Hub")
        self.tabs = ttk.Notebook(self.root)

        self.npc_frame = tk.Frame(self.tabs)
        self.faction_frame = tk.Frame(self.tabs)
        self.log_frame = tk.Frame(self.tabs)
        self.gallery_frame = tk.Frame(self.tabs)
        self.newspaper_frame = tk.Frame(self.tabs)
        self.crisis_frame = tk.Frame(self.tabs)
        self.secrets_frame = tk.Frame(self.tabs)

        self.tabs.add(self.npc_frame, text="NPC")
        self.tabs.add(self.faction_frame, text="Factions")
        self.tabs.add(self.log_frame, text="Chronicle")
        self.tabs.add(self.gallery_frame, text="Gallery")
        self.tabs.add(self.newspaper_frame, text="Newspapers")
        self.tabs.add(self.crisis_frame, text="Crises")
        self.tabs.add(self.secrets_frame, text="Secrets")

        self.tabs.pack(expand=1, fill="both")

        npc_status.build(self.npc_frame)
        faction_control.build(self.faction_frame)
        world_log_ui.build(self.log_frame)
        gallery_viewer.build(self.gallery_frame)
        from gui.panels import newspaper_panel
        newspaper_panel.build(self.newspaper_frame)
        from gui.panels import crisis_panel
        crisis_panel.build(self.crisis_frame)
        from gui.panels import deep_secrets_panel
        deep_secrets_panel.build(self.secrets_frame)

def launch_hub():
    root = tk.Tk()
    app = WorldHubUI(root)
    root.mainloop()
