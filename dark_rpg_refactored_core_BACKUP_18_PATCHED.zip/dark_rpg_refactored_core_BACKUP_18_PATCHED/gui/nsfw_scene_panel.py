
from nsfw_scene_engine import NSFWSceneEngine
from psyche_progression import PsycheProgression

def render_nsfw_scene_panel(player, npc):
    print(f"--- NSFW-Панель ---")
    print(f"NPC: {npc.name}")
    print(f"Отношения с NPC: {npc.relations.get(player.name, 0)}")

    if not hasattr(player, 'nsfw_experience_level'):
        print("У игрока нет опыта. Инициализируем PsycheProgression...")
        player.psyche = PsycheProgression()
        player.nsfw_experience_level = player.psyche.experience_level
    else:
        print(f"NSFW Уровень игрока: {player.nsfw_experience_level}")

    print("\n[Навыки и техники]:")
    if hasattr(player, 'psyche'):
        for tech in player.psyche.describe()['techniques']:
            print(f" - {tech}")
    else:
        print("Нет информации о навыках.")

    engine = NSFWSceneEngine(player, npc)
    scene = engine.generate_scene()

    print("\n[Результат сцены]:")
    print(scene)
