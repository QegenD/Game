
import tkinter as tk
import json

def build(frame):
    tk.Label(frame, text="NSFW Scene Gallery", font=("Arial", 14)).pack()
    try:
        with open("data/gallery.json", "r", encoding="utf-8") as f:
            scenes = json.load(f)
        for s in scenes[-20:]:
            text = f"[{s.get('time')}] Scene: {s.get('scene_type')} — NPCs: {s.get('npc_ids')}"
            tk.Label(frame, text=text, anchor="w", justify="left").pack(fill="x")
    except:
        tk.Label(frame, text="No gallery data.").pack()
