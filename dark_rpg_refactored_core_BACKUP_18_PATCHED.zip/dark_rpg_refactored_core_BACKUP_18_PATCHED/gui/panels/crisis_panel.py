
import tkinter as tk
import json

def build(frame):
    tk.Label(frame, text="🌍 Мировые кризисы", font=("Arial", 14)).pack()
    try:
        with open("data/world_crises.json", "r", encoding="utf-8") as f:
            crises = json.load(f)[-10:]
        for c in crises:
            txt = f"{c['type']} в регионе {c['region']} (Интенсивность: {c['intensity']})"
            tk.Label(frame, text=txt, anchor="w").pack(fill="x")
    except:
        tk.Label(frame, text="Нет активных кризисов.").pack()
