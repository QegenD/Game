
import tkinter as tk

def build(frame):
    tk.Label(frame, text="NPC Status Viewer", font=("Arial", 14)).pack()
    # Здесь будет вывод данных о потребностях, доверии, настроении
