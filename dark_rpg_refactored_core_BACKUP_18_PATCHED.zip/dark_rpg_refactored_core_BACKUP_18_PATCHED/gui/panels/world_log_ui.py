
import tkinter as tk
import json

def build(frame):
    tk.Label(frame, text="World Chronicle", font=("Arial", 14)).pack()
    try:
        with open("data/world_log.json", "r", encoding="utf-8") as f:
            events = json.load(f)
        for e in events[-20:]:
            text = f"[{e.get('time')}] {e.get('faction', 'World')}: {e.get('action', e.get('type'))}"
            tk.Label(frame, text=text, anchor="w", justify="left").pack(fill="x")
    except:
        tk.Label(frame, text="No log data.").pack()
