
# visualizer_panel.py

from visualizer import draw_social_graph, draw_faction_graph, draw_world_map

def render_visualizer_panel(social_graph=None, factions=None, world_regions=None, control_map=None):
    print("=== Панель визуализации ===")

    if social_graph:
        print("▶️ Отображение социальной сети NPC...")
        draw_social_graph(social_graph.all_connections())

    if factions:
        print("▶️ Отображение графа фракций...")
        draw_faction_graph(factions)

    if world_regions:
        print("▶️ Отображение карты мира...")
        draw_world_map(world_regions, faction_control=control_map)
