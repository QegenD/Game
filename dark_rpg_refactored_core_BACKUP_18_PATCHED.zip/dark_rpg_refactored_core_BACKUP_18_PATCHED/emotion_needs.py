# Эмоции и потребности NPC

class EmotionSystem:
    pass
