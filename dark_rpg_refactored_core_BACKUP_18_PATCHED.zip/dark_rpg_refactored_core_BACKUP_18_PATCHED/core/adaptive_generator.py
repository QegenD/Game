import random
import json
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class AdaptiveMemory:
    def __init__(self, decay_rate=0.95):
        self.interaction_log = []
        self.context_weights = {}
        self.last_updated = datetime.now()
        self.decay_rate = decay_rate

    def log_interaction(self, context, result_success=True):
        timestamp = datetime.now().isoformat()
        self.interaction_log.append({"context": context, "success": result_success, "timestamp": timestamp})
        weight_change = 1 if result_success else -0.5

        if context not in self.context_weights:
            self.context_weights[context] = weight_change
        else:
            self.context_weights[context] += weight_change

        logger.debug(f"Logged interaction: context={context}, success={result_success}, weight={self.context_weights[context]}")

    def decay_weights(self):
        now = datetime.now()
        elapsed = (now - self.last_updated).total_seconds()
        if elapsed < 10:
            return

        for context in self.context_weights:
            self.context_weights[context] *= self.decay_rate
        self.last_updated = now
        logger.debug("Decayed context weights.")

    def get_weighted_context(self):
        self.decay_weights()
        if not self.context_weights:
            return None
        return max(self.context_weights, key=self.context_weights.get)

    def adjust_behavior(self, options):
        self.decay_weights()
        context = self.get_weighted_context()
        if context and context in options:
            logger.debug(f"Adaptive choice: context={context}, action={options[context]}")
            return options[context]
        choice = random.choice(list(options.values())) if options else None
        logger.debug(f"Fallback choice: {choice}")
        return choice

    def save_memory(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({
                "interaction_log": self.interaction_log,
                "context_weights": self.context_weights
            }, f, indent=2)
        logger.info(f"Memory saved to {path}")

    def load_memory(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.interaction_log = data.get("interaction_log", [])
                self.context_weights = data.get("context_weights", {})
            logger.info(f"Memory loaded from {path}")
        except Exception as e:
            logger.warning(f"Failed to load memory from {path}: {e}")
