
# npc_generator.py — генерация NPC без шаблонов

import random
from ai.ai_content_generator import generate_npc_profile
from data.available_races import RACES
from data.available_classes import CLASSES

def generate_npc():
    race = random.choice(RACES)
    char_class = random.choice(CLASSES)
    base_npc = {
        "race": race,
        "class": char_class,
        "level": random.randint(1, 5),
        "faction": None,
        "tags": [],
        "lewd_level": random.randint(0, 40)
    }
    enriched = generate_npc_profile(base_npc)
    return enriched
