class FaceEmotionMatcher:
    def __init__(self):
        self.mapping = {
            "joy": "smiling, bright eyes, cheerful expression",
            "anger": "furrowed brows, clenched jaw, intense glare",
            "fear": "wide eyes, pale face, tense expression",
            "trust": "soft eyes, relaxed posture, slight smile",
            "disgust": "wrinkled nose, curled lips, narrowed eyes",
            "sadness": "teary eyes, downturned lips, drooping eyebrows",
            "neutral": "relaxed face, blank expression"
        }

    def get_expression(self, emotion):
        return self.mapping.get(emotion, self.mapping["neutral"])
