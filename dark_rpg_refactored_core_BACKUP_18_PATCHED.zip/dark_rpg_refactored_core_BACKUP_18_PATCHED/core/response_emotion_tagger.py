class ResponseEmotionTagger:
    def __init__(self):
        self.keywords = {
            "joy": ["happy", "glad", "pleased", "excited", "yay", "fun"],
            "anger": ["hate", "angry", "furious", "rage", "kill", "burn"],
            "fear": ["afraid", "scared", "fear", "run", "danger", "hide"],
            "trust": ["trust", "believe", "safe", "follow", "loyal", "friend"],
            "disgust": ["disgust", "gross", "nasty", "ugh", "vomit", "ew"],
            "sadness": ["sad", "sorry", "cry", "tears", "miss", "alone"]
        }

    def get_emotion_tag(self, response_text):
        text = response_text.lower()
        score = {emotion: 0 for emotion in self.keywords}

        for emotion, words in self.keywords.items():
            for word in words:
                if word in text:
                    score[emotion] += 1

        if all(v == 0 for v in score.values()):
            return "neutral"

        return max(score, key=score.get)
