import matplotlib.pyplot as plt
from core.contextual_emotion_engine import ContextualEmotionEngine

class EmotionVisualizer:
    def __init__(self, emotion_engine=None):
        self.engine = emotion_engine or ContextualEmotionEngine()

    def plot_current_emotions(self):
        emotions = self.engine.emotions
        labels = list(emotions.keys())
        values = [emotions[k] for k in labels]

        plt.figure(figsize=(10, 5))
        bars = plt.bar(labels, values, color='skyblue')
        plt.title("Current NPC Emotion Levels")
        plt.ylabel("Intensity")
        plt.ylim(0, 1.1)

        for bar in bars:
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2.0, height + 0.02,
                     f'{height:.2f}', ha='center', va='bottom')

        plt.tight_layout()
        plt.show()

if __name__ == "__main__":
    viz = EmotionVisualizer()
    viz.plot_current_emotions()
