import logging
from core.contextual_emotion_engine import ContextualEmotionEngine
from core.auto_image_generator import AutoImageGenerator

logger = logging.getLogger(__name__)

class DeveloperPanel:
    def __init__(self):
        self.emotion_engine = ContextualEmotionEngine()
        self.image_generator = AutoImageGenerator()
        logger.info("DeveloperPanel initialized.")

    def simulate_event(self, event_name):
        logger.info(f"Simulating event: {event_name}")
        self.emotion_engine.evaluate_event(event_name)
        current_emotion = self.emotion_engine.get_emotional_state()
        tone = self.emotion_engine.get_tone()
        print(f"[DEBUG] Emotional state: {current_emotion}, tone: {tone}")

    def test_prompt_generation(self, description, category=None, emotion=None, nsfw=False):
        logger.info("Testing image prompt generation.")
        output = self.image_generator.generate(description, category, emotion, nsfw)
        print(f"[DEBUG] Image saved to: {output if output else 'Generation failed'}")

    def show_emotions(self):
        logger.info("Displaying all current emotion levels.")
        for emotion, value in self.emotion_engine.emotions.items():
            print(f"{emotion}: {round(value, 2)}")

    def run_demo(self):
        print("Developer Panel Demo Mode")
        self.simulate_event("player_gift")
        self.simulate_event("player_attack")
        self.test_prompt_generation("a haunted knight in mist", category="undead", emotion="fear")
        self.show_emotions()
