import time
from core.contextual_emotion_engine import ContextualEmotionEngine

class EmotionSimulator:
    def __init__(self):
        self.engine = ContextualEmotionEngine()

    def simulate_sequence(self, event_list, delay=0.5):
        print("[EmotionSimulator] Starting simulation...")
        for event in event_list:
            print(f"> Event: {event}")
            self.engine.evaluate_event(event)
            self.print_emotions()
            time.sleep(delay)

    def print_emotions(self):
        state = self.engine.get_emotional_state()
        print(f"  Dominant emotion: {state}")
        for emotion, value in sorted(self.engine.emotions.items()):
            print(f"   - {emotion}: {round(value, 2)}")
        print("")

if __name__ == "__main__":
    sim = EmotionSimulator()
    sim.simulate_sequence([
        "player_gift",
        "praise",
        "help",
        "insult",
        "player_attack",
        "betrayal",
        "praise"
    ])
