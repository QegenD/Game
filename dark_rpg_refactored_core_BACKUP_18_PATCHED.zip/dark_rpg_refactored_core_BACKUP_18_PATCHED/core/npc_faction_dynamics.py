
import random

class NPCFactionManager:
    def __init__(self):
        self.npc_factions = {}
        self.factions = {"Королевство Севера", "Культ Тени", "Ордена Света", "Скрытая Академия"}
        self.npc_loyalty = {}  # loyalty 0-100

    def assign_npc(self, npc, faction):
        self.npc_factions[npc] = faction
        self.npc_loyalty[npc] = random.randint(30, 100)

    def evaluate_loyalty_shift(self, npc, recruiter_faction, influence):
        if npc not in self.npc_factions:
            return "NPC не состоит ни в какой фракции"
        loyalty = self.npc_loyalty[npc]
        if influence > loyalty:
            self.npc_factions[npc] = recruiter_faction
            self.npc_loyalty[npc] = random.randint(40, 80)
            return f"{npc} переманен во фракцию: {recruiter_faction}"
        return f"{npc} отказался переметнуться"

    def attempt_found_new_faction(self, npc):
        if random.random() > 0.9:
            new_faction = f"Фракция {npc}"
            self.factions.add(new_faction)
            self.npc_factions[npc] = new_faction
            self.npc_loyalty[npc] = 100
            return f"{npc} основал новую фракцию: {new_faction}"
        return f"{npc} не удалось основать новую фракцию"

    def get_npc_faction(self, npc):
        return self.npc_factions.get(npc, "Нейтрал")
