
class NPCBehavior:
    def __init__(self):
        self.npc_location = {}
        self.fleeing_npcs = []

    def react_to_alert(self, city, alert_level):
        if alert_level >= 80:
            fleeing = [npc for npc in self.npc_location if self.npc_location[npc] == city]
            self.fleeing_npcs.extend(fleeing)
            for npc in fleeing:
                self.npc_location[npc] = "в бегах"

    def describe_npc_state(self, npc):
        return f"{npc} сейчас в: {self.npc_location.get(npc, 'неизвестно')}"

class CityHelpRequests:
    def __init__(self):
        self.requests = {}

    def check_request(self, city, alert_level):
        if alert_level >= 50:
            self.requests[city] = "Просьба о помощи: стабилизировать обстановку"
        elif city in self.requests:
            del self.requests[city]

    def get_request(self, city):
        return self.requests.get(city, None)

class BountyHunter:
    def __init__(self, real=True):
        self.real = real

    def interact(self):
        if self.real:
            return "Охотник за головами предъявляет ордер!"
        else:
            return "Ложный охотник пытается тебя ограбить!"
