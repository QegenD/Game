import os
import requests
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class AutoImageGenerator:
    def __init__(self, output_dir="generated/images", sd_url="http://127.0.0.1:7860"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.sd_url = sd_url.rstrip("/")
        logger.info(f"AutoImageGenerator initialized with output: {self.output_dir}")

    def build_prompt(self, description, category=None, emotion=None, nsfw=False):
        base = f"{description}, dark fantasy, cinematic lighting"
        if category:
            base += f", {category}"
        if emotion:
            base += f", evoking {emotion}"
        if nsfw:
            base += ", nsfw"
        return base

    def generate(self, description, category=None, emotion=None, nsfw=False, steps=30, cfg_scale=7):
        prompt = self.build_prompt(description, category, emotion, nsfw)
        logger.info(f"Generating image with prompt: {prompt}")

        payload = {
            "prompt": prompt,
            "steps": steps,
            "cfg_scale": cfg_scale,
            "width": 512,
            "height": 512,
            "sampler_index": "Euler a",
        }

        try:
            response = requests.post(f"{self.sd_url}/sdapi/v1/txt2img", json=payload)
            response.raise_for_status()
            image_data = response.json()["images"][0]
            image_bytes = requests.utils.unquote_to_bytes(image_data)

            filename = f"{description.replace(' ', '_')[:30]}_{category or 'gen'}.png"
            output_path = self.output_dir / filename
            with open(output_path, "wb") as f:
                f.write(image_bytes)
            logger.info(f"Image saved to {output_path}")
            return str(output_path)

        except Exception as e:
            logger.error(f"Image generation failed: {e}")
            return None
