
class WorldReputation:
    def __init__(self):
        self.faction_reputation = {}
        self.city_alertness = {}
        self.player_reputation = 0

    def apply_rumor_effect(self, rumor):
        if "сражение" in rumor.text or "пал от руки" in rumor.text:
            self.player_reputation += 5 if rumor.truth else -3
        elif "интрига" in rumor.text or "преступников" in rumor.text:
            self.player_reputation += 3 if rumor.truth else -2
        elif "колдун" in rumor.text or "магия выходит из-под контроля" in rumor.text:
            self.player_reputation -= 5

        if "страх" in rumor.text or "проклятие" in rumor.text:
            self.modify_city_alert(rumor.origin, 1)

    def modify_city_alert(self, city, value):
        if city not in self.city_alertness:
            self.city_alertness[city] = 0
        self.city_alertness[city] += value
        self.city_alertness[city] = min(max(self.city_alertness[city], 0), 100)

    def get_city_risk(self, city):
        return self.city_alertness.get(city, 0)

    def get_player_reputation(self):
        return self.player_reputation

    def get_price_modifier(self, city):
        alert = self.get_city_risk(city)
        return 1.0 + (alert / 100.0 * 0.5)  # цены растут при тревоге
