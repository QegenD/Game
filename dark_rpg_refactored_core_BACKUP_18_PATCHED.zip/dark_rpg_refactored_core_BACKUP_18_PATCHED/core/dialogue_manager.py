import random
from core.contextual_emotion_engine import ContextualEmotionEngine

class DialogueManager:
    def __init__(self, npc_id=None):
        self.npc_id = npc_id or "npc"
        self.emotion_engine = ContextualEmotionEngine()

        # Простые шаблоны для каждой эмоции
        self.templates = {
            "joy": ["Приятно тебя видеть!", "Ты мне нравишься."],
            "anger": ["Проваливай, пока цел!", "Ты мне надоел."],
            "fear": ["Я не хочу сражаться...", "Ты пугаешь меня."],
            "trust": ["Я тебе помогу.", "Ты доказал, что тебе можно доверять."],
            "disgust": ["Фу, мерзость!", "Мне противно с тобой говорить."],
            "sadness": ["Оставь меня в покое...", "Мне грустно."],
            "neutral": ["Что тебе нужно?", "Да?"]
        }

    def get_response(self, player_action=None):
        if player_action:
            self.emotion_engine.evaluate_event(player_action)

        emotion = self.emotion_engine.get_emotional_state()
        tone = self.emotion_engine.get_tone()
        options = self.templates.get(emotion, self.templates["neutral"])
        return {
            "text": random.choice(options),
            "emotion": emotion,
            "tone": tone
        }
