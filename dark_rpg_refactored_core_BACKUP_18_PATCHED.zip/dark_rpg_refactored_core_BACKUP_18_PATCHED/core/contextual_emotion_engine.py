import random
import logging
import time
from collections import defaultdict

logger = logging.getLogger(__name__)

class ContextualEmotionEngine:
    def __init__(self, personality=None):
        self.emotions = defaultdict(float)
        self.last_update = time.time()
        self.personality = personality or {
            "sensitivity": 1.0,    # Насколько сильны реакции на события
            "emotional_decay": 0.01  # Скорость затухания эмоций
        }

    def decay_emotions(self):
        now = time.time()
        elapsed = now - self.last_update
        decay = self.personality["emotional_decay"]
        for emotion in self.emotions:
            self.emotions[emotion] = max(0.0, self.emotions[emotion] - decay * elapsed)
        self.last_update = now

    def evaluate_event(self, event_type):
        self.decay_emotions()
        impact = self._event_impact(event_type)
        for emotion, delta in impact.items():
            self.emotions[emotion] = min(1.0, self.emotions[emotion] + delta * self.personality["sensitivity"])
        logger.info(f"Event '{event_type}' updated emotions to: {dict(self.emotions)}")

    def get_emotional_state(self):
        self.decay_emotions()
        if not self.emotions:
            return "neutral"
        dominant = max(self.emotions.items(), key=lambda x: x[1])
        return dominant[0] if dominant[1] > 0.1 else "neutral"

    def get_tone(self):
        tone_map = {
            "anger": "aggressive",
            "joy": "friendly",
            "fear": "anxious",
            "trust": "reassuring",
            "disgust": "sarcastic",
            "sadness": "depressed"
        }
        emotion = self.get_emotional_state()
        return tone_map.get(emotion, "neutral")

    def _event_impact(self, event_type):
        mapping = {
            "player_gift": {"joy": 0.3, "trust": 0.2},
            "player_attack": {"anger": 0.5, "fear": 0.2},
            "insult": {"anger": 0.3, "sadness": 0.2},
            "praise": {"joy": 0.4, "trust": 0.3},
            "betrayal": {"anger": 0.5, "disgust": 0.3},
            "help": {"trust": 0.4, "joy": 0.2}
        }
        return mapping.get(event_type, {"neutral": 0.1})
