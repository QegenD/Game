class FactionManager:
    def __init__(self):
        self.factions = []

    def add_faction(self, faction):
        self.factions.append(faction)

    def get_factions(self):
        return self.factions

    def get_faction_by_name(self, name):
        return next((f for f in self.factions if f["name"] == name), None)

# --- AI-логика фракций ---

class Faction:
    def __init__(self, name, alignment, members=None):
        self.name = name
        self.alignment = alignment  # e.g. 'militarist', 'religious', 'economic'
        self.members = members or []
        self.goals = []
        self.rivals = set()

    def add_member(self, npc_id):
        if npc_id not in self.members:
            self.members.append(npc_id)

    def set_goal(self, goal):
        self.goals.append(goal)

    def evaluate_rivalry(self, other_faction):
        if self.alignment != other_faction.alignment:
            self.rivals.add(other_faction.name)

    def __repr__(self):
        return f"Faction({self.name}, alignment={self.alignment}, members={len(self.members)})"

class FactionManager:
    def __init__(self):
        self.factions = {}

    def create_faction(self, name, alignment):
        faction = Faction(name, alignment)
        self.factions[name] = faction
        return faction

    def get_faction(self, name):
        return self.factions.get(name)

    def simulate_conflicts(self):
        for f1 in self.factions.values():
            for f2 in self.factions.values():
                if f1 != f2:
                    f1.evaluate_rivalry(f2)

    def list_factions(self):
        return list(self.factions.values())
