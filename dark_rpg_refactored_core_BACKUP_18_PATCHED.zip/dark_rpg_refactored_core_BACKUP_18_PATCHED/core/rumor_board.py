
import random
from datetime import datetime

class Rumor:
    def __init__(self, text, origin, truth=True, spread_by="неизвестно"):
        self.text = text
        self.origin = origin
        self.truth = truth
        self.spread_by = spread_by
        self.timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')

    def display(self):
        status = "правда" if self.truth else "ложь"
        return f"[{self.timestamp}] ({self.spread_by}, {status}) {self.text}"

class RumorBoard:
    def __init__(self):
        self.global_rumors = []
        self.local_rumors = {}

    def add_rumor(self, text, location=None, origin="неизвестно", truth=True, spread_by=None):
        source = spread_by or random.choice(["бард", "газетчик", "жрец", "купец", "наёмник"])
        rumor = Rumor(text, origin, truth, source)
        if location:
            if location not in self.local_rumors:
                self.local_rumors[location] = []
            self.local_rumors[location].append(rumor)
        else:
            self.global_rumors.append(rumor)

    def get_rumors(self, location=None):
        local = self.local_rumors.get(location, []) if location else []
        return [r.display() for r in self.global_rumors[-5:] + local[-5:]]

    def generate_rumor_from_event(self, event_type, target, manipulated_by=None):
        templates = {
            "battle": [
                f"Говорят, {target} пал от руки таинственного воина.",
                f"Слухи о великом сражении против {target} распространились повсюду."
            ],
            "investigation": [
                f"Интрига в {target} раскрыта неизвестным героем.",
                f"Кто-то выследил преступников в {target} — это обсуждают на рынках."
            ],
            "monster": [
                f"В {target} исчезли чудовища. Люди говорят, что их спасли духи.",
                f"Стаю волков истребил незнакомец, скрывшийся в тени."
            ],
            "false": [
                f"Некто утверждает, что правитель {target} — колдун.",
                f"По округе ходят слухи, что магия в {target} выходит из-под контроля."
            ]
        }

        truth = manipulated_by is None
        template_type = event_type if truth else "false"
        text = random.choice(templates.get(template_type, [f"В {target} произошло что-то странное."]))
        return text, truth
