
from typing import List, Dict, Any
import random

class WorldCrisisManager:
    def __init__(self):
        self.global_alert_level = 0
        self.recent_events: List[str] = []

    def register_event(self, event: str):
        self.recent_events.append(event)
        if "attack" in event or "riot" in event:
            self.global_alert_level += 1
        elif "peace" in event or "celebration" in event:
            self.global_alert_level = max(0, self.global_alert_level - 1)

    def evaluate_crisis(self, npc: Dict[str, Any], alert_level: int, recent_events: List[str]) -> str:
        personality = npc.get("personality", [])
        if "трусливый" in personality and alert_level > 2:
            return "NPC сбежал из города из-за паники"
        elif "харизматичный" in personality and "riot" in recent_events:
            return "NPC подстрекает толпу"
        elif "подчинённый" in personality and alert_level > 3:
            return "NPC исполняет приказ подавить волнения"
        elif "жестокий" in personality and alert_level > 1:
            return "NPC начинает наказывать горожан"
        else:
            return "NPC остаётся в тени"

    def get_alert_level(self) -> int:
        return self.global_alert_level

    def get_recent_events(self) -> List[str]:
        return self.recent_events[-10:]
