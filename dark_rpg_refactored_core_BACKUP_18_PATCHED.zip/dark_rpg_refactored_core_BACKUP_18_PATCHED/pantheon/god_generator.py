
# god_generator.py — генерация богов, доменов, эстетики и верований

import random

DOMAINS = [
    "war", "love", "death", "fertility", "light", "darkness", "knowledge",
    "madness", "dreams", "fire", "ice", "chaos", "order", "nature", "blood"
]

SYMBOLS = [
    "burning eye", "golden chalice", "crimson sword", "spiral sun", "serpent crown",
    "black mirror", "winged skull", "eternal flame", "thorned rose", "bone crown"
]

EPITHETS = [
    "the Merciful", "the Cruel", "Whisperer", "the Radiant", "the Silent", "of Storms",
    "the Bleeding", "the All-Seeing", "of Forgotten Ways", "the Child-Eater"
]

class God:
    def __init__(self):
        self.name = self.generate_name()
        self.domain = random.choice(DOMAINS)
        self.symbol = random.choice(SYMBOLS)
        self.epithet = random.choice(EPITHETS)
        self.description = f"{self.name}, {self.epithet}, god of {self.domain}, is symbolized by a {self.symbol}."

    def generate_name(self):
        parts = [
            random.choice(["Va", "Ze", "Mor", "Tha", "El", "Ny", "Ka", "Ura"]),
            random.choice(["th", "dr", "lor", "mir", "rax", "sul", "ven"]),
            random.choice(["a", "os", "eth", "ion", "ir", "oth"])
        ]
        return ''.join(parts)

    def get_profile(self):
        return {
            "name": self.name,
            "domain": self.domain,
            "symbol": self.symbol,
            "epithet": self.epithet,
            "description": self.description
        }

def generate_gods(n=5):
    return [God().get_profile() for _ in range(n)]
