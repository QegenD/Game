# secrets_system.py — система компромата
class Secret:
    def __init__(self, holder, content):
        self.holder = holder
        self.content = content
        self.revealed = False

class SecretsManager:
    def __init__(self):
        self.secrets = []

    def add_secret(self, holder, content):
        self.secrets.append(Secret(holder, content))

    def reveal_secret(self, index):
        self.secrets[index].revealed = True
