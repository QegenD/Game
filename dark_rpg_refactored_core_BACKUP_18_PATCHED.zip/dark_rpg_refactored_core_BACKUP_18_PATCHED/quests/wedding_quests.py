
# wedding_quests.py — Квесты, связанные со свадьбами NPC

import random

def generate_wedding_quest(npc1, npc2, reason):
    quests = []

    if reason == "любовь":
        quests.append({
            "type": "help_lovers",
            "title": f"Помоги любви между {npc1['name']} и {npc2['name']}",
            "description": f"{npc1['name']} и {npc2['name']} хотят быть вместе, но их династии враждуют. Помоги устроить тайную свадьбу или убедить их семьи."
        })
        quests.append({
            "type": "prevent_tragedy",
            "title": f"Защити влюблённых от трагедии",
            "description": f"Они хотят сбежать, но их могут убить. Устрой побег или переговоры с главами династий."
        })

    if reason == "политический союз для прекращения конфликта":
        quests.append({
            "type": "negotiate_union",
            "title": f"Переговоры о браке между {npc1['dynasty']} и {npc2['dynasty']}",
            "description": f"Союз может закончить войну. Помоги провести дипломатические переговоры или подкупи влиятельных лиц."
        })
        quests.append({
            "type": "sabotage_wedding",
            "title": f"Сорви политическую свадьбу",
            "description": f"Не все довольны союзом между {npc1['dynasty']} и {npc2['dynasty']}. Некоторые хотят сорвать свадьбу любой ценой."
        })

    return random.choice(quests)
