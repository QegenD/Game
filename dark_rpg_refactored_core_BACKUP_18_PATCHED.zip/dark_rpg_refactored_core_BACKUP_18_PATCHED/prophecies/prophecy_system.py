
# prophecy_system.py — генерация пророчеств

import random

PROPHECY_THEMES = [
    "возвращение древнего зла",
    "падение империи",
    "сошествие кровавой луны",
    "восстание изгнанных богов",
    "появление избранного"
]

def generate_prophecy():
    theme = random.choice(PROPHECY_THEMES)
    return f"⚠️ Пророчество гласит: {theme.capitalize()} изменит ход истории."
