
# betting_system.py — система ставок на турнир

import random

class TournamentBetting:
    def __init__(self, player_gold):
        self.bets = {}
        self.player_gold = player_gold

    def place_bet(self, npc_name, amount):
        if amount > self.player_gold:
            print("Not enough gold!")
            return False
        self.bets[npc_name] = amount
        self.player_gold -= amount
        print(f"Bet placed: {amount} gold on {npc_name}")
        return True

    def resolve_bets(self, winner_name):
        if winner_name in self.bets:
            reward = self.bets[winner_name] * 3
            self.player_gold += reward
            print(f"You won the bet! +{reward} gold")
        else:
            print("You lost the bet.")
        self.bets.clear()
        return self.player_gold
