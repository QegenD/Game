
# mourning_system.py — траур, месть, похороны

def handle_death(npc, world):
    print(f"{npc.name} has died. Checking for mourners...")
    mourners = []

    for other in world.npcs:
        if npc.id in getattr(other, "family", []) or npc.id in getattr(other, "friends", []):
            mourners.append(other)

    for mourner in mourners:
        mourner.set_mood("grieving")
        mourner.status_effects.append("mourning")
        if hasattr(mourner, "dialogue"):
            mourner.dialogue.append(f"I can't believe {npc.name} is gone...")
        print(f"{mourner.name} mourns the death of {npc.name}.")

        # Возможная месть
        if hasattr(npc, "killer") and random.random() < 0.3:
            mourner.goals.append("avenge_" + npc.killer.name)
            print(f"{mourner.name} swears vengeance on {npc.killer.name}!")

    return mourners
