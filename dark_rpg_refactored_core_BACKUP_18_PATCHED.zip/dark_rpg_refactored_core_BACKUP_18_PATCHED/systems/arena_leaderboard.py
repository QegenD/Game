
# arena_leaderboard.py — таблица бойцов арены

class ArenaLeaderboard:
    def __init__(self):
        self.records = {}  # npc_id: {wins, losses, kills}

    def record_fight(self, npc, won=False, killed=False):
        if npc.id not in self.records:
            self.records[npc.id] = {
                "name": npc.name,
                "wins": 0,
                "losses": 0,
                "kills": 0
            }

        if won:
            self.records[npc.id]["wins"] += 1
        else:
            self.records[npc.id]["losses"] += 1

        if killed:
            self.records[npc.id]["kills"] += 1

    def get_top_fighters(self, count=5):
        sorted_records = sorted(
            self.records.values(),
            key=lambda x: (x["wins"], x["kills"]),
            reverse=True
        )
        return sorted_records[:count]

    def print_leaderboard(self):
        top = self.get_top_fighters()
        print("🏆 Arena Leaderboard:")
        for i, entry in enumerate(top, 1):
            print(f"{i}. {entry['name']} — Wins: {entry['wins']} | Kills: {entry['kills']} | Losses: {entry['losses']}")
