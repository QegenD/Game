
# npc_dialogue.py — диалоги и реакции NPC

from core.visual_trigger import generate_npc_portrait

class NPCDialogue:
    def __init__(self, npc_name):
        self.npc_name = npc_name
        self.emotion = "neutral"

    def speak(self, phrase, emotion="neutral"):
        self.emotion = emotion
        generate_npc_portrait(self.npc_name, emotion)
        return f"{self.npc_name} ({emotion}): {phrase}"
    