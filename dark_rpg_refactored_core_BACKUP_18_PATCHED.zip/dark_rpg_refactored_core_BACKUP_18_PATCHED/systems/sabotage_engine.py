
# sabotage_engine.py — саботаж и грязные трюки на турнире

import random

class SabotageEngine:
    def __init__(self, npc):
        self.npc = npc

    def attempt_sabotage(self, target):
        chance = 10
        if self.npc.npc_class == "Spy":
            chance += 25
        if self.npc.race == "Demon":
            chance += 15

        success = random.randint(1, 100) <= chance
        if success:
            print(f"{self.npc.name} sabotaged {target.name}!")
            return True
        else:
            print(f"{self.npc.name} failed to sabotage {target.name}.")
            return False
