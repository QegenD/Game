
# champion_portraits.py — SD-портреты чемпионов

from core.auto_image_generator import AutoImageGenerator

class ChampionPortraitManager:
    def __init__(self):
        self.generator = AutoImageGenerator()
        self.gallery = {}

    def generate_portrait(self, npc):
        description = f"Portrait of {npc.name}, the {npc.race} {npc.npc_class}, tournament champion"
        image_id = self.generator.generate("portrait", description, emotion="pride")
        self.gallery[npc.name] = image_id
        print(f"[Portrait] Generated for {npc.name}")
        return image_id
