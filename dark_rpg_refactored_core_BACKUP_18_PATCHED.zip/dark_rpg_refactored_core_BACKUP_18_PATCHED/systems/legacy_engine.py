
# legacy_engine.py — смерть и наследие

from core.visual_trigger import generate_death_legacy

class LegacyEngine:
    def __init__(self):
        self.legacies = []

    def record_death(self, npc, cause, will=None):
        legacy = {
            "name": npc,
            "cause": cause,
            "will": will or "Nothing left behind.",
        }
        self.legacies.append(legacy)
        generate_death_legacy(npc, cause)

    def get_legacy(self, npc):
        return [l for l in self.legacies if l["name"] == npc]
