
# cult_system.py — тёмные культы, ритуалы, влияние на NPC

import random

class CultSystem:
    def __init__(self):
        self.members = []

    def recruit(self, npc):
        if npc.faith < 3:
            npc.cultist = True
            self.members.append(npc)
            print(f"{npc.name} was initiated into the cult!")

    def perform_ritual(self, location):
        print(f"A dark ritual begins at {location}...")
        if random.randint(1, 100) < 40:
            print("A demon has been summoned!")
        else:
            print("The ritual failed. Blood was spilled in vain.")
