
# race_class_system.py — расширенная система рас и классов

import random

RACES = {
    "Human": {
        "traits": ["adaptable", "curious"],
        "biases": {"Elf": +0, "Demon": -1, "Beastkin": -1}
    },
    "Elf": {
        "traits": ["graceful", "ritualistic"],
        "biases": {"Human": 0, "Demon": -2, "Beastkin": -1}
    },
    "Demon": {
        "traits": ["lustful", "manipulative"],
        "biases": {"Human": +1, "Elf": -1, "Beastkin": 0}
    },
    "Beastkin": {
        "traits": ["instinctual", "feral"],
        "biases": {"Elf": -2, "Human": -1, "Demon": +1}
    }
}

CLASSES = {
    "Witch": {
        "skills": {"rituals": 5, "manipulation": 2},
        "perks": ["vision", "curse"]
    },
    "Knight": {
        "skills": {"combat": 5, "honor": 3},
        "perks": ["leadership", "armor_training"]
    },
    "Seductress": {
        "skills": {"seduction": 5, "manipulation": 3},
        "perks": ["sex_control", "body_language"]
    },
    "Spy": {
        "skills": {"manipulation": 4, "stealth": 5},
        "perks": ["disguise", "eavesdrop"]
    }
}

def generate_race_class():
    race = random.choice(list(RACES.keys()))
    cls = random.choice(list(CLASSES.keys()))
    return race, cls
