
# bloodline_tracker.py — династии и кровь

class BloodlineTracker:
    def __init__(self):
        self.bloodlines = {}

    def register_birth(self, child, parents):
        self.bloodlines[child] = {"parents": parents, "traits": self.inherit(parents)}

    def inherit(self, parents):
        traits = []
        for p in parents:
            if p in self.bloodlines:
                traits += self.bloodlines[p].get("traits", [])
        return list(set(traits))[:3]  # максимум 3 наследуемых черты

    def get_lineage(self, name):
        if name in self.bloodlines:
            return self.bloodlines[name]
        return {}
