
# skill_system.py — система навыков и опыта

class SkillSystem:
    def __init__(self):
        self.skills = {
            "combat": 0,
            "seduction": 0,
            "alchemy": 0,
            "manipulation": 0,
            "rituals": 0
        }

    def gain_xp(self, skill, amount):
        if skill in self.skills:
            self.skills[skill] += amount
            return f"{skill} +{amount} XP"
        return "Unknown skill"

    def get_level(self, skill):
        xp = self.skills.get(skill, 0)
        return xp // 10  # 10 XP = 1 level
