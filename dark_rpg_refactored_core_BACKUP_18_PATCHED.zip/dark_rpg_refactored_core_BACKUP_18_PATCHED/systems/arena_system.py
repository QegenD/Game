
# arena_system.py — гладиаторские бои, ставки, слава

from combat.combat_engine import CombatEngine
from progression.xp_system import XPSystem

def arena_fight(npc1, npc2, spectators=None):
    print(f"⚔️ Arena fight: {npc1.name} vs {npc2.name}")
    combat = CombatEngine(npc1, npc2)
    attacker, defender = npc1, npc2

    while True:
        if combat.perform_turn():
            winner = attacker
            loser = defender
            break
        attacker, defender = defender, attacker
        combat.attacker = attacker
        combat.defender = defender

    print(f"🏆 {winner.name} wins the arena!")
    XPSystem(winner).award_xp(40)
    XPSystem(loser).award_xp(10 if loser.status != "dead" else 0)

    if spectators:
        for s in spectators:
            print(f"{s.name} cheers or mourns...")

    return winner
