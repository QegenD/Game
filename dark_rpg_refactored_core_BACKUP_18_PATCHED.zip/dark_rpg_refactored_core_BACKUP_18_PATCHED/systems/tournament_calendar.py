
# tournament_calendar.py — Календарь турниров и рейтинг чемпионов

import datetime

class TournamentCalendar:
    def __init__(self):
        self.upcoming_tournaments = []  # список (дата, город)
        self.champion_log = []          # (имя, город, дата)
        self.rankings = {}

    def schedule_tournament(self, city, days_from_now):
        date = datetime.date.today() + datetime.timedelta(days=days_from_now)
        self.upcoming_tournaments.append((date, city))

    def register_champion(self, name, city):
        today = datetime.date.today()
        self.champion_log.append((name, city, today))
        self.rankings[name] = self.rankings.get(name, 0) + 1
        print(f"{name} is registered as champion of {city} on {today}")

    def get_rankings(self):
        return sorted(self.rankings.items(), key=lambda x: -x[1])
