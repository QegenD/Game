
# faction_conflict.py — столкновения между светом и тьмой

def resolve_conflict(city, factions):
    if "Holy Order" in factions and any("Cult" in f for f in factions):
        print(f"A conflict erupts in {city} between the Holy Order and dark cults!")
        outcome = "Holy Order prevails" if factions["Holy Order"] > factions["Cult"] else "Cults corrupt the city"
        print(f"Conflict result: {outcome}")
        return outcome
    else:
        print(f"No holy conflict in {city}.")
        return "peace"
