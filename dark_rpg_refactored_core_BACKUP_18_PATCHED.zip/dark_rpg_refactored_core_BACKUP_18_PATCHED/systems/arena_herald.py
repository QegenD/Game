
# arena_herald.py — Турнирная "газета", создающая сводку событий

from datetime import date
from core.auto_image_generator import AutoImageGenerator

class ArenaHerald:
    def __init__(self):
        self.issues = []
        self.generator = AutoImageGenerator()

    def publish(self, city, winner, scandal=None, victim=None):
        today = date.today().isoformat()
        headline = f"{today} — Victory in {city}!"
        content = f"{winner.name} has emerged as the Champion of {city}."

        if scandal and victim:
            content += f" Scandal strikes as {victim.name} was allegedly sabotaged!"

        issue = {
            "date": today,
            "city": city,
            "champion": winner.name,
            "scandal": scandal,
            "content": content
        }
        self.issues.append(issue)
        print(f"[Arena Herald] Published: {headline}")
        print(content)

        # Визуализация
        self.generator.generate("news", f"Newspaper showing {winner.name} as champion of {city}", emotion="fame")
