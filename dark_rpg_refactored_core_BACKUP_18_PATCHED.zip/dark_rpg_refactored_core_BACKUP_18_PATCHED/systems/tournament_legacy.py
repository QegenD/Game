
# tournament_legacy.py — последствия побед в турнирах (политика, влияние, поклонники)

import random

class TournamentLegacy:
    def __init__(self, champion, all_npcs):
        self.champion = champion
        self.all_npcs = all_npcs

    def apply_political_impact(self):
        if hasattr(self.champion, "faction"):
            self.champion.faction.reputation += 5
            self.champion.political_status = "Rising Star"
            print(f"{self.champion.name} gains political influence in {self.champion.faction.name}!")

    def create_fans_and_rivals(self):
        fans = []
        rivals = []
        for npc in self.all_npcs:
            if npc == self.champion:
                continue
            if random.randint(0, 100) < 25:
                npc.relationships[self.champion.name] = "admirer"
                fans.append(npc.name)
            elif random.randint(0, 100) < 15:
                npc.relationships[self.champion.name] = "jealous"
                rivals.append(npc.name)
        print(f"Fans of {self.champion.name}: {fans}")
        print(f"Rivals of {self.champion.name}: {rivals}")
