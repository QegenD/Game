
# slavery_system.py — рабство, рынок рабов, освобождение, мятежи

class SlaverySystem:
    def __init__(self):
        self.slaves = []

    def enslave(self, npc, owner):
        npc.status = "enslaved"
        npc.owner = owner
        self.slaves.append(npc)
        print(f"{npc.name} was enslaved by {owner.name}.")

    def free(self, npc):
        npc.status = "free"
        npc.owner = None
        if npc in self.slaves:
            self.slaves.remove(npc)
        print(f"{npc.name} was freed.")

    def sell(self, npc, buyer):
        if npc.status != "enslaved":
            print(f"{npc.name} is not a slave.")
            return
        npc.owner = buyer
        print(f"{npc.name} was sold to {buyer.name}.")

    def revolt(self):
        revolters = [npc for npc in self.slaves if npc.loyalty < 3]
        for npc in revolters:
            print(f"{npc.name} starts a revolt against their owner!")
