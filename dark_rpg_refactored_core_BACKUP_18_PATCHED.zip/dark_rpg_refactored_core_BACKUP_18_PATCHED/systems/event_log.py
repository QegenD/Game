
# event_log.py — журнал игрока

import datetime

class EventLog:
    def __init__(self):
        self.entries = []

    def log(self, category, text):
        timestamp = datetime.datetime.now().isoformat()
        self.entries.append({
            "time": timestamp,
            "category": category,
            "text": text
        })

    def get_all(self):
        return self.entries[-50:]  # последние 50 записей

    def get_by_category(self, category):
        return [e for e in self.entries if e["category"] == category]
