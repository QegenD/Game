
# tournament_system.py — сетка турнира, календарь, этапы

import random
from combat.arena_system import arena_fight

class Tournament:
    def __init__(self, participants, city, date):
        self.city = city
        self.date = date
        self.participants = participants
        self.winner = None
        self.rounds = []

    def run_tournament(self):
        print(f"🏟️ Tournament in {self.city} begins on {self.date} with {len(self.participants)} fighters!")
        fighters = self.participants[:]
        random.shuffle(fighters)

        while len(fighters) > 1:
            round_fights = []
            for i in range(0, len(fighters), 2):
                if i+1 < len(fighters):
                    winner = arena_fight(fighters[i], fighters[i+1])
                    round_fights.append((fighters[i], fighters[i+1], winner))
                    fighters[i].status_effects.append("tournament_fought")
                else:
                    round_fights.append((fighters[i], None, fighters[i]))
            fighters = [fight[2] for fight in round_fights]
            self.rounds.append(round_fights)

        self.winner = fighters[0]
        print(f"👑 {self.winner.name} is crowned the Champion of {self.city}!")
        return self.winner
