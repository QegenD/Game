
# alchemy_engine.py — создание зелий и алхимических эффектов

import random

class AlchemyEngine:
    def __init__(self):
        self.ingredients = []
        self.recipes = {
            ("nightshade", "mandrake"): "Potion of Lust",
            ("wolfsbane", "moonroot"): "Potion of Fury",
            ("rose", "blood"): "Love Elixir",
        }

    def mix(self, ing1, ing2):
        key = tuple(sorted([ing1, ing2]))
        potion = self.recipes.get(key)
        if potion:
            effect = random.choice(["strong", "mild", "unstable"])
            return {"name": potion, "effect": effect}
        else:
            return {"name": "Unknown Brew", "effect": "???", "dangerous": True}
