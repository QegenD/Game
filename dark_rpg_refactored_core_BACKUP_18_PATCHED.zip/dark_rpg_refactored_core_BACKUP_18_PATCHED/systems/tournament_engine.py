
# tournament_engine.py — Турниры в крупных городах

import random
from core.auto_image_generator import AutoImageGenerator

class Tournament:
    def __init__(self, city, participants):
        self.city = city
        self.participants = participants  # Список NPC (вкл. игрока)
        self.generator = AutoImageGenerator()
        self.champion = None
        self.history = []

    def start(self):
        print(f"A grand tournament begins in {self.city}!")
        self.generator.generate("scene", f"Opening ceremony of the tournament in {self.city}", emotion="epic")

        while len(self.participants) > 1:
            p1 = self.participants.pop(0)
            p2 = self.participants.pop(0)
            winner = self.fight(p1, p2)
            self.participants.append(winner)
            print(f"{winner.name} advances to the next round!")

        self.champion = self.participants[0]
        print(f"{self.champion.name} is the Champion of {self.city}!")
        self.generator.generate("scene", f"Victory of {self.champion.name} in the {self.city} tournament", emotion="glory")
        return self.champion

    def fight(self, npc1, npc2):
        score1 = random.randint(1, 20) + self._class_bonus(npc1)
        score2 = random.randint(1, 20) + self._class_bonus(npc2)
        duel_description = f"{npc1.name} vs {npc2.name} in the arena"
        self.generator.generate("scene", duel_description, emotion="tense")
        self.history.append((npc1.name, npc2.name, npc1.race, npc2.race))
        return npc1 if score1 >= score2 else npc2

    def _class_bonus(self, npc):
        if npc.npc_class == "Knight":
            return 3
        elif npc.npc_class == "Spy":
            return 1
        elif npc.npc_class == "Witch":
            return 2
        elif npc.npc_class == "Seductress":
            return 1
        elif npc.npc_class == "Beastkin":
            return 2
        return 0
