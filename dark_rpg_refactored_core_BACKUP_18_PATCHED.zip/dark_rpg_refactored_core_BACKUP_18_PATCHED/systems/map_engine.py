
# map_engine.py — переход между локациями с генерацией визуала

from core.visual_trigger import generate_location_image

class MapEngine:
    def __init__(self):
        self.current_location = "Unknown"

    def move_to(self, location, mood="mysterious"):
        self.current_location = location
        generate_location_image(location, mood)
        return f"You moved to {location}."
    