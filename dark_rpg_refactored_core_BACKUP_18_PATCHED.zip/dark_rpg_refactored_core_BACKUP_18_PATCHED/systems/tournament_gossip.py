
# tournament_gossip.py — обсуждение турнира NPC

import random

TOURNAMENT_COMMENTS = [
    "{winner} was unstoppable in the arena!",
    "Did you see how {loser} fell? Shameful!",
    "Rumor is {winner} used dark magic...",
    "They say {loser} was sabotaged before the fight.",
    "I bet all my coin on {winner}, drinks on me!"
]

class TournamentGossip:
    def __init__(self, npcs):
        self.npcs = npcs

    def spread_gossip(self, winner, loser):
        for npc in self.npcs:
            comment = random.choice(TOURNAMENT_COMMENTS).format(winner=winner.name, loser=loser.name)
            npc.hear_gossip(comment)
            print(f"{npc.name} heard: "{comment}"")
