# npc_emotions.py — потребности и эмоции
class EmotionState:
    def __init__(self):
        self.happiness = 0.5
        self.anger = 0.0
        self.fear = 0.0

    def tick(self, events):
        for e in events:
            if e == "threat": self.fear += 0.1
            if e == "gift": self.happiness += 0.1
