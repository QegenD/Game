# devtools.py — режим разработчика
is_debug_mode = False

def toggle_debug():
    global is_debug_mode
    is_debug_mode = not is_debug_mode
    return is_debug_mode
