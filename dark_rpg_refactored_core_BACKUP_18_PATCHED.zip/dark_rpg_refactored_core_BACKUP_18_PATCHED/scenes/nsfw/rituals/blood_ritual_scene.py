
# blood_ritual_scene.py — NSFW ритуал с визуализацией

import random

def generate_blood_ritual_scene(player, participants, god):
    description = f"{player.name} и {', '.join([p.name for p in participants])} совершают ритуал во имя {god['name']}."
    pose = random.choice(["жертвенный круг", "плотская жертва", "ритуальный акт", "омовение кровью"])
    intensity = random.randint(6, 10)

    image_prompt = f"NSFW сцена: {pose}, тёмный храм, кровь, символы {god['domain']}, участники в экстазе, реализм"

    return {
        "text": description + f" Позы: {pose}, интенсивность: {intensity}.",
        "image_prompt": image_prompt,
        "participants": [p.name for p in participants]
    }
