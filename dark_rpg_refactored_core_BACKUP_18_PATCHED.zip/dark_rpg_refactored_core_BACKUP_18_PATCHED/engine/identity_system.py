
# [identity_system.py] — система маскировки и разоблачения личности

class Identity:
    def __init__(self, true_name, disguise_name=None, disguise_traits=None):
        self.true_name = true_name
        self.disguise_name = disguise_name or true_name
        self.disguise_traits = disguise_traits or {}
        self.revealed = False

    def is_disguised(self):
        return self.true_name != self.disguise_name and not self.revealed

    def reveal_identity(self):
        self.revealed = True
        return self.true_name

    def current_identity(self):
        if self.revealed:
            return self.true_name
        return self.disguise_name


class IdentitySystem:
    def __init__(self):
        self.identities = {}  # npc_id: Identity

    def set_identity(self, npc_id, true_name, disguise_name=None, disguise_traits=None):
        self.identities[npc_id] = Identity(true_name, disguise_name, disguise_traits)

    def get_current_identity(self, npc_id):
        identity = self.identities.get(npc_id)
        if identity:
            return identity.current_identity()
        return None

    def reveal(self, npc_id):
        identity = self.identities.get(npc_id)
        if identity and identity.is_disguised():
            return identity.reveal_identity()
        return None

    def is_disguised(self, npc_id):
        identity = self.identities.get(npc_id)
        return identity.is_disguised() if identity else False
