
# rumor_reflection_engine.py — NPC-отражения и слухи о герое

import random

class RumorReflectionEngine:
    def __init__(self, world):
        self.world = world
        self.hero_log = []  # список действий игрока

    def log_player_action(self, action):
        self.hero_log.append(action)

    def analyze_and_reflect(self):
        for npc in self.world.npcs:
            if not hasattr(npc, "reflection_state"):
                npc.reflection_state = {}

            impact = self._analyze_impact(npc)
            if impact == "admiration":
                npc.reflection_state["goal"] = "follow_hero"
                npc.set_mood("inspired")
            elif impact == "vengeful":
                npc.reflection_state["goal"] = "oppose_hero"
                npc.set_mood("angry")
            elif impact == "curious":
                npc.reflection_state["goal"] = "investigate_hero"
                npc.set_mood("curious")

    def _analyze_impact(self, npc):
        relevant_actions = [a for a in self.hero_log if npc.faction != a.get("faction")]

        if not relevant_actions:
            return random.choice(["neutral", "curious"])

        emotional_weight = 0
        for action in relevant_actions:
            if action["type"] == "violence":
                emotional_weight += 2 if action["target"] == npc.faction else 1
            elif action["type"] == "heroic":
                emotional_weight -= 2
            elif action["type"] == "seduction":
                emotional_weight += 1

        if emotional_weight > 3:
            return "vengeful"
        elif emotional_weight < -1:
            return "admiration"
        else:
            return "curious"

    def generate_rumors(self):
        rumors = []
        for action in self.hero_log:
            if random.random() < 0.4:
                text = f"Rumor spreads: the hero once {action['type']} at {action['location']}..."
                rumors.append(text)
        return rumors
