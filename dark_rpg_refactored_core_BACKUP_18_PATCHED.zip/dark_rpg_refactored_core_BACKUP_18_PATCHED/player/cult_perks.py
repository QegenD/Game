
# cult_perks.py — бонусы для игрока при вступлении в культ

def apply_cult_perks(player):
    if player.faction == "cult":
        if "dark_vision" not in player.abilities:
            player.abilities.append("dark_vision")

        if "ritual_magic" not in player.skills:
            player.skills.append("ritual_magic")

        if "corruption" not in player.status_effects:
            player.status_effects.append("corruption")

        player.reputation["cultists"] = 10
        player.max_sanity -= 10  # Чем больше силы — тем ближе безумие
        return True
    return False
