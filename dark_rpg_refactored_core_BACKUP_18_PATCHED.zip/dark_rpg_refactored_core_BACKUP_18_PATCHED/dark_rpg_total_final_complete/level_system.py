def gain_experience(player, amount):
    player['xp'] += amount
    level_up = False
    while player['xp'] >= 100:
        player['xp'] -= 100
        player['level'] += 1
        level_up = True
        increase_stats(player)
    return level_up

def increase_stats(player):
    player['hp'] += 5
    player['attack'] += 1
    player['defense'] += 1
    player['charisma'] += 1
