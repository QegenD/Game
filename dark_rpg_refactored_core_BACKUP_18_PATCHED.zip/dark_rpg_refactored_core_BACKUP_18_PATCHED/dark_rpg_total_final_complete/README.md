# Dark RPG: Локальная офлайн RPG-песочница

## Возможности
- Генерация NPC, фракций, слухов и событий
- AI-дирижёр мира (`world_master.py`)
- Пророчества и их влияние (`prophecies.py`)
- Хроника мира (`world_log.json`)
- Социальная сеть NPC (`social_network.py`)
- Визуализация мира (`visualizer.py`)

## Запуск
1. Установите зависимости: `pip install -r requirements.txt`
2. Убедитесь, что Ollama LLM работает на `http://localhost:11434`
3. Запустите игру: `python main.py`

## Настройки
Все настройки в `config.py`