
# world_log.py
class WorldLog:
    def __init__(self):
        self.events = []

    def log_event(self, description):
        self.events.append(description)

    def get_log(self):
        return list(self.events)
