
# investigation_system.py

import random

class Investigation:
    def __init__(self, intrigues):
        self.intrigues = intrigues
        self.progress = {}
        self.results = []

    def start_investigation(self, intrigue):
        self.progress[intrigue] = 0

    def advance_investigations(self):
        to_complete = []
        for intrigue, value in self.progress.items():
            self.progress[intrigue] += random.randint(5, 20)
            if self.progress[intrigue] >= 100:
                to_complete.append(intrigue)
        for intrigue in to_complete:
            self.results.append(f"Интрига раскрыта: {intrigue.describe()}")
            del self.progress[intrigue]

    def get_progress_report(self):
        return {i.describe(): p for i, p in self.progress.items()}

    def get_results(self):
        return self.results
