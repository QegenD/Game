
# logic/town_rituals.py

import random

class RitualCenter:
    def __init__(self, town_name):
        self.town_name = town_name
        self.ritual_ready = False
        self.current_ritual = None

    def prepare_ritual(self, anomaly):
        if anomaly and anomaly != "отсутствует":
            self.current_ritual = f"Ритуал подавления: {anomaly}"
            self.ritual_ready = random.choice([True, False])
        else:
            self.current_ritual = None
            self.ritual_ready = False

    def perform_ritual(self):
        if self.ritual_ready and self.current_ritual:
            result = f"В {self.town_name} успешно проведён {self.current_ritual}"
            self.ritual_ready = False
            self.current_ritual = None
            return result
        return f"В {self.town_name} не удалось провести ритуал."

    def get_ritual_status(self):
        return {
            "город": self.town_name,
            "ритуал": self.current_ritual or "нет",
            "готов": self.ritual_ready
        }
