
from logic.noble_intrigue import NobleIntrigueSystem

class GameExtensions(GameExtensions):
    def __init__(self):
        super().__init__()
        self.noble_intrigue = NobleIntrigueSystem()

    def trigger_coup(self, noble_group):
        return self.noble_intrigue.plan_coup(noble_group)

    def trigger_assassination_attempt(self, target_npc):
        return self.noble_intrigue.arrange_assassination(target_npc)

    def assign_order_rank(self, npc):
        return self.noble_intrigue.assign_knightly_order(npc)

    def assign_court_council_role(self, npc):
        return self.noble_intrigue.assign_court_position(npc)

    def generate_knightly_conflict(self):
        return self.noble_intrigue.generate_knightly_conflict()

    def generate_knightly_tournament(self):
        return self.noble_intrigue.organize_tournament()
