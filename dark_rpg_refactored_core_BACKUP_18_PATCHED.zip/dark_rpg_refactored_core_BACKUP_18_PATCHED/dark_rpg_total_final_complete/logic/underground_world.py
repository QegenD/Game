
# logic/underground_world.py

import random

class CultsAndReligions:
    def generate_cult(self):
        names = ["Око Тени", "Глас Ночного Пламени", "Последователи Странника"]
        goals = ["оживить древнего бога", "освободить мир от магии", "уничтожить королей"]
        return f"Культ '{random.choice(names)}' с целью: {random.choice(goals)}"

class AlchemyAndContraband:
    def generate_potion_or_poison(self):
        return random.choice(["Зелье невидимости", "Яд с эффектом подчинения", "Феромон страсти"])

    def smuggling_event(self, item, city):
        return f"Контрабандисты проносят '{item}' в {city}"

class EspionageSystem:
    def spy_action(self, faction):
        acts = ["украли документы", "заменили советника", "взорвали склады"]
        return f"Шпионы нанесли удар по {faction}: {random.choice(acts)}"

class NPCMigration:
    def migrate_npcs(self, from_city, to_city, reason):
        return f"Жители из {from_city} массово перебираются в {to_city} из-за {reason}"

class ArcheologyAndRelics:
    def discover_ruins(self, region):
        finds = ["гробница древнего мага", "забытая библиотека", "храм предков"]
        return f"В {region} обнаружено: {random.choice(finds)}"

class GeneratedLore:
    def create_scroll_or_legend(self):
        themes = ["пророчество о катастрофе", "письмо любовника-ассасина", "легенда о Золотом Лесе"]
        return f"Найдено: {random.choice(themes)}"
