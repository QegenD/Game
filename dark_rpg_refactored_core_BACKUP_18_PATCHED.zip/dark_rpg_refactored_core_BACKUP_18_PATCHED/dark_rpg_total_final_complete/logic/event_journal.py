
# logic/event_journal.py

class EventJournal:
    def __init__(self):
        self.entries = []

    def log(self, entry):
        self.entries.append(entry)

    def get_log(self, limit=10):
        return self.entries[-limit:]
