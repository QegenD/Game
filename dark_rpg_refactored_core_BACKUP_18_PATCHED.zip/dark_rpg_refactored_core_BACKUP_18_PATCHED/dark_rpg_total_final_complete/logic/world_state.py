
# world_state.py
import random

class WorldState:
    def __init__(self):
        self.phase = "новолуние"
        self.corruption_level = 0

    def update_phase(self):
        self.phase = random.choice(["новолуние", "полнолуние", "затмение", "кровавая луна"])

    def apply_corruption(self, amount):
        self.corruption_level = max(0, min(100, self.corruption_level + amount))

    def get_state(self):
        return {
            "фаза": self.phase,
            "порча": self.corruption_level
        }
