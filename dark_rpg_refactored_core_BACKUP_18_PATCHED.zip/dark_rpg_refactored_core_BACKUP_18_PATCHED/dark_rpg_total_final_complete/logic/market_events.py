
# logic/market_events.py

import random

class MarketEventSystem:
    def __init__(self):
        self.events = {}
        self.event_pool = [
            "ярмарка",
            "запрет торговли",
            "контрабанда",
            "нормальный рынок"
        ]

    def generate_events(self, towns):
        for town in towns:
            self.events[town] = random.choices(
                self.event_pool, weights=[1, 1, 1, 3], k=1
            )[0]

    def get_event(self, town):
        return self.events.get(town, "нормальный рынок")

    def get_all_events(self):
        return self.events
