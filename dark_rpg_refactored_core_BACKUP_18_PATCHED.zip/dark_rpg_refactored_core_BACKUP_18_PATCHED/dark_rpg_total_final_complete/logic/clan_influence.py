
# logic/clan_influence.py

import random

class ClanReputation:
    def __init__(self):
        self.reputation = {}  # {имя_клана: -100 до +100}

    def initialize_for_clans(self, clans):
        for clan in clans:
            self.reputation[clan.name] = random.randint(-20, 20)

    def adjust(self, clan_name, amount):
        if clan_name in self.reputation:
            self.reputation[clan_name] = max(-100, min(100, self.reputation[clan_name] + amount))

    def get(self, clan_name):
        return self.reputation.get(clan_name, 0)

    def get_all(self):
        return self.reputation
