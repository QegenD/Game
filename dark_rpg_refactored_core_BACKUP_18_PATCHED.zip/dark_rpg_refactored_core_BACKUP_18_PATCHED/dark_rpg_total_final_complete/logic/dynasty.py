
# logic/dynasty.py

import random

class Dynasty:
    def __init__(self, name):
        self.name = name
        self.age = random.randint(100, 1000)
        self.power = random.randint(50, 100)
        self.symbol = random.choice(["дракон", "солнце", "ворон", "змей", "звезда", "кровь"])
        self.lineage_trait = random.choice(["древняя магия", "божественное право", "проклятая кровь", "избранность"])

    def get_summary(self):
        return {
            "name": self.name,
            "age": self.age,
            "symbol": self.symbol,
            "trait": self.lineage_trait,
            "power": self.power
        }

class WorldDynasties:
    def __init__(self):
        self.dynasties = self.generate_dynasties()

    def generate_dynasties(self):
        base_names = ["Таргус", "Элейн", "Мальвис", "Нур-Хаим", "Рахтель", "Олдант"]
        return [Dynasty(name) for name in base_names]

    def list_dynasties(self):
        return [d.get_summary() for d in self.dynasties]
