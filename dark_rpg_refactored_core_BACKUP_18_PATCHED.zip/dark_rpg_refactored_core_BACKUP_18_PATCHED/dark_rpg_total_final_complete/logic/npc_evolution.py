
# logic/npc_evolution.py

import random

class NPCEvolution:
    def evolve_traits(self, npc):
        traits = npc.get("traits", [])
        if "трусливый" in traits and random.random() < 0.3:
            traits.remove("трусливый")
            traits.append("решительный")
        if "подчинённый" in traits and random.random() < 0.2:
            traits.remove("подчинённый")
            traits.append("амбициозный")
        npc["traits"] = traits
        return npc

    def evolve_job(self, npc):
        job = npc.get("job", "крестьянин")
        evolutions = {
            "крестьянин": "наёмник",
            "наёмник": "капитан",
            "учёный": "архимаг",
            "вор": "лидер гильдии",
        }
        if job in evolutions and random.random() < 0.4:
            npc["job"] = evolutions[job]
        return npc

    def grow_relationship(self, npc, player_actions):
        relationship = npc.get("relationship", 0)
        for act in player_actions:
            if act == "спас":
                relationship += 10
            elif act == "предал":
                relationship -= 15
            elif act == "подарок":
                relationship += 5
        npc["relationship"] = max(min(relationship, 100), -100)
        return npc
