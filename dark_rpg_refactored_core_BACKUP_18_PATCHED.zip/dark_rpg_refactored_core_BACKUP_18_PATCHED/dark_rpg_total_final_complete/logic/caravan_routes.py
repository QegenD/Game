
# logic/caravan_routes.py

import random

class CaravanSystem:
    def __init__(self, towns):
        self.routes = []
        self.towns = towns
        self.update_caravans()

    def update_caravans(self):
        self.routes = []
        for _ in range(random.randint(2, 5)):
            origin, destination = random.sample(self.towns, 2)
            goods = random.choice(["еда", "вода", "артефакт", "зелье"])
            delay = random.choice([0, 1, 2])  # дни задержки
            self.routes.append({
                "из": origin,
                "в": destination,
                "товар": goods,
                "задержка": delay
            })

    def get_routes(self):
        return self.routes
