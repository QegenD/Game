
# logic/conspiracies.py

import random

class ConspiracySystem:
    def __init__(self, npcs):
        self.npcs = npcs
        self.active_conspiracies = []

    def seed_conspiracies(self):
        candidates = [npc for npc in self.npcs if npc.get("role") in ["жрец", "маг", "дворянин", "советник"]]
        random.shuffle(candidates)
        for npc in candidates[:3]:
            target = random.choice(["Король", "Совет", "Глава клана", "Церковь", "Гильдия"])
            plan = random.choice(["убийство", "смена власти", "подделка пророчества", "перехват финансирования"])
            conspiracy = {
                "initiator": npc["name"],
                "target": target,
                "plan": plan,
                "status": "тайно"
            }
            self.active_conspiracies.append(conspiracy)

    def advance_conspiracies(self):
        outcomes = []
        for conspiracy in self.active_conspiracies:
            roll = random.random()
            if roll < 0.3:
                conspiracy["status"] = "провалено"
                outcomes.append(f"Заговор {conspiracy['plan']} против {conspiracy['target']} провалился.")
            elif roll < 0.6:
                conspiracy["status"] = "раскрыто"
                outcomes.append(f"Заговор против {conspiracy['target']} раскрыт! Начаты преследования.")
            else:
                conspiracy["status"] = "успешно"
                outcomes.append(f"Заговор {conspiracy['plan']} против {conspiracy['target']} успешно завершён.")
        return outcomes

    def get_all_conspiracies(self):
        return self.active_conspiracies
