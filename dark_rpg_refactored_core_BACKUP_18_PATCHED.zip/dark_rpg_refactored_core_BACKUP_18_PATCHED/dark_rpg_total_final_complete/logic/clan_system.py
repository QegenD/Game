
# logic/clan_system.py

import random

class Clan:
    def __init__(self, name, influence, interests, cities_controlled):
        self.name = name
        self.influence = influence  # 1-100
        self.interests = interests  # например: "магия", "политика", "контрабанда"
        self.cities_controlled = cities_controlled

    def controls_city(self, city):
        return city in self.cities_controlled

    def is_interested_in(self, topic):
        return topic in self.interests

class ClanSystem:
    def __init__(self, all_cities):
        self.clans = []
        self.generate_clans(all_cities)

    def generate_clans(self, cities):
        names = ["Тень Заката", "Пламя Порядка", "Рука Знания", "Гильдия Безликих"]
        interests_pool = [["магия", "исследования"], ["контрабанда", "честь"], ["политика", "интриги"], ["власть", "чёрный рынок"]]
        random.shuffle(cities)

        for i, name in enumerate(names):
            controlled = random.sample(cities, k=random.randint(1, 2))
            self.clans.append(
                Clan(name, influence=random.randint(30, 90), interests=interests_pool[i], cities_controlled=controlled)
            )

    def get_clans_for_city(self, city):
        return [clan for clan in self.clans if clan.controls_city(city)]

    def get_all_clans(self):
        return self.clans
