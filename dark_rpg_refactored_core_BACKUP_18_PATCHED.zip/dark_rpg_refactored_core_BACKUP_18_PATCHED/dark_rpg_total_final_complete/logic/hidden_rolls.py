
# hidden_rolls.py
import random

class HiddenCheck:
    def __init__(self, base_chance, modifier=0):
        self.base_chance = base_chance
        self.modifier = modifier

    def roll(self):
        result = random.randint(1, 100)
        success = result + self.modifier >= self.base_chance
        return {"успех": success, "выпало": result}
