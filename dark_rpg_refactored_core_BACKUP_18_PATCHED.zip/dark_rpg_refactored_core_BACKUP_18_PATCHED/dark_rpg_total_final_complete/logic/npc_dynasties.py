
# logic/npc_dynasties.py

import random
import uuid

class NPCDynastySystem:
    def assign_family_id(self, npc):
        if "family_id" not in npc:
            npc["family_id"] = str(uuid.uuid4())
        return npc

    def inherit_assets(self, deceased_npc, family_members):
        inheritance = deceased_npc.get("assets", {"золото": 0, "земля": 0})
        distributed = {}
        for asset, value in inheritance.items():
            share = value // len(family_members)
            distributed[asset] = share
            for member in family_members:
                if "assets" not in member:
                    member["assets"] = {}
                member["assets"][asset] = member["assets"].get(asset, 0) + share
        return family_members

    def simulate_family_conflict(self, family_members):
        if random.random() < 0.3 and len(family_members) >= 2:
            conflict_pair = random.sample(family_members, 2)
            for member in conflict_pair:
                if "conflicts" not in member:
                    member["conflicts"] = []
                member["conflicts"].append(f"Семейная вражда с {conflict_pair[0]['name'] if member == conflict_pair[1] else conflict_pair[1]['name']}")
        return family_members
