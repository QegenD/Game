
# logic/weather_magic.py

import random

class WorldEffect:
    def __init__(self):
        self.weather = "ясно"
        self.magic = None

    def generate_effects(self):
        weather_options = ["ясно", "дождь", "туман", "буря", "засуха", "метель"]
        magic_anomalies = [None, "временной разлом", "шепоты тьмы", "переменная гравитация", "магическое забывание"]

        self.weather = random.choice(weather_options)
        self.magic = random.choice(magic_anomalies)

    def get_world_state(self):
        return {
            "погода": self.weather,
            "аномалия": self.magic if self.magic else "отсутствует"
        }
