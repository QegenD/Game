
# logic/npc_reactions.py

import random

class NPCWorldReactions:
    def __init__(self, factions, calendar):
        self.factions = factions
        self.calendar = calendar

    def generate_reaction(self):
        reaction_list = []

        # Политические события
        for f in self.factions:
            if f.traits.get("tyranny") and random.random() < 0.3:
                reaction_list.append({
                    "тип": "бегство",
                    "причина": f"НПС покинул территорию фракции '{f.name}' из-за тирании.",
                    "фракция": f.name
                })

        # Погодные события
        if self.calendar.season == "Зима" and random.random() < 0.2:
            reaction_list.append({
                "тип": "замерзание",
                "причина": "Местный житель погиб в зимнюю стужу без магической защиты.",
                "место": random.choice(["северная деревня", "пограничный тракт", "глубинный лес"])
            })

        if random.random() < 0.2:
            reaction_list.append({
                "тип": "ритуал",
                "причина": "Маги проводят ритуал подавления магической бури.",
                "место": random.choice(["центральная площадь", "долина магов", "древний круг"])
            })

        return reaction_list
