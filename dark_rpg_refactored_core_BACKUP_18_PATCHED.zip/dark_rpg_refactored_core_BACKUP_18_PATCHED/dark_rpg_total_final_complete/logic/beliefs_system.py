
# beliefs_system.py
class BeliefsSystem:
    def __init__(self):
        self.beliefs = {
            "религия": "нейтральная",
            "насилие": "допустимо",
            "эротика": "табу",
            "жертвы": "недопустимы",
        }

    def change_belief(self, topic, new_value):
        if topic in self.beliefs:
            self.beliefs[topic] = new_value

    def get_beliefs(self):
        return dict(self.beliefs)
