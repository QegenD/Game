
# world_master.py
import random

class WorldMaster:
    def __init__(self, world):
        self.world = world
        self.tick = 0

    def advance(self):
        self.tick += 1
        if self.tick % 10 == 0:
            self.trigger_global_event()

    def trigger_global_event(self):
        event = random.choice(["война", "восстание", "эпидемия", "религиозный раскол"])
        faction = random.choice(self.world["factions"])
        self.world["log"].append({
            "type": "global_event",
            "event": event,
            "faction": faction,
        })
