import random

# Контекст игры с примерами для анализа и генерации
GAME_FILES = {
    "nsfw_settings": [
        "в проклятом борделе, где шепчут о запретных наслаждениях, а тени соблазняют",
        "в некрополе, где призраки нашептывают греховные тайны",
        "у алтаря, где проводятся кровавые ритуалы страсти",
        "в подземелье, пропитанном аурой запретных желаний",
        "в логове суккуба, где соблазн смешивается с опасностью",
        "на кладбище, где мёртвые искушают живых"
    ],
    "nsfw_enemies": [
        "Суккуб", "Инкуб", "Проклятый любовник", "Тень страсти",
        "Демон вожделения", "Призрак греха", "Сирена мрака", "Танцующий в тенях"
    ],
    "nsfw_phrases": [
        "Твои слова пробуждают запретные желания",
        "Ты играешь с огнём, смертный",
        "Твоё присутствие разжигает тьму в моей душе",
        "Ты готов поддаться искушению?",
        "Страсть в твоих глазах манит меня"
    ],
    "dialogue_phrases": [
        "Ты смел, раз говоришь так",
        "Твои слова интригуют",
        "Что скрывается за твоими намерениями?",
        "Ты пришёл искать ответы или погибель?",
        "Тьма наблюдает за тобой"
    ],
    "nsfw_moods": [
        "тягостное желание",
        "запретное влечение",
        "мрачный соблазн",
        "греховная страсть",
        "невыносимое искушение"
    ],
    "nsfw_events": [
        "ритуал, полный соблазна",
        "тень, зовущая поддаться страсти",
        "таинственный обряд, пропитанный похотью",
        "встреча с существом, чьи глаза горят желанием",
        "шёпот, обещающий запретные наслаждения"
    ],
    "nsfw_choices": [
        "Поддаться соблазну и исследовать запретные тайны",
        "Сразиться с соблазнительным врагом",
        "Попытаться сбежать от искушения",
        "Раскрыть тайну ритуала",
        "Остаться и принять вызов страсти"
    ],
    "example_phrases": [
        {"text": "Я хочу соблазнить тебя своей страстью", "category": "provocative", "intent": {"action": "соблазнить", "emotion": "страсть"}},
        {"text": "Твои глаза манят меня в бездну", "category": "provocative", "intent": {"target": "глаза", "emotion": "влечение"}},
        {"text": "Поддайся моему искушению", "category": "provocative", "intent": {"action": "искушение", "emotion": "соблазн"}},
        {"text": "Ты дурак, сдохни!", "category": "offensive", "intent": {"action": "оскорбить", "emotion": "гнев"}},
        {"text": "Я убью тебя, мерзавец!", "category": "offensive", "intent": {"action": "угроза", "emotion": "гнев"}},
        {"text": "Ты жалкий глупец!", "category": "offensive", "intent": {"action": "оскорбить", "emotion": "презрение"}},
        {"text": "Кто ты такой?", "category": "question", "intent": {"action": "узнать", "target": "личность"}},
        {"text": "Расскажи о себе", "category": "question", "intent": {"action": "рассказать", "target": "личность"}},
        {"text": "Где я нахожусь?", "category": "question", "intent": {"action": "узнать", "target": "место"}},
        {"text": "Я иду дальше", "category": "neutral", "intent": {"action": "идти", "emotion": "нейтральное"}},
        {"text": "Я готов сражаться!", "category": "aggressive", "intent": {"action": "сражаться", "emotion": "решительность"}}
    ],
    "question_words": ["кто", "что", "где", "когда", "почему", "как", "какой"],
    "action_verbs": ["иду", "сражаюсь", "бегу", "исследую", "хочу", "пытаюсь"],
    "emotional_words": ["страсть", "желание", "любовь", "грех", "похоть", "искушение", "вожделение"],
    "aggressive_words": ["убью", "сражаться", "атаковать", "уничтожить"],
    "offensive_words": ["дурак", "мерзавец", "глупец", "ублюдок", "тварь"]
}

def get_game_context():
    """Возвращает контекст игры на основе файлов."""
    return GAME_FILES

def analyze_player_input(player_input, game_context):
    """Анализирует полный текст игрока и возвращает категорию и намерение."""
    player_input = player_input.lower().strip()
    if not player_input:
        return {"category": "neutral", "intent": {}}

    words = player_input.split()
    sentences = player_input.split(".")

    # Проверяем точное совпадение с примерами
    for example in game_context.get("example_phrases", []):
        if player_input == example["text"].lower():
            return {"category": example["category"], "intent": example["intent"]}

    # Извлечение намерения
    intent = {"action": None, "target": None, "emotion": None}
    score = {"provocative": 0, "offensive": 0, "question": 0, "aggressive": 0, "neutral": 0}

    # 1. Проверка на вопросы
    if "?" in player_input or any(word in words for word in game_context.get("question_words", [])):
        score["question"] += 2
        intent["action"] = "узнать"
        intent["target"] = "личность" if "кто" in words else "место" if "где" in words else "информация"

    # 2. Проверка на провокацию
    for word in game_context.get("emotional_words", []):
        if word in words:
            score["provocative"] += 2
            intent["emotion"] = word
            intent["action"] = "соблазнить" if word in ["страсть", "искушение", "похоть"] else "вызвать"

    # 3. Проверка на агрессию
    for word in game_context.get("aggressive_words", []):
        if word in words:
            score["aggressive"] += 2
            intent["action"] = word
            intent["emotion"] = "гнев"

    # 4. Проверка на оскорбления
    for word in game_context.get("offensive_words", []):
        if word in words:
            score["offensive"] += 2
            intent["action"] = "оскорбить"
            intent["emotion"] = "презрение"

    # 5. Проверка на нейтральность
    for word in game_context.get("action_verbs", []):
        if word in words:
            score["neutral"] += 1
            intent["action"] = word
            intent["emotion"] = "нейтральное"

    # 6. Учёт длины текста
    if len(words) > 5:
        score["provocative"] += 1 if score["provocative"] > 0 else 0
        score["question"] += 1 if score["question"] > 0 else 0

    # Определяем категорию
    max_score = max(score.values())
    category = "neutral" if max_score == 0 else max(score, key=score.get)
    return {"category": category, "intent": intent}

def generate_dynamic_response(npc_name, input_type, intent, game_context):
    """Генерирует динамический ответ NPC без жёстких шаблонов."""
    action = intent.get("action", "говорить")
    emotion = intent.get("emotion", "нейтральное")
    target = intent.get("target", "ты")

    # Базовые компоненты ответа
    mood = random.choice(game_context.get("nsfw_moods", ["тягостное желание", "запретное влечение"]))
    setting = random.choice(game_context.get("nsfw_settings", ["в проклятом борделе", "в логове суккуба"]))

    # Логика для разных категорий
    if input_type == "provocative":
        phrases = game_context.get("nsfw_phrases", ["Твои слова пробуждают запретные желания"])
        response = f"{npc_name} склоняется ближе, глаза горят {mood}: '{random.choice(phrases)}. Твоё {action} {target} заставляет тьму в моей душе пылать.'"
    elif input_type in ["offensive", "aggressive"]:
        response = f"{npc_name} сжимает кулаки, {mood} в глазах: 'Твоё {action} {target} не останется без ответа!'"
    elif input_type == "question":
        answers = game_context.get("dialogue_phrases", ["Тайны этого мира глубоки"])
        response = f"{npc_name} задумчиво смотрит на тебя в {setting}: '{random.choice(answers)}. Зачем тебе {action} о {target}?'"
    else:  # neutral
        response = f"{npc_name} взирает на тебя в {setting}: 'Твоё {action} интригует, но что ты ищешь в этом месте?'"

    return response