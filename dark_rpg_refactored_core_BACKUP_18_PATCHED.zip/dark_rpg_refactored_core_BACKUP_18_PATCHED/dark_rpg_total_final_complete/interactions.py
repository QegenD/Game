from training_context import get_game_context, generate_dynamic_response
from nsfw_flags import NSFW_SETTINGS

def generate_npc_reply(npc_name, player_input, intent="talk", role="npc", emotion="neutral", context_override=None):
    base_context = get_game_context()
    context = context_override if context_override else base_context

    # Интент может быть "flirt", "command", "ask", "nsfw", "violence", "ally"
    if NSFW_SETTINGS.get("enable_nsfw") and any(x in player_input.lower() for x in ["прикоснись", "раздень", "целуй", "глубже", "возьми меня", "покори"]):
        intent = "nsfw"
        if NSFW_SETTINGS.get("dark_erotica"):
            emotion = "desire + dominance"
        else:
            emotion = "romantic + lust"

    reply = generate_dynamic_response(
        npc_name=npc_name,
        input_type="dialogue",
        intent=intent,
        emotion=emotion,
        game_context=context + f" Интим: {NSFW_SETTINGS['player_desire_level']} Уровень-табу: {NSFW_SETTINGS['taboo_threshold']}"
    )
    return reply



# --- Erotic Influence in Trade ---
def apply_charisma_trade(player, merchant):
    if player.charisma > 70 and "доминирование" in merchant.fetishes:
        merchant.give_discount(25)



# --- Black Market & Underground Offers ---
def black_market_options(player):
    offers = []
    if "садист" in player.traits:
        offers.append("Подпольная сцена с принуждением")
    if "фетишист" in player.traits:
        offers.append("Продажа запрещённых аксессуаров")
    return offers



# --- Capture and Servitude ---
def enslave_npc(npc):
    npc.status = "раб"
    npc.loyalty = -50
    npc.fetishes.append("унижение")
