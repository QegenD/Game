
# visualizer.py
import matplotlib.pyplot as plt
import networkx as nx

def draw_social_graph(graph):
    G = nx.Graph()
    for npc1, relations in graph.relations.items():
        for npc2, relation in relations.items():
            G.add_edge(npc1, npc2, label=relation)

    pos = nx.spring_layout(G)
    nx.draw(G, pos, with_labels=True, node_color='lightblue')
    edge_labels = nx.get_edge_attributes(G, 'label')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)
    plt.title("Социальная сеть NPC")
    plt.show()
