import random
import datetime

WORLD_STATE = {
    "time_of_day": random.choice(["утро", "день", "вечер", "ночь"]),
    "weather": random.choice(["ясно", "туман", "гроза", "дождь", "ветер", "снег"]),
    "last_updated": datetime.datetime.now()
}

def update_world_state():
    WORLD_STATE["time_of_day"] = random.choice(["утро", "день", "вечер", "ночь"])
    WORLD_STATE["weather"] = random.choice(["ясно", "туман", "гроза", "дождь", "ветер", "снег"])
    WORLD_STATE["last_updated"] = datetime.datetime.now()

def get_world_flavor():
    return f"{WORLD_STATE['time_of_day']} и {WORLD_STATE['weather']}"



# --- Shadow Memory System ---
nsfw_history = []

def record_nsfw_event(partner, action, result):
    nsfw_history.append({
        "partner": partner.name,
        "action": action,
        "result": result
    })

def get_past_interaction(partner_name):
    return [entry for entry in nsfw_history if entry["partner"] == partner_name]



# --- Reactive Locations ---
location_flags = {}

def update_location_state(location, state):
    location_flags[location] = state

def get_location_state(location):
    return location_flags.get(location, "нормально")



# --- Кризисы мира ---
class WorldCrisisManager:
    def __init__(self):
        self.crisis_history = []

    def evaluate_crisis(self, npc, alert_level, recent_events):
        reaction = None

        if alert_level > 7:
            if "магическая буря" in recent_events:
                reaction = f"{npc.name} прячется от магической бури."
            elif "нашествие" in recent_events:
                reaction = f"{npc.name} готовится к обороне или покидает деревню."
            else:
                reaction = f"{npc.name} насторожен и следит за происходящим."
        elif alert_level > 3:
            if "странные слухи" in recent_events:
                reaction = f"{npc.name} делится слухами о приближающейся беде."
            else:
                reaction = f"{npc.name} обеспокоен общей обстановкой."
        else:
            reaction = f"{npc.name} занимается своими делами, как ни в чем не бывало."

        self.crisis_history.append((npc.name, alert_level, recent_events))
        return reaction
