
# npc_scheduler.py

class NPCScheduler:
    def __init__(self):
        self.schedule = {}

    def assign_task(self, npc_id, task, time):
        self.schedule.setdefault(npc_id, []).append((time, task))

    def get_schedule(self, npc_id):
        return self.schedule.get(npc_id, [])
