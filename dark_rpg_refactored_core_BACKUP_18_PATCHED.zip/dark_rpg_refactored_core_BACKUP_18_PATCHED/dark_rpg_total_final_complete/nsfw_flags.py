# nsfw_flags.py

NSFW_SETTINGS = {
    "enable_nsfw": True,
    "kink_mode": True,
    "dark_erotica": True,
    "allow_consent_dynamics": True,
    "taboo_threshold": 3,  # 1 - мягкое, 5 - экстремальное
    "player_desire_level": 4,  # как охотно игрок вовлечён в эротические сцены
    "npc_variability": True
}



# --- Trauma System ---
def apply_trauma(npc, trauma_type):
    npc.traumas.append(trauma_type)
    if trauma_type == "насилие":
        npc.fetishes.append("боль")
