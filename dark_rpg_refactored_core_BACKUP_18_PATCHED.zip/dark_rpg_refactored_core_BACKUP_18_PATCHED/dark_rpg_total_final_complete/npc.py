
# npc.py

from logic.hidden_goals import NPCHiddenGoal
from logic.secret_agents import SecretAgent
from logic.emotion_drift import EmotionDrift
from logic.emotion_memory import EmotionMemory

class NPC:
    def __init__(self, npc_id, name):
        self.id = npc_id
        self.name = name
        self.emotions = {"страх": 0, "желание": 0, "ненависть": 0}
        self.goal = NPCHiddenGoal(npc_id)
        self.agent = SecretAgent(npc_id)
        self.memory = EmotionMemory()

    def evolve_emotions(self):
        drift = EmotionDrift(self.emotions)
        self.emotions = drift.evolve()

    def react_to_player(self, action, impact):
        self.memory.record(action, impact)

    def attitude(self):
        return self.memory.get_attitude()

    def get_summary(self):
        return {
            "id": self.id,
            "name": self.name,
            "эмоции": self.emotions,
            "цель": self.goal.get_goal(),
            "агент": self.agent.reveal(),
            "настроение": self.attitude()
        }
