
import random

class AIContentGenerator:
    def __init__(self):
        self.base_templates = {
            "npc": [
                "Мрачный {profession} из {kingdom}, {trait} и {trait2}",
                "Служитель {order} с {feature}, известный как {title}",
                "{race} из {faction}, обладает чертами: {trait}, {trait2}"
            ],
            "rumor": [
                "Ходят слухи, что {event} в {place} было делом рук {group}",
                "Говорят, {npc} замечен возле {location} с подозрительной миссией",
                "Некто утверждает, что {phenomenon} предвещает беду в {region}"
            ],
            "faction": [
                "Орден {name}, следуют кодексу {code} и враждуют с {enemy}",
                "Клан {name}, основанный на принципах {belief}, часто вмешивается в дела {kingdom}",
                "Академия {name} обучает {magic_school} и стремится к {goal}"
            ]
        }
        self.memory = {}

    def _adapt_template(self, template, context):
        # Заменим плейсхолдеры на реальные значения из контекста
        return template.format(**context)

    def generate(self, content_type, context):
        # Использует шаблон только как отправную точку, адаптирует под мир и память
        if content_type not in self.base_templates:
            return f"Неизвестный тип генерации: {content_type}"

        template = random.choice(self.base_templates[content_type])
        result = self._adapt_template(template, context)
        
        # Запоминаем и адаптируем генерацию на основе прошлого опыта
        self.memory.setdefault(content_type, []).append(result)
        return result

    def summarize_memory(self, content_type):
        return self.memory.get(content_type, [])
