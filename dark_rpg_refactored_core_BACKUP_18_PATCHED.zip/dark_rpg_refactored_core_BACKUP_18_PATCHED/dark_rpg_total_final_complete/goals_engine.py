
# goals_engine.py

class GoalsEngine:
    def __init__(self):
        self.goals = {}

    def set_goal(self, npc_id, goal):
        self.goals[npc_id] = goal

    def get_goal(self, npc_id):
        return self.goals.get(npc_id)
