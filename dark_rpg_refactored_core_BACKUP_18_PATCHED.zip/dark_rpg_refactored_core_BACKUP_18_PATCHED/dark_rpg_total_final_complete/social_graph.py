
# social_graph.py
from collections import defaultdict

class SocialGraph:
    def __init__(self):
        self.relations = defaultdict(dict)

    def add_relation(self, npc1, npc2, relation_type):
        self.relations[npc1][npc2] = relation_type
        self.relations[npc2][npc1] = relation_type

    def update_relation(self, npc1, npc2, new_relation_type):
        if npc2 in self.relations[npc1]:
            self.relations[npc1][npc2] = new_relation_type
            self.relations[npc2][npc1] = new_relation_type

    def get_relations(self, npc):
        return self.relations.get(npc, {})
