
"""
NSFW Scene Engine
Управляет генерацией эротических сцен в зависимости от отношений и опыта.
"""

import random

class NSFWSceneEngine:
    def __init__(self, player, npc):
        self.player = player
        self.npc = npc

    def generate_scene(self):
        intimacy_level = self.npc.relations.get(self.player.name, 0)
        experience = self.player.nsfw_experience_level

        if intimacy_level < 20:
            return "NPC отвергает любые попытки сближения."
        elif intimacy_level < 50:
            return f"{self.npc.name} позволяет лёгкие прикосновения. Сцена остаётся скромной."
        elif intimacy_level < 80:
            return f"{self.npc.name} проявляет страсть. Сцена становится более откровенной."
        else:
            return self._explicit_scene(experience)

    def _explicit_scene(self, experience):
        levels = [
            "нежная интимная сцена без обнажёнки",
            "пылкая сцена с частичной наготой",
            "горячая сцена с подробным описанием",
            "откровенная сцена с множеством техник",
        ]
        return levels[min(experience, len(levels) - 1)]
