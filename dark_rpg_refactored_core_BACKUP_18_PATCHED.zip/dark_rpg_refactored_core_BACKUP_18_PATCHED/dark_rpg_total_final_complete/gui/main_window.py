import os
from PyQt6.QtWidgets import (
    QMainWindow, QLabel, QPushButton, QVBoxLayout, QWidget,
    QScrollArea, QMessageBox, QListWidget, QListWidgetItem
)
from PyQt6.QtGui import QPixmap, QFont
from PyQt6.QtCore import Qt
from scene_gen import generate_synthetic_scene
from gui.combat_panel import CombatPanel

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Dark Gothic RPG")
        self.setGeometry(100, 100, 1000, 800)
        self.setStyleSheet("background-color: #111; color: #eee;")

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)

        self.title_label = QLabel("🕯️ Добро пожаловать в мрачный мир...")
        self.title_label.setFont(QFont("Georgia", 20))
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.title_label)

        self.scene_area = QScrollArea()
        self.scene_label = QLabel()
        self.scene_label.setWordWrap(True)
        self.scene_label.setFont(QFont("Georgia", 14))
        self.scene_area.setWidgetResizable(True)
        self.scene_area.setWidget(self.scene_label)
        self.layout.addWidget(self.scene_area, stretch=2)

        self.background_label = QLabel()
        self.background_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.background_label, stretch=3)

        self.inventory_list = QListWidget()
        self.inventory_list.setMaximumHeight(100)
        self.layout.addWidget(self.inventory_list)

        self.choices_container = QWidget()
        self.choices_layout = QVBoxLayout(self.choices_container)
        self.layout.addWidget(self.choices_container)

        self.load_scene()

    def load_scene(self):
        self.clear_choices()
        scene_text, img_path, fight_triggered = generate_synthetic_scene(user_id=None)
        self.scene_label.setText(scene_text)

        if img_path and os.path.exists(img_path):
            pixmap = QPixmap(img_path).scaled(960, 400, Qt.AspectRatioMode.KeepAspectRatioByExpanding)
            self.background_label.setPixmap(pixmap)
        else:
            self.background_label.clear()

        self.update_inventory(["Окорок на палке", "Кольчужный капюшон"])

        if fight_triggered:
            enemy = {
                "name": "Суккуб",
                "attack": 6,
                "defense": 3,
                "hp": 25,
                "agility": 2
            }
            player = {
                "name": "Герой",
                "attack": 7,
                "defense": 4,
                "hp": 30,
                "agility": 2
            }
            self.start_combat(player, enemy)
            return

        if "\n\nВыберите действие:" in scene_text:
            choices = scene_text.split("\n\nВыберите действие:")[-1].strip().split("\n")
            for choice in choices:
                btn = QPushButton(choice.strip())
                btn.setStyleSheet("background-color: #333; color: #eee; font-size: 14px; padding: 6px;")
                btn.clicked.connect(lambda checked, ch=choice: self.choice_selected(ch))
                self.choices_layout.addWidget(btn)

    def clear_choices(self):
        for i in reversed(range(self.choices_layout.count())):
            widget = self.choices_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

    def choice_selected(self, choice_text):
        QMessageBox.information(self, "Выбор сделан", f"Вы выбрали:\n{choice_text}")
        self.load_scene()

    def update_inventory(self, items):
        self.inventory_list.clear()
        for item in items:
            QListWidgetItem(f"🎒 {item}", self.inventory_list)

    def start_combat(self, player, enemy):
        self.clear_choices()
        self.scene_area.hide()
        self.background_label.hide()
        self.choices_container.hide()
        self.title_label.setText("⚔️ Битва начинается!")
        self.combat_panel = CombatPanel(player, enemy)
        self.layout.addWidget(self.combat_panel)
