
import tkinter as tk
from tkinter import Toplevel, Text, Scrollbar, Label, Entry, Button, Frame, PhotoImage
from PIL import Image, ImageTk
import os

class RPGInterface:
    def __init__(self, root):
        self.root = root
        self.root.title("🧙 Dark RPG Interface")
        self.root.geometry("1200x800")

        # Верхняя панель кнопок
        top_frame = Frame(root)
        top_frame.pack(side="top", fill="x")

        Button(top_frame, text="🧳 Инвентарь", command=self.open_inventory).pack(side="left", padx=5)
        Button(top_frame, text="📖 Журнал", command=self.open_journal).pack(side="left", padx=5)
        Button(top_frame, text="🗺️ Карта", command=self.open_worldmap).pack(side="left", padx=5)
        Button(top_frame, text="🔞 NSFW", command=self.open_nsfw_gallery).pack(side="left", padx=5)

        # Основной фрейм (портреты + локация + диалог)
        center_frame = Frame(root)
        center_frame.pack(fill="both", expand=True)

        # Портрет игрока
        self.player_image_label = Label(center_frame, text="Игрок")
        self.player_image_label.pack(side="left", padx=10)
        self.load_image(self.player_image_label, "images/player/avatar.png", size=(160, 240))

        # Центр — изображение локации
        self.location_image_label = Label(center_frame, text="Локация")
        self.location_image_label.pack(side="left", expand=True)
        self.load_image(self.location_image_label, "images/locations/current_location.png", size=(512, 320))

        # Портрет NPC
        self.npc_image_label = Label(center_frame, text="NPC")
        self.npc_image_label.pack(side="right", padx=10)
        self.load_image(self.npc_image_label, "images/npc/current_npc.png", size=(160, 240))

        # История событий
        self.story_text = Text(root, height=20, bg="#f4f4f4", wrap="word")
        self.story_text.pack(fill="both", expand=True, padx=10, pady=(5, 0))
        self.story_text.insert("end", "Добро пожаловать в Dark RPG!
")

        # Нижняя панель ввода
        input_frame = Frame(root)
        input_frame.pack(fill="x", pady=5)

        self.input_entry = Entry(input_frame, font=("Arial", 14))
        self.input_entry.pack(side="left", fill="x", expand=True, padx=10)

        Button(input_frame, text="🗨️ Речь", command=lambda: self.handle_input("speech")).pack(side="left", padx=5)
        Button(input_frame, text="⚔️ Действие", command=lambda: self.handle_input("action")).pack(side="left", padx=5)

    def load_image(self, label, path, size=(128, 128)):
        if os.path.exists(path):
            img = Image.open(path).resize(size)
            photo = ImageTk.PhotoImage(img)
            label.configure(image=photo)
            label.image = photo

    def handle_input(self, mode):
        text = self.input_entry.get().strip()
        if not text:
            return
        self.story_text.insert("end", f">>> ({mode.upper()}) {text}\n")
        self.story_text.see("end")
        self.input_entry.delete(0, "end")
        
# Обработка в зависимости от режима
        if mode == "speech":
            response = self.generate_llm_response(text)
            self.story_text.insert("end", f"{response}\n")
        elif mode == "action":
            result = self.process_action(text)
            self.story_text.insert("end", f"{result}\n")
        self.update_images()
    

    def open_inventory(self):
        self.popup_window("Инвентарь", "Тут будет список предметов.")

    def open_journal(self):
        self.popup_window("Журнал", "Здесь хранятся квесты и записи.")

    def open_worldmap(self):
        self.popup_image("Карта мира", "images/world/world_map.png")

    def open_nsfw_gallery(self):
        self.popup_window("NSFW Галерея", "Контент для взрослых (если есть).")

    
    def generate_llm_response(self, text):
        return f"[NPC отвечает]: '{text[::-1]}'"  # Заглушка для демонстрации

    def process_action(self, text):
        return f"[Вы сделали]: {text}"  # Заглушка

    def update_images(self):
        self.load_image(self.player_image_label, "images/player/avatar.png", size=(160, 240))
        self.load_image(self.location_image_label, "images/locations/current_location.png", size=(512, 320))
        self.load_image(self.npc_image_label, "images/npc/current_npc.png", size=(160, 240))


        win = Toplevel()
        win.title(title)
        label = Label(win, text=text, font=("Arial", 14))
        label.pack(padx=20, pady=20)

    def popup_image(self, title, path):
        win = Toplevel()
        win.title(title)
        if os.path.exists(path):
            img = Image.open(path).resize((512, 320))
            photo = ImageTk.PhotoImage(img)
            label = Label(win, image=photo)
            label.image = photo
            label.pack()
        else:
            Label(win, text="Изображение не найдено.").pack(padx=20, pady=20)

if __name__ == "__main__":
    root = tk.Tk()
    app = RPGInterface(root)
    root.mainloop()
