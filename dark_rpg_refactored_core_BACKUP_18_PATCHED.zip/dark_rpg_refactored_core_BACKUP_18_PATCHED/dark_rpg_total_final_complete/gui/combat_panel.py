from PyQt6.QtWidgets import QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QTextEdit, QProgressBar, QDialog
from PyQt6.QtCore import Qt
from combat import calculate_attack, attempt_escape, apply_item_effects
from gui.inventory_panel import InventoryPanel

class CombatPanel(QWidget):
    def __init__(self, player, npc, items=None):
        super().__init__()
        self.player = player
        self.npc = npc
        self.items = items or []
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.title = QLabel(f"⚔️ Битва: {self.player['name']} vs {self.npc['name']}")
        self.title.setStyleSheet("font-size: 18px; color: #f55;")
        layout.addWidget(self.title)

        hp_layout = QHBoxLayout()
        self.player_hp = QProgressBar()
        self.player_hp.setMaximum(self.player['hp'])
        self.player_hp.setValue(self.player['hp'])
        self.player_hp.setFormat(f"Игрок: %v/%m HP")

        self.npc_hp = QProgressBar()
        self.npc_hp.setMaximum(self.npc['hp'])
        self.npc_hp.setValue(self.npc['hp'])
        self.npc_hp.setFormat(f"Враг: %v/%m HP")

        hp_layout.addWidget(self.player_hp)
        hp_layout.addWidget(self.npc_hp)
        layout.addLayout(hp_layout)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)

        btn_layout = QHBoxLayout()
        self.attack_btn = QPushButton("🗡️ Атаковать")
        self.attack_btn.clicked.connect(self.do_attack)
        btn_layout.addWidget(self.attack_btn)

        self.use_item_btn = QPushButton("🧪 Предметы")
        self.use_item_btn.clicked.connect(self.open_inventory)
        btn_layout.addWidget(self.use_item_btn)

        self.escape_btn = QPushButton("🏃 Сбежать")
        self.escape_btn.clicked.connect(self.try_escape)
        btn_layout.addWidget(self.escape_btn)

        layout.addLayout(btn_layout)
        self.setLayout(layout)

    def do_attack(self):
        dmg, msg = calculate_attack(self.player, self.npc)
        self.npc['hp'] -= dmg
        self.log.append(f"Ты ударил на {dmg}. {msg}")
        self.npc_hp.setValue(max(0, self.npc['hp']))

        if self.npc['hp'] <= 0:
            self.log.append("✅ Победа!")
            self.attack_btn.setEnabled(False)
            self.use_item_btn.setEnabled(False)
            self.escape_btn.setEnabled(False)
            return

        dmg2, msg2 = calculate_attack(self.npc, self.player)
        self.player['hp'] -= dmg2
        self.player_hp.setValue(max(0, self.player['hp']))
        self.log.append(f"Враг бьёт на {dmg2}. {msg2}")

        if self.player['hp'] <= 0:
            self.log.append("💀 Поражение!")
            self.attack_btn.setEnabled(False)
            self.use_item_btn.setEnabled(False)
            self.escape_btn.setEnabled(False)

    def try_escape(self):
        if attempt_escape(self.player, self.npc):
            self.log.append("✅ Ты сбежал!")
            self.attack_btn.setEnabled(False)
            self.use_item_btn.setEnabled(False)
            self.escape_btn.setEnabled(False)
        else:
            self.log.append("❌ Сбежать не удалось!")
            self.do_attack()

    def open_inventory(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("🎒 Инвентарь")
        inventory_panel = InventoryPanel(self.items, self.use_item_effect)
        layout = QVBoxLayout()
        layout.addWidget(inventory_panel)
        dialog.setLayout(layout)
        dialog.exec()

    def use_item_effect(self, item):
        apply_item_effects(self.player, [item])
        self.player_hp.setValue(self.player.get('hp', 0))
        self.log.append(f"🧪 Использован предмет: {item.get('name')} — эффект {item.get('effect')}")
