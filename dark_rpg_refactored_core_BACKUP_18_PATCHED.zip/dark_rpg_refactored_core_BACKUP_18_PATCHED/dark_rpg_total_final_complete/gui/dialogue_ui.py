


# --- Seduction Mini-game ---
def seduction_dialogue(player, npc):
    options = ["флирт", "похвала", "прямое предложение"]
    for opt in options:
        if player.charisma + npc.trust > 100:
            npc.arousal += 15
