from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QListWidget, QListWidgetItem, QComboBox
from journal_and_reputation import get_quest_log

class QuestLogPanel(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("📜 Журнал квестов")
        self.resize(520, 450)
        self.setStyleSheet("background-color: #111; color: #eee; font-size: 13px;")
        self.layout = QVBoxLayout()

        self.title_label = QLabel("Квесты:")
        self.layout.addWidget(self.title_label)

        self.filter_box = QComboBox()
        self.filter_box.addItems(["Все", "Активные", "Завершённые", "Проваленные"])
        self.filter_box.currentTextChanged.connect(self.update_quest_list)
        self.layout.addWidget(self.filter_box)

        self.quest_list = QListWidget()
        self.quest_list.setStyleSheet("background-color: #222; color: #ddd; padding: 5px;")
        self.layout.addWidget(self.quest_list)

        self.setLayout(self.layout)
        self.update_quest_list()

    def update_quest_list(self):
        self.quest_list.clear()
        filter_value = self.filter_box.currentText().lower()
        quests = get_quest_log()
        for q in quests:
            if filter_value != "все" and q["status"] != filter_value:
                continue
            short_desc = q.get("summary", q["description"][:90] + "...")
            location = q.get("location", "Неизвестно")
            item = QListWidgetItem(
                f"[{q['status'].upper()}] {q['title']}
📌 {location} | 📖 {short_desc}"
            )
            item.setToolTip(q["description"])
            self.quest_list.addItem(item)
