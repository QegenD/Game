from PyQt6.QtWidgets import QWidget, QVBoxLayout, QCheckBox, QPushButton
from creative_control import CREATIVE_FLAGS

class CreativeSettingsPanel(QWidget):
    def __init__(self, on_apply=None):
        super().__init__()
        self.setWindowTitle("⚙️ Креативные настройки")
        self.setStyleSheet("background-color: #111; color: #eee; font-size: 13px;")
        self.resize(400, 300)
        self.on_apply = on_apply
        self.checkboxes = {}

        layout = QVBoxLayout()
        for key, value in CREATIVE_FLAGS.items():
            box = QCheckBox(key.replace('_', ' ').capitalize())
            box.setChecked(value)
            self.checkboxes[key] = box
            layout.addWidget(box)

        apply_btn = QPushButton("✅ Применить")
        apply_btn.clicked.connect(self.apply_settings)
        layout.addWidget(apply_btn)

        self.setLayout(layout)

    def apply_settings(self):
        for key, checkbox in self.checkboxes.items():
            CREATIVE_FLAGS[key] = checkbox.isChecked()
        if self.on_apply:
            self.on_apply()
        self.close()
