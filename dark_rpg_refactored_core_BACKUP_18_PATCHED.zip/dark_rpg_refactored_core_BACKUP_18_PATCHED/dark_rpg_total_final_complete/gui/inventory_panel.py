from PyQt6.QtWidgets import QWidget, QVBoxLayout, QListWidget, QPushButton, QMessageBox
from PyQt6.QtCore import Qt

class InventoryPanel(QWidget):
    def __init__(self, items, on_use_callback=None):
        super().__init__()
        self.items = items
        self.on_use_callback = on_use_callback

        self.layout = QVBoxLayout()
        self.list_widget = QListWidget()
        self.layout.addWidget(self.list_widget)

        self.use_button = QPushButton("🧪 Использовать выбранный предмет")
        self.use_button.clicked.connect(self.use_selected_item)
        self.layout.addWidget(self.use_button)

        self.setLayout(self.layout)
        self.refresh()

    def refresh(self):
        self.list_widget.clear()
        for item in self.items:
            label = f"{item.get('name')} ({item.get('type')}, {item.get('rarity')})"
            self.list_widget.addItem(label)

    def use_selected_item(self):
        selected = self.list_widget.currentRow()
        if selected == -1:
            QMessageBox.warning(self, "Нет выбора", "Выберите предмет для использования.")
            return
        item = self.items[selected]
        if self.on_use_callback:
            self.on_use_callback(item)
        del self.items[selected]
        self.refresh()
