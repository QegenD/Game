from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton
from training_context import get_game_context, generate_dynamic_response, analyze_player_input

class NPCDialog(QWidget):
    def __init__(self, npc_name, player_data):
        super().__init__()
        self.npc_name = npc_name
        self.player_data = player_data
        self.setWindowTitle(f"💬 Диалог с {npc_name}")
        self.setStyleSheet("background-color: #222; color: #eee;")
        self.resize(600, 400)

        self.layout = QVBoxLayout()
        self.prompt_label = QLabel("Введите фразу:")
        self.input_field = QTextEdit()
        self.send_button = QPushButton("📨 Отправить")
        self.send_button.clicked.connect(self.process_input)
        self.response_area = QTextEdit()
        self.response_area.setReadOnly(True)

        self.layout.addWidget(self.prompt_label)
        self.layout.addWidget(self.input_field)
        self.layout.addWidget(self.send_button)
        self.layout.addWidget(self.response_area)
        self.setLayout(self.layout)

    def process_input(self):
        text = self.input_field.toPlainText()
        game_context = get_game_context()
        input_analysis = analyze_player_input(text, game_context)
        response = generate_dynamic_response(
            npc_name=self.npc_name,
            input_type=input_analysis['category'],
            intent=input_analysis['intent'],
            game_context=game_context
        )
        self.response_area.append(f"🧍‍♀️ {self.npc_name}:
{response}\n")
        self.input_field.clear()
