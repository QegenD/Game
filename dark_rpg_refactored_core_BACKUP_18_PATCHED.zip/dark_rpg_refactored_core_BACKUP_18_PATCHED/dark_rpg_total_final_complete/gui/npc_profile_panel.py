
# npc_profile_panel.py
import tkinter as tk

class NPCProfilePanel(tk.Toplevel):
    def __init__(self, master, npc_data):
        super().__init__(master)
        self.title(f"Профиль NPC: {npc_data['name']}")
        self.geometry("400x300")

        info = [
            f"Имя: {npc_data['name']}",
            f"Черты: {', '.join(npc_data['traits'])}",
            f"Фетиши: {', '.join(npc_data['fetishes'])}",
            f"Отношение к игроку: {npc_data['opinion']}",
            f"Текущие эмоции: {', '.join(npc_data['emotions'])}"
        ]

        for line in info:
            label = tk.Label(self, text=line, anchor="w")
            label.pack(fill="x", padx=10, pady=2)
