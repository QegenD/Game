from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton
import random

LOCATIONS = [
    {"name": "Проклятый бордель", "description": "шепчут о запретных наслаждениях"},
    {"name": "Некрополь", "description": "где призраки нашептывают греховные тайны"},
    {"name": "Алтарь страсти", "description": "проводятся кровавые ритуалы"},
    {"name": "Подземелье искушений", "description": "пропитано желанием"},
    {"name": "Логово суккуба", "description": "соблазн и опасность"},
    {"name": "Кладбище искушений", "description": "мёртвые искушают живых"},
]

class MapNavigation(QWidget):
    def __init__(self, on_location_selected):
        super().__init__()
        self.setWindowTitle("🗺 Карта мира")
        self.setStyleSheet("background-color: #222; color: #eee;")
        self.resize(600, 400)
        self.layout = QVBoxLayout()
        self.on_location_selected = on_location_selected

        self.label = QLabel("Выберите локацию:")
        self.layout.addWidget(self.label)

        for loc in LOCATIONS:
            btn = QPushButton(f"{loc['name']} — {loc['description']}")
            btn.clicked.connect(lambda _, l=loc: self.select_location(l))
            self.layout.addWidget(btn)

        self.setLayout(self.layout)

    def select_location(self, location):
        self.on_location_selected(location)
        self.close()
