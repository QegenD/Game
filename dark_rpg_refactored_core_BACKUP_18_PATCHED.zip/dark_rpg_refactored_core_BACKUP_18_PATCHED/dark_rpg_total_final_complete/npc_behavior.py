from world_state import WORLD_STATE

def get_npc_behavior(npc_type="обычный"):
    time = WORLD_STATE["time_of_day"]
    weather = WORLD_STATE["weather"]

    behavior = []

    # Ночное поведение
    if time == "ночь":
        if npc_type in ["враг", "разбойник"]:
            behavior.append("агрессивен")
        else:
            behavior.append("насторожен")
    elif time == "утро":
        behavior.append("спокоен")

    # Погодное поведение
    if weather == "дождь":
        behavior.append("ищет укрытие")
    elif weather == "туман":
        behavior.append("оглядывается по сторонам")
    elif weather == "ясно":
        behavior.append("расслаблен")

    return ", ".join(behavior)



# --- Personality Traits and Fetishes ---
class PersonalityProfile:
    def __init__(self, traits=None, fetishes=None):
        self.traits = traits or []
        self.fetishes = fetishes or []
    
    def is_dominant(self):
        return "доминирующий" in self.traits
    
    def reacts_to_fetish(self, fetish):
        return fetish in self.fetishes



# --- Personality Archetype Generator ---
import random

personality_archetypes = {
    "мученик": ["покорный", "эмпатичный"],
    "садист": ["жестокий", "доминирующий"],
    "харизматик": ["харизматичный", "манипулятор"],
    "фетишист": ["навязчивый", "фетишист"],
    "пророк": ["одержимый", "харизматичный"]
}

def generate_npc_personality():
    archetype = random.choice(list(personality_archetypes.keys()))
    traits = personality_archetypes[archetype]
    return {"archetype": archetype, "traits": traits}



# --- Background and Relationship Conflicts ---
class NPCBackground:
    def __init__(self, family=None, secrets=None):
        self.family = family or []
        self.secrets = secrets or []

    def has_conflict_with(self, other_npc):
        return any(person in other_npc.family for person in self.secrets)
