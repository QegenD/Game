
"""
Модуль прогрессии NSFW: фетиши, техники, опыт, обучение.
"""

class PsycheProgression:
    def __init__(self):
        self.fetishes = set()
        self.techniques = set()
        self.experience_level = 0

    def discover_fetish(self, fetish):
        self.fetishes.add(fetish)

    def learn_technique(self, technique):
        self.techniques.add(technique)
        self.experience_level += 1

    def describe(self):
        return {
            "fetishes": list(self.fetishes),
            "techniques": list(self.techniques),
            "level": self.experience_level
        }

    def apply_learning_from_npc(self, npc):
        if hasattr(npc, "known_techniques"):
            for tech in npc.known_techniques:
                self.learn_technique(tech)
