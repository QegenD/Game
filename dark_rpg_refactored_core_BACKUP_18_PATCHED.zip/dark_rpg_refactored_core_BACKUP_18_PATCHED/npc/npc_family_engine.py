
# npc_family_engine.py — Расширенные семейные узы и эмоциональные реакции

import random

RELATION_TYPES = ["mother", "father", "brother", "sister", "child", "lover", "spouse", "mentor", "friend", "rival"]

def build_family_reactions(npc, event, target_name, world):
    relation_map = npc.get("relations", {})
    for relation, name in relation_map.items():
        if name != target_name:
            continue

        if relation in ["father", "mother", "brother", "sister", "child", "spouse", "lover"]:
            if event == "death":
                npc["mood"] = "mourning"
                world.setdefault("rumors", []).append(f"{npc['name']} скорбит по {target_name}.")
                if npc.get("personality") in ["vengeful", "honorable"]:
                    world.setdefault("plots", []).append(f"{npc['name']} поклялся(-ась) отомстить за {target_name}.")
            elif event == "scandal":
                npc["mood"] = "ashamed"
                world.setdefault("rumors", []).append(f"{npc['name']} стыдится поступка {target_name}.")
                if npc.get("personality") == "proud":
                    npc["goal"] = "restore_family_honor"
            elif event == "heroic":
                npc["mood"] = "inspired"
                npc["goal"] = "follow_legacy"
                world.setdefault("rumors", []).append(f"{npc['name']} гордится {target_name} и хочет пойти по его пути.")
            elif event == "betrayal":
                npc["mood"] = "devastated"
                npc["goal"] = "cut_all_ties"
                world.setdefault("rumors", []).append(f"{npc['name']} отрёкся от {target_name}.")

        elif relation in ["mentor", "friend"]:
            if event == "death":
                npc["mood"] = "lonely"
            elif event == "scandal":
                npc["mood"] = "distrustful"

        elif relation == "rival":
            if event == "death":
                npc["mood"] = "satisfied"
                world.setdefault("rumors", []).append(f"{npc['name']} празднует смерть соперника {target_name}.")
            elif event == "heroic":
                npc["mood"] = "jealous"
                npc["goal"] = "surpass_rival"
