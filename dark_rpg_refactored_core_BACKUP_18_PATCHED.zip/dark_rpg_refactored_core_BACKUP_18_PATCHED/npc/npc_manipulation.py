
# npc_manipulation.py — NPC могут убеждать, соблазнять, запугивать

import random

def try_to_manipulate(actor, target):
    if "manipulative" not in actor.traits:
        return

    method = random.choice(["persuade", "intimidate", "seduce"])
    success = random.random() < 0.6  # базовый шанс

    if method == "persuade":
        if success:
            target.goals.append("assist_" + actor.name)
            target.dialogue.append(f"{actor.name} убедил меня помочь...")
    elif method == "intimidate":
        if success:
            target.mood = "afraid"
            target.traits.append("submissive")
    elif method == "seduce":
        if success:
            target.dialogue.append(f"Я не мог(ла) устоять перед {actor.name}...")
            target.relationships[actor.name] = "obsessed"

    print(f"{actor.name} использует {method} на {target.name} — {'успешно' if success else 'безуспешно'}")
