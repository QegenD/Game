
# npc_memory.py — NPC хранят травматичный опыт и реагируют на события

def record_trauma(npc, event_type, source=None):
    if not hasattr(npc, "memory"):
        npc.memory = []

    entry = {"event": event_type, "source": source, "severity": 1}
    npc.memory.append(entry)

    # Изменение поведения
    if event_type == "violence":
        npc.traits.append("fearful")
        npc.mood = "anxious"
    elif event_type == "nsfw_abuse":
        npc.traits.append("scarred")
        npc.mood = "numb"
    elif event_type == "betrayal":
        npc.traits.append("distrustful")
        npc.mood = "cold"

    npc.dialogue.append(f"Я не могу забыть, что случилось тогда…")
