
# economic_house_engine.py — экономические династии и борьба за богатство

import random

def process_trade_dominance(npc, world):
    if not npc.get("owns_business"):
        return

    rivals = [n for n in world["npcs"].values()
              if n.get("owns_business") and n.get("family_name") != npc.get("family_name")]

    for rival in rivals:
        if random.random() < 0.1:
            world.setdefault("business_conflicts", []).append(
                f"Дом {npc['family_name']} пытается вытеснить {rival['family_name']} с рынка.")

def transfer_business_on_death(npc, world):
    if npc.get("owns_business"):
        heirs = npc.get("children", []) or npc.get("siblings", [])
        if heirs:
            heir = random.choice(heirs)
            world["npcs"][heir]["owns_business"] = True
            world.setdefault("rumors", []).append(f"{heir} получил дело {npc['name']} после смерти.")
