
# update_bloodline_log.py — фиксация семейных последствий в хронике

import json
import os
from datetime import datetime

def record_family_event(event_type, source, target, description):
    path = os.path.join(os.path.dirname(__file__), "..", "bloodline_log.json")
    with open(path, "r+", encoding="utf-8") as f:
        data = json.load(f)
        entry = {
            "timestamp": datetime.now().isoformat(),
            "type": event_type,
            "source": source,
            "target": target,
            "description": description
        }
        data.setdefault("events", []).append(entry)
        f.seek(0)
        json.dump(data, f, indent=2)
        f.truncate()
