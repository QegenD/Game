
# npc_diary_reader.py — игрок читает записи NPC и может использовать это

import os

DIARY_FOLDER = "npc/diaries/"

def read_npc_diary(npc_name):
    diary_path = os.path.join(DIARY_FOLDER, f"{npc_name}_diary.txt")
    if not os.path.exists(diary_path):
        return f"Нет записей от {npc_name}."

    with open(diary_path, "r", encoding="utf-8") as f:
        return f.read()

def extract_secrets_from_diary(content):
    secrets = []
    for line in content.split("\n"):
        if any(word in line.lower() for word in ["любовь", "насилие", "предал", "сцена", "жестокость"]):
            secrets.append(line)
    return secrets
