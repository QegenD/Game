
# npc_diary_system.py — NPC оставляют дневники и записки

import os
import datetime
from nsfw.memories.nsfw_memories import find_memories_by_npc

DIARY_FOLDER = "npc/diaries/"

def write_npc_diary(npc):
    if not os.path.exists(DIARY_FOLDER):
        os.makedirs(DIARY_FOLDER)

    entries = []
    memories = find_memories_by_npc(npc.name)
    if not memories:
        return

    for memory in memories[-3:]:  # Пишем только последние 3
        date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        entry = f"[{date}] {npc.name} записал: {memory['description']}"
        entries.append(entry)

    # Сохраняем
    diary_path = os.path.join(DIARY_FOLDER, f"{npc.name}_diary.txt")
    with open(diary_path, "a", encoding="utf-8") as f:
        for line in entries:
            f.write(line + "\n")
