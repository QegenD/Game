from npc.npc_diary_system import write_npc_diary
from npc.npc_reactions_to_memories import determine_behavior_from_memories


# npc_conflict_engine.py — зависть, конфликты, дуэли

import random

def evaluate_envy(npc, target_npc, player):
    write_npc_diary(npc)
    determine_behavior_from_memories(npc)
    if npc.get("bonded_to_player") and target_npc.get("bonded_to_player"):
        envy = random.randint(1, 10)
        if envy >= 7:
            npc["envy_target"] = target_npc["name"]
            npc["mood"] = "jealous"
            return "duel_declared"
        elif envy >= 4:
            npc["mood"] = "passive_aggressive"
            return "spreading_rumors"
    return "no_action"

def resolve_duel(npc1, npc2):
    npc1_skill = npc1.get("combat", random.randint(1, 10))
    npc2_skill = npc2.get("combat", random.randint(1, 10))
    winner = npc1 if npc1_skill >= npc2_skill else npc2
    loser = npc2 if winner is npc1 else npc1
    winner["mood"] = "triumphant"
    loser["mood"] = "ashamed"
    return f"Duel between {npc1['name']} and {npc2['name']} — Winner: {winner['name']}"
