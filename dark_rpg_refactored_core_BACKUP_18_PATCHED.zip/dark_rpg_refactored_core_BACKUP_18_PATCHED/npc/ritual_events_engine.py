
# ritual_events_engine.py — NSFW и магические ритуалы орденов

import random

NSFW_TYPES = ["оргиастический ритуал", "жертвоприношение", "ритуал похоти", "трансцендентная связь"]
MAGIC_TYPES = ["призыв сущности", "озарение знания", "печать крови", "ритуал невидимости"]

def generate_ritual(order_name, world):
    if "Крови" in order_name:
        ritual = random.choice(NSFW_TYPES)
    else:
        ritual = random.choice(MAGIC_TYPES)

    world.setdefault("ritual_log", []).append({
        "order": order_name,
        "type": ritual,
        "intensity": random.randint(1, 5)
    })
