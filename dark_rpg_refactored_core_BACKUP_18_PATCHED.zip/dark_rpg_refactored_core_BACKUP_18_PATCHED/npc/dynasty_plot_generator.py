
# dynasty_plot_generator.py — войны династий и месть за семью

import random

def generate_dynasty_response(npc, event, target_name, world):
    if event == "death_of_relative":
        if npc.get("personality") in ["vengeful", "patriotic"]:
            plot = f"{npc['name']} поклялся(-ась) отомстить за {target_name}."
            world.setdefault("dynasty_plots", []).append(plot)
            world.setdefault("rumors", []).append(plot)

    if event == "family_disgrace":
        if npc.get("personality") == "proud":
            plot = f"{npc['name']} начал кампанию по восстановлению чести рода."
            world.setdefault("dynasty_plots", []).append(plot)
            world.setdefault("rumors", []).append(plot)
