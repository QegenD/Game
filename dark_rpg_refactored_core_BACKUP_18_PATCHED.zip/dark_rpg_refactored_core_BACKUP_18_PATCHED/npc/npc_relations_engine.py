
# npc_relations_engine.py — семья, друзья, мстительные реакции

def process_relation_event(npc, world, target_name, event_type):
    for role, name in npc.get("relations", {}).items():
        if name == target_name:
            if event_type == "death":
                npc["mood"] = "mourning"
                world.setdefault("rumors", []).append(f"{npc['name']} оплакивает {target_name}.")
                if npc.get("personality") in ["vengeful", "honorable"]:
                    world.setdefault("plots", []).append(f"{npc['name']} поклялся отомстить за {target_name}.")
            elif event_type == "public_disgrace":
                npc["mood"] = "ashamed"
                world.setdefault("rumors", []).append(f"{npc['name']} стыдится поступка {target_name}.")
