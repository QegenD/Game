
# spirit_clans.py — кланы духов, взаимодействие с NPC

import random

SPIRIT_CLANS = [
    {"name": "Теневые", "element": "тьма", "goal": "распространение страха"},
    {"name": "Пепельные", "element": "прах", "goal": "уничтожение памяти"},
    {"name": "Янтарные", "element": "огонь", "goal": "поджигать души"},
    {"name": "Безмолвные", "element": "тишина", "goal": "поглощение голосов"}
]

def assign_spirit_influence(npcs):
    for npc in npcs:
        if random.random() < 0.05:
            clan = random.choice(SPIRIT_CLANS)
            npc['spirit_bound'] = clan['name']
            npc['whispers'] = f"Слышит голоса клана {clan['name']} ({clan['element']})"
