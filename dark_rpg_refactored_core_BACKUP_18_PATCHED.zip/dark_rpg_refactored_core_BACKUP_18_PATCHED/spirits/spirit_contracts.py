
# spirit_contracts.py — сделки с духами

import random

SPIRIT_OFFERS = [
    {"benefit": "увеличение силы", "price": "жертва близкого"},
    {"benefit": "вечная молодость", "price": "душа"},
    {"benefit": "власть над разумом", "price": "отказ от сна"},
    {"benefit": "неуязвимость", "price": "лишение удовольствия"},
    {"benefit": "воскрешение", "price": "потеря памяти"}
]

def propose_contract(npc_or_player):
    deal = random.choice(SPIRIT_OFFERS)
    npc_or_player["spirit_contract"] = deal
    npc_or_player["status"] = "связан с духом"
    return f"👁 Дух предлагает сделку: {deal['benefit']} за {deal['price']}."
