
# spirit_revival.py — NPC или игрок может воскреснуть через духа (цена: потеря/изменение)

import random

def attempt_spirit_revival(npc):
    if npc.get("status") == "мертв":
        deal = random.choice([
            {"price": "потеря памяти", "side_effect": "амнезия"},
            {"price": "одержимость", "side_effect": "двойственная личность"},
            {"price": "утрата человечности", "side_effect": "бессердечие"},
        ])
        npc["status"] = "воскрешён"
        npc["side_effect"] = deal["side_effect"]
        npc["revived_by"] = "дух"
        return f"☠️ {npc['name']} воскрес через духа. Цена: {deal['price']} ({deal['side_effect']})."
    return None
