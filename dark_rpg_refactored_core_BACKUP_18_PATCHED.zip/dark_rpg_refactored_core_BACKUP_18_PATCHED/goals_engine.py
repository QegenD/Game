
# goals_engine.py

class GoalsEngine:
    def __init__(self):
        self.goals = {}

    def set_goal(self, npc_id, goal):
        self.goals[npc_id] = goal

    def get_goal(self, npc_id):
        return self.goals.get(npc_id)


# --- Цели NPC и мотивации ---

class Goal:
    def __init__(self, target, goal_type, urgency=1.0):
        self.target = target
        self.goal_type = goal_type  # e.g. 'seduce', 'avoid', 'dominate', 'protect'
        self.urgency = urgency

    def __repr__(self):
        return f"[{self.goal_type.upper()} {self.target} — urgency {self.urgency}]"

class GoalEngine:
    def __init__(self):
        self.goals = []  # List of Goal

    def generate_goals_from_emotions(self, npc_name, emotion_profile):
        emotions = emotion_profile.describe_emotions(npc_name)
        new_goals = []
        for target, emotions in emotion_profile.emotions.items():
            desire = emotions.get("desire", 0)
            fear = emotions.get("fear", 0)
            anger = emotions.get("anger", 0)
            if desire > 50:
                new_goals.append(Goal(target, "seduce", urgency=desire / 100))
            if fear > 50:
                new_goals.append(Goal(target, "avoid", urgency=fear / 100))
            if anger > 50:
                new_goals.append(Goal(target, "attack", urgency=anger / 100))
        self.goals.extend(new_goals)

    def get_goals(self):
        return self.goals

    def clear_goals(self):
        self.goals = []
