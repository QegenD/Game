
# auto_image_generator_hooks/interrogation_visuals.py — визуализация допросов и пыток

from imagegen.auto_image_generator import generate_image

def render_interrogation_scene(npc, scene_type="interrogation"):
    description = f"{npc.name} is restrained in a dimly lit chamber, bruised and bloodied. Torture instruments are visible nearby. Mood: {npc.mood}."
    image_path = generate_image(
        prompt=description,
        context_tags=["torture", "interrogation", npc.faction, npc.race],
        target="interrogation"
    )
    npc.last_generated_image = image_path
    return image_path
