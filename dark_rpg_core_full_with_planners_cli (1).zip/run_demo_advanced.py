from dark_rpg_refactored_core_BACKUP_18_PATCHED.world_master import World, Entity
from dark_rpg_refactored_core_BACKUP_18_PATCHED.items import get_item
from dark_rpg_refactored_core_BACKUP_18_PATCHED.planner_advanced import AdvancedPlanner
from dark_rpg_refactored_core_BACKUP_18_PATCHED.actions import Action

w = World()
a = Entity("Hero", pos=(1,1)); a.inv.add(get_item("sword")); a.inv.add(get_item("potion"),2); a.skills.add("melee",2)
b = Entity("Gob", pos=(2,1)); b.inv.add(get_item("potion"),1); b.hp = 6
w.add_entity(a); w.add_entity(b)

planner = AdvancedPlanner(w, beam_width=4, max_depth=3)
plan = planner.plan("Hero", goal={'type':'loot'})
print("Planned actions:")
for p in plan:
    print(p.name, p.params)
# Execute plan step by step
for step in plan:
    ok, msg, data = w.do_action("Hero", step)
    print("->", ok, msg)
print("Chronicles:", w.chronicles.as_text())

