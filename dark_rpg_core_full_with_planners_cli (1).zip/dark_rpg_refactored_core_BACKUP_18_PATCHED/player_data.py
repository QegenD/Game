import json
import os

DEFAULT_PLAYER = {
    "name": "Герой",
    "class": "воин",
    "level": 1,
    "hp": 30,
    "attack": 6,
    "defense": 3,
    "agility": 2,
    "charisma": 1,
    "inventory": [],
    "xp": 0
}

def load_player(user_id='1'):
    filename = f"player_{user_id}.json"
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT_PLAYER.copy()

def save_player(player_data, user_id='1'):
    filename = f"player_{user_id}.json"
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(player_data, f, ensure_ascii=False, indent=2)



# --- Player Psychology ---
class PlayerMind:
    def __init__(self):
        self.traits = []  # Например: ["садист", "эмпат"]
        self.kinks = []
        self.psych_flags = {}

    def add_trait(self, trait):
        if trait not in self.traits:
            self.traits.append(trait)

    def track_consequence(self, tag, level):
        self.psych_flags[tag] = self.psych_flags.get(tag, 0) + level



# --- Disguise System ---
class Disguise:
    def __init__(self, fake_faction, traits):
        self.faction = fake_faction
        self.traits = traits



# --- Player Titles System ---
def assign_title(player, title):
    if title not in player.titles:
        player.titles.append(title)

def evaluate_titles(player):
    if player.karma < -50:
        assign_title(player, "Извращённый")
    elif player.faction_reputation.get("Церковь", 0) > 70:
        assign_title(player, "Осквернённый святой")
