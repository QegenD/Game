from dataclasses import dataclass
from typing import Dict, Any
import random

@dataclass
class CombatLog:
    attacker: str
    defender: str
    hit: bool
    damage: int
    crit: bool
    remaining_hp: int
    notes: str = ""

def calculate_damage(attack: int, defense: int) -> int:
    base = max(1, attack - defense)
    variance = random.randint(0, base)
    return max(0, base + variance)

def perform_attack(attacker: Dict[str, Any], defender: Dict[str, Any]) -> CombatLog:
    atk = attacker.get("attack", 5) + sum(attacker.get("attack_bonuses", []))
    dfs = defender.get("defense", 2) + sum(defender.get("defense_bonuses", []))
    hp = defender.get("hp", 10)
    crit_chance = attacker.get("crit_chance", 0.05)
    notes = ""

    # to-hit curve with soft clamp
    hit_prob = max(0.05, min(0.95, 0.65 + (atk - dfs) * 0.03))
    hit_roll = random.random() < hit_prob
    crit = False
    dmg = 0
    if hit_roll:
        dmg = calculate_damage(atk, dfs)
        if random.random() < crit_chance:
            crit = True
            dmg = int(dmg * 1.8)
        # apply resistances
        resist = defender.get("resist", 0)
        dmg = max(0, dmg - resist)
        hp = max(0, hp - dmg)
    else:
        notes = "miss"

    return CombatLog(attacker=attacker.get("name","?"),
                     defender=defender.get("name","?"),
                     hit=hit_roll,
                     damage=dmg,
                     crit=crit,
                     remaining_hp=hp,
                     notes=notes)

