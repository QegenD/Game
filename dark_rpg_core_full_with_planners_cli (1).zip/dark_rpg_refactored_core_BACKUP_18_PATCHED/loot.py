import random
from typing import List
from .items import get_item

COMMON = ["potion"]
UNCOMMON = ["sword","leather"]
RARE = ["bow","chain"]

def drop_table(tier: int = 1) -> List[str]:
    pool = COMMON + (UNCOMMON if tier>=2 else []) + (RARE if tier>=3 else [])
    return random.sample(pool, k=min(1+tier//2, len(pool)))

