# llm_adapter.py - stub for integrating an LLM. By default it uses a local heuristic.
from typing import Any, Dict

class LLMAdapter:
    def __init__(self, provider=None):
        self.provider = provider  # user can set to callable for external LLM

    def generate_intent(self, prompt: str) -> Dict[str, Any]:
        # Default heuristic mapping for demo; users can replace provider with real LLM call
        p = prompt.lower()
        if 'attack' in p:
            return {'intent': 'attack'}
        if 'trade' in p or 'buy' in p:
            return {'intent': 'trade'}
        if 'rest' in p or 'sleep' in p:
            return {'intent': 'rest'}
        return {'intent': 'wait'}

