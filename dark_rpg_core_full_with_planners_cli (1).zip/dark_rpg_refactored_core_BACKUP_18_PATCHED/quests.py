from dataclasses import dataclass, field
from typing import Dict, List

@dataclass
class Quest:
    id: str
    name: str
    stages: List[str]
    current: int = 0
    done: bool = False

    def progress(self, steps: int = 1):
        if self.done: return
        self.current = min(len(self.stages)-1, self.current + steps)
        if self.current == len(self.stages)-1:
            self.done = True

@dataclass
class QuestLog:
    quests: Dict[str, Quest] = field(default_factory=dict)

    def add(self, q: Quest):
        self.quests[q.id] = q

    def tick(self):
        # placeholder for timed quests
        pass

