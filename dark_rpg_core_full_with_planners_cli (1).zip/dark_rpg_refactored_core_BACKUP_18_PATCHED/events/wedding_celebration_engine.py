
# wedding_celebration_engine.py — Торжества, заговоры и сцены на свадьбах

import random

def generate_celebration_scene(npc1, npc2):
    moods = ["радость", "напряжение", "ревность", "скандал", "NSFW", "покушение"]
    mood = random.choices(
        moods,
        weights=[4, 2, 1, 1, 2, 1],  # Частота каждой сцены
        k=1
    )[0]

    if mood == "радость":
        return {
            "type": "пир",
            "description": f"Свадьба {npc1['name']} и {npc2['name']} проходит в атмосфере счастья. Все радуются."
        }
    elif mood == "напряжение":
        return {
            "type": "молчаливая зависть",
            "description": f"Некоторые гости напряжены, чувствуется скрытое недовольство свадьбой {npc1['name']} и {npc2['name']}."
        }
    elif mood == "ревность":
        return {
            "type": "конфликт",
            "description": f"Бывший любовник одного из молодожёнов устроил сцену прямо во время пиршества."
        }
    elif mood == "скандал":
        return {
            "type": "публичное разоблачение",
            "description": f"На свадьбе раскрыт тёмный секрет одной из сторон. Гости в шоке."
        }
    elif mood == "NSFW":
        return {
            "type": "ночь страсти",
            "description": f"Сцена первой ночи между {npc1['name']} и {npc2['name']} полна страсти. Некоторые гости подглядывают."
        }
    elif mood == "покушение":
        return {
            "type": "попытка убийства",
            "description": f"Во время свадьбы совершается покушение на одного из гостей или молодожёнов."
        }

    return {"type": "неожиданность", "description": "Что-то странное произошло."}
