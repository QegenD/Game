
# marriage_grief_and_divorce.py — реакции NPC на смерть, разводы, траур

import random

def handle_spouse_death(npc, spouse):
    reactions = [
        f"{npc['name']} впадает в глубокий траур после смерти {spouse['name']}.",
        f"{npc['name']} обещает отомстить за смерть {spouse['name']}.",
        f"{npc['name']} устраивает величественные похороны в честь {spouse['name']}."
    ]
    return random.choice(reactions)

def handle_divorce(npc1, npc2):
    outcomes = [
        f"{npc1['name']} и {npc2['name']} расходятся мирно, но отношения между их династиями напряжены.",
        f"{npc1['name']} обвиняет {npc2['name']} в предательстве. Война между родами на горизонте.",
        f"{npc2['name']} покидает город после громкого развода с {npc1['name']}."
    ]
    return random.choice(outcomes)
