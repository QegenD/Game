
# public_judgement_engine.py — суды, линчевания, штрафы

import random

def try_trigger_trial(player_reputation, crimes, charisma, gold):
    threshold = 7 + len(crimes)
    risk = player_reputation + charisma - len(crimes)
    if risk < random.randint(0, threshold):
        return "trial_summoned"
    return "avoided"

def resolve_trial(world, player, charisma, gold):
    outcome = {}
    jury_bias = random.randint(0, 10) + charisma + gold // 100
    if jury_bias < 8:
        outcome["verdict"] = "guilty"
        if random.random() < 0.5:
            outcome["punishment"] = "exile"
        else:
            outcome["punishment"] = "public_execution"
    else:
        outcome["verdict"] = "innocent"
        outcome["reward"] = "public_trust"
    world.setdefault("events", []).append(f"Trial completed: {outcome}")
    return outcome
