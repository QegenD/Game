from dataclasses import dataclass, field
from typing import List, Dict, Any
import time

@dataclass
class ChronicleEntry:
    ts: float
    type: str
    data: Dict[str, Any]

@dataclass
class Chronicles:
    entries: List[ChronicleEntry] = field(default_factory=list)

    def log(self, type: str, **data):
        entry = ChronicleEntry(ts=time.time(), type=type, data=data)
        self.entries.append(entry)
        return entry

    def as_text(self, limit: int = 50) -> str:
        out = []
        for e in self.entries[-limit:]:
            out.append(f"[{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(e.ts))}] {e.type}: {e.data}")
        return "\n".join(out)

    def to_json(self) -> str:
        return json.dumps([e.__dict__ for e in self.entries], ensure_ascii=False, indent=2)
