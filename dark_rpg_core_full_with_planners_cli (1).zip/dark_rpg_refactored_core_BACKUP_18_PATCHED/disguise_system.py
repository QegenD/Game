from dataclasses import dataclass

@dataclass
class Disguise:
    level: int = 0      # 0..100 effectiveness
    notoriety: int = 0  # 0..100 makes it harder to hide

def detect(disguise: Disguise, observer_skill: int = 50) -> bool:
    """Return True if observer sees through the disguise."""
    # Simple opposed check
    effective = max(0, disguise.level - disguise.notoriety)
    # Base chance that disguise holds
    hold = 0.5 + (effective - observer_skill) * 0.005
    import random
    return random.random() > max(0.05, min(0.95, hold))
