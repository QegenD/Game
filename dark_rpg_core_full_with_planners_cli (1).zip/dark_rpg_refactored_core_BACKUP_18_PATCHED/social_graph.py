from dataclasses import dataclass, field
from typing import Dict, Tuple

Key = Tuple[str, str]

def clamp(x, a=-100.0, b=100.0):
    return max(a, min(b, x))

@dataclass
class SocialGraph:
    relations: Dict[Key, float] = field(default_factory=dict)

    def get(self, a: str, b: str) -> float:
        if a == b: return 100.0
        return self.relations.get((a,b), 0.0)

    def set(self, a: str, b: str, score: float):
        score = clamp(score)
        self.relations[(a,b)] = score
        self.relations[(b,a)] = score

    def add(self, a: str, b: str, delta: float):
        self.set(a, b, self.get(a,b) + delta)

    def befriend(self, a: str, b: str, amount: float = 10.0):
        self.add(a, b, abs(amount))

    def enmity(self, a: str, b: str, amount: float = 10.0):
        self.add(a, b, -abs(amount))

    def are_allies(self, a: str, b: str) -> bool:
        return self.get(a,b) >= 40.0

    def are_enemies(self, a: str, b: str) -> bool:
        return self.get(a,b) <= -40.0
