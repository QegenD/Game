
# npc_schedule.py
class NPCSchedule:
    def __init__(self, npc_name):
        self.npc_name = npc_name
        self.schedule = {
            "утро": "молитва",
            "день": "работа",
            "вечер": "исчезает",
            "ночь": "в тайном месте"
        }

    def get_schedule(self):
        return dict(self.schedule)

    def modify_schedule(self, time, new_activity):
        if time in self.schedule:
            self.schedule[time] = new_activity

# --- Система расписаний NPC ---

class DailySchedule:
    def __init__(self, npc_name):
        self.npc_name = npc_name
        self.slots = {
            "morning": "sleeping",
            "day": "wandering",
            "evening": "socializing",
            "night": "resting"
        }

    def set_slot(self, time_slot, activity):
        if time_slot in self.slots:
            self.slots[time_slot] = activity

    def get_slot(self, time_slot):
        return self.slots.get(time_slot, "idle")

    def render_schedule(self):
        print(f"📅 Расписание для {self.npc_name}:")
        for slot, activity in self.slots.items():
            print(f" - {slot.capitalize()}: {activity}")

    def as_dict(self):
        return self.slots


# --- AI-навигация по карте ---

class NPCTravelPlanner:
    def __init__(self, npc_name, world_map, home_region):
        self.npc_name = npc_name
        self.map = world_map
        self.current_region = home_region
        self.destination = None
        self.route = []

    def set_destination(self, destination):
        self.destination = destination
        self.route = self.map.shortest_path(self.current_region, destination)

    def move_one_step(self):
        if self.route and len(self.route) > 1:
            # Удаляем текущую позицию и переходим в следующую
            self.route.pop(0)
            self.current_region = self.route[0]
            return self.current_region
        return self.current_region
