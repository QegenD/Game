
# logic/conspiracies.py

import random

class ConspiracySystem:
    def __init__(self, npcs):
        self.npcs = npcs
        self.active_conspiracies = []

    def seed_conspiracies(self):
        candidates = [npc for npc in self.npcs if npc.get("role") in ["жрец", "маг", "дворянин", "советник"]]
        random.shuffle(candidates)
        for npc in candidates[:3]:
            target = random.choice(["Король", "Совет", "Глава клана", "Церковь", "Гильдия"])
            plan = random.choice(["убийство", "смена власти", "подделка пророчества", "перехват финансирования"])
            conspiracy = {
                "initiator": npc["name"],
                "target": target,
                "plan": plan,
                "status": "тайно"
            }
            self.active_conspiracies.append(conspiracy)

    def advance_conspiracies(self):
        outcomes = []
        for conspiracy in self.active_conspiracies:
            roll = random.random()
            if roll < 0.3:
                conspiracy["status"] = "провалено"
                outcomes.append(f"Заговор {conspiracy['plan']} против {conspiracy['target']} провалился.")
            elif roll < 0.6:
                conspiracy["status"] = "раскрыто"
                outcomes.append(f"Заговор против {conspiracy['target']} раскрыт! Начаты преследования.")
            else:
                conspiracy["status"] = "успешно"
                outcomes.append(f"Заговор {conspiracy['plan']} против {conspiracy['target']} успешно завершён.")
        return outcomes

    def get_all_conspiracies(self):
        return self.active_conspiracies


# --- Система заговоров и интриг ---

import random

class Conspiracy:
    def __init__(self, conspirators, target, type, success_chance=0.5):
        self.conspirators = conspirators  # список NPC-имен
        self.target = target  # NPC-цель
        self.type = type  # e.g. 'assassinate', 'blackmail', 'seduce', 'discredit'
        self.success_chance = success_chance
        self.status = "planned"

    def execute(self):
        roll = random.random()
        if roll <= self.success_chance:
            self.status = "successful"
            return f"Заговор ({self.type}) против {self.target} завершён УСПЕШНО."
        else:
            self.status = "failed"
            return f"Заговор ({self.type}) против {self.target} ПРОВАЛЕН."

    def __repr__(self):
        return f"[{self.type.upper()} → {self.target}] by {', '.join(self.conspirators)} | status: {self.status}"

class ConspiracyNetwork:
    def __init__(self):
        self.plots = []

    def plan_conspiracy(self, conspirators, target, type):
        plot = Conspiracy(conspirators, target, type)
        self.plots.append(plot)
        return plot

    def execute_all(self):
        return [plot.execute() for plot in self.plots if plot.status == "planned"]

    def get_active_plots(self):
        return [p for p in self.plots if p.status == "planned"]

    def get_all_plots(self):
        return self.plots
