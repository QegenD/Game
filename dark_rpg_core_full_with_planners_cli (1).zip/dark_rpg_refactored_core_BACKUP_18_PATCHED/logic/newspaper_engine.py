
# --- Генератор газет на основе хроники и слухов ---

import json
from datetime import datetime

NEWS_PATH = "data/newspapers.json"

def generate_newspaper(title="Вестник Королевства"):
    # Загружаем хронику и слухи
    try:
        with open("data/world_log.json", "r", encoding="utf-8") as f:
            log = json.load(f)[-10:]
    except Exception:
        log = []

    try:
        with open("data/rumors.json", "r", encoding="utf-8") as f:
            rumors = json.load(f)[-10:]
    except Exception:
        rumors = []

    entries = []
    for item in log:
        headline = f"{item.get('faction', 'Неизвестно')} совершает: {item.get('action', 'действие')}"
        entries.append({"type": "event", "headline": headline})

    for r in rumors:
        entries.append({
            "type": "rumor",
            "headline": f"Слух: {r['text']}"
        })

    newspaper = {
        "title": title,
        "date": datetime.utcnow().strftime("%Y-%m-%d"),
        "articles": entries
    }

    # Сохраняем
    try:
        with open(NEWS_PATH, "r", encoding="utf-8") as f:
            existing = json.load(f)
    except:
        existing = []

    existing.append(newspaper)
    with open(NEWS_PATH, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2)

    return newspaper
