
# --- Модуль карты мира и навигации AI ---

import networkx as nx

class WorldMap:
    def __init__(self):
        self.graph = nx.Graph()

    def add_region(self, name):
        self.graph.add_node(name)

    def connect_regions(self, region1, region2, weight=1):
        self.graph.add_edge(region1, region2, weight=weight)

    def shortest_path(self, start, end):
        try:
            return nx.shortest_path(self.graph, start, end, weight='weight')
        except nx.NetworkXNoPath:
            return None

    def all_regions(self):
        return list(self.graph.nodes)

    def neighbors(self, region):
        return list(self.graph.neighbors(region))

    def draw_map(self):
        import matplotlib.pyplot as plt
        pos = nx.spring_layout(self.graph)
        nx.draw(self.graph, pos, with_labels=True, node_color='lightblue')
        plt.title("Карта мира")
        plt.show()
