
# --- Скрытые личности и разоблачения ---

class HiddenIdentity:
    def __init__(self, npc_name, true_identity, secrets=None):
        self.npc_name = npc_name
        self.true_identity = true_identity
        self.secrets = secrets or []
        self.revealed = False

    def reveal(self):
        self.revealed = True
        return f"Личность {self.npc_name} раскрыта! Это {self.true_identity}."

    def conceal(self):
        self.revealed = False

    def is_revealed(self):
        return self.revealed

    def __repr__(self):
        return f"HiddenIdentity({self.npc_name} as {self.true_identity}) {'[REVEALED]' if self.revealed else ''}"
