
# generator.py — генерация изображений каждой стадии ритуала

def generate_ritual_stage(stage_name, god_domain, mood="intense", nsfw=False):
    base = f"ritual stage: {stage_name}, atmosphere: {mood}, symbols of {god_domain}, "
    if nsfw:
        base += "nudity, ecstasy, flesh, blood, "
    base += "dark fantasy, hyperrealism"
    return base
