
# --- NSFW Обучение и тренеры ---

class NSFWTrainer:
    def __init__(self, name, specializations):
        self.name = name
        self.specializations = specializations  # список техник

    def can_teach(self, technique):
        return technique in self.specializations

    def teach(self, player, technique):
        if self.can_teach(technique):
            player.psyche.learn_technique(technique)
            return f"{self.name} обучил вас технике: {technique}"
        else:
            return f"{self.name} не знает технику {technique}"
