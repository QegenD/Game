
# --- Движок мировых кризисов ---

import random
import json
from datetime import datetime

CRISIS_PATH = "data/world_crises.json"

class Crisis:
    TYPES = [
        "Чума", "Голод", "Война", "Религиозный фанатизм", "Демоническое вторжение", "Восстание рабов"
    ]

    def __init__(self):
        self.type = random.choice(self.TYPES)
        self.region = random.choice(["Север", "Юг", "Запад", "Восток", "Столица", "Колонии"])
        self.intensity = random.randint(1, 10)
        self.start_time = datetime.utcnow().isoformat()

    def to_dict(self):
        return {
            "type": self.type,
            "region": self.region,
            "intensity": self.intensity,
            "start_time": self.start_time
        }

def spawn_crisis():
    crisis = Crisis()
    try:
        with open(CRISIS_PATH, "r", encoding="utf-8") as f:
            crises = json.load(f)
    except:
        crises = []

    crises.append(crisis.to_dict())
    with open(CRISIS_PATH, "w", encoding="utf-8") as f:
        json.dump(crises, f, indent=2)

    return crisis
