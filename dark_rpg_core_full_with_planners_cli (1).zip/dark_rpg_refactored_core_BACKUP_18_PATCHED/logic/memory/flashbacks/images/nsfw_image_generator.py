
# nsfw_image_generator.py — генерация изображений к NSFW-воспоминаниям

from random import choice

TAGS_TO_STYLES = {
    "романтика": "soft lighting, loving embrace, dreamy",
    "жесткость": "dark room, rough shadows, intense expression",
    "новизна": "curious gaze, experimentation, soft chaos",
    "унизительность": "shameful posture, dim lighting, submissive pose",
    "одержимость": "wild eyes, desperate touch, obsession tone",
}

def generate_nsfw_image_from_tags(tags):
    prompt = ", ".join([TAGS_TO_STYLES.get(tag, tag) for tag in tags])
    return f"NSFW-IMG({prompt})"
