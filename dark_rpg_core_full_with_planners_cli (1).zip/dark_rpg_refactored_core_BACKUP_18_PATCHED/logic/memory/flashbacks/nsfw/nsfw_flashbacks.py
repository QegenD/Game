
# nsfw_flashbacks.py — NSFW-флешбеки, отдельная память

class NSFWFlashbackMemory:
    def __init__(self, character):
        self.character = character
        self.scenes = []

    def record_scene(self, description, tags=None):
        self.scenes.append({
            "description": description,
            "tags": tags or [],
        })

    def recall_recent(self, tag_filter=None):
        if tag_filter:
            return [s for s in self.scenes if any(tag in s['tags'] for tag in tag_filter)]
        return self.scenes[-3:]

    def get_all_memories(self):
        return [f"[{'/'.join(s['tags'])}] {s['description']}" for s in self.scenes]
