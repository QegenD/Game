
# combat_style.py — боевой стиль на основе характеристик

def get_combat_style(character):
    style = []

    if character.race == "орк":
        style.append("агрессивный стиль")
    elif character.race == "эльф":
        style.append("ловкий стиль")
    elif character.race == "человек":
        style.append("сбалансированный стиль")

    if character.character_class == "воин":
        style.append("тяжёлые удары")
    elif character.character_class == "маг":
        style.append("дистанционная магия")
    elif character.character_class == "ассасин":
        style.append("скрытные атаки")

    if character.faction == "инквизиция":
        style.append("святой боевой обет")
    elif character.faction == "культ":
        style.append("ритуальная жестокость")
    elif character.faction == "кланы":
        style.append("честь и ярость")

    return style
