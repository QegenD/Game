
# --- Простая боевая система с насилием и расчлёнкой ---

import random

class Combatant:
    def __init__(self, name, hp=100, attack=10, defense=5, gore_enabled=False):
        self.name = name
        self.hp = hp
        self.attack = attack
        self.defense = defense
        self.gore_enabled = gore_enabled
        self.dead = False

    def take_damage(self, amount):
        self.hp -= amount
        if self.hp <= 0:
            self.dead = True
            if self.gore_enabled:
                return self._gore_death()
            else:
                return f"{self.name} погибает."
        return f"{self.name} получает {amount} урона. Осталось {self.hp} HP."

    def attack_target(self, other):
        if self.dead:
            return f"{self.name} мёртв и не может атаковать."
        damage = max(0, self.attack + random.randint(-3, 3) - other.defense)
        result = other.take_damage(damage)
        return f"{self.name} атакует {other.name} на {damage} урона. {result}"

    def _gore_death(self):
        method = random.choice([
            f"голова {self.name} взрывается от удара",
            f"тело {self.name} разрывает пополам",
            f"кишки {self.name} выпадают наружу",
            f"конечности {self.name} оторваны в клочья"
        ])
        return f"{self.name} погибает с расчлёнкой: {method}!"
