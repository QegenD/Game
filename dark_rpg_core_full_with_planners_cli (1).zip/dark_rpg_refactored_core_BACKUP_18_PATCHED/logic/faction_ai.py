
# --- AI-поведение фракций и стратегические кампании ---

import random
import json
from datetime import datetime

class FactionAI:
    def __init__(self, name, influence=100, agents=None, territory=None):
        self.name = name
        self.influence = influence
        self.agents = agents or []
        self.territory = territory or []
        self.goal = "Expand Influence"

    def tick(self):
        if self.influence > 200:
            return self.launch_operation()
        elif self.influence < 50:
            return self.defend_position()
        else:
            return self.grow_slowly()

    def launch_operation(self):
        ops = ["Assassinate NPC", "Subvert Region", "Declare War", "Forge Alliance"]
        op = random.choice(ops)
        result = {
            "time": datetime.utcnow().isoformat(),
            "faction": self.name,
            "type": "operation",
            "action": op
        }
        self.influence -= random.randint(10, 30)
        self._log(result)
        return result

    def defend_position(self):
        result = {
            "time": datetime.utcnow().isoformat(),
            "faction": self.name,
            "type": "defense",
            "action": "Fortify Region or Recruit"
        }
        self.influence += random.randint(5, 15)
        self._log(result)
        return result

    def grow_slowly(self):
        self.influence += random.randint(1, 10)
        return {
            "faction": self.name,
            "type": "passive_growth",
            "influence_now": self.influence
        }

    def _log(self, entry):
        try:
            with open("data/world_log.json", "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = []
        data.append(entry)
        with open("data/world_log.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
