
# player_rituals.py — участие игрока в ритуалах

class PlayerRitualHandler:
    def __init__(self, player, world):
        self.player = player
        self.world = world

    def offer_participation(self, cult, ritual_type, region):
        if cult in self.player.known_cults:
            self.world.log_event(f"🧍 Игрок может участвовать в ритуале '{ritual_type}' культа '{cult}' в регионе {region}")
            return True
        return False

    def participate(self, ritual_type):
        if ritual_type == "blood":
            self.player.traits.add("жажда крови")
            self.player.sanity -= 10
        elif ritual_type == "lust":
            self.player.add_fetish("ритуальный экстаз")
            self.player.reputation["порочность"] += 5
        elif ritual_type == "light":
            self.player.blessings.add("просветление")
        elif ritual_type == "death":
            self.player.sanity -= 5
            self.player.abilities.add("некровидение")
