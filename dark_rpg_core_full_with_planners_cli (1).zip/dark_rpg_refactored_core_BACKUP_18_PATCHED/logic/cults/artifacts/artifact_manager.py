
# artifact_manager.py — артефакты, создаваемые и используемые культами

import random

class CultArtifact:
    def __init__(self, name, power_type, description):
        self.name = name
        self.power_type = power_type
        self.description = description
        self.used_in_rituals = 0

    def use_in_ritual(self):
        self.used_in_rituals += 1
        return f"{self.name} активирован. Эффект: {self.power_type}"

def generate_artifact(cult_name, domain):
    base_names = {
        "blood": ["Кровавая Печать", "Алый Кинжал"],
        "lust": ["Соблазнительница Тьмы", "Нефритовая Маска"],
        "death": ["Урна Пепла", "Мрачный Череп"],
        "light": ["Светоч", "Око Милосердия"]
    }
    name = random.choice(base_names.get(domain, ["Неизвестный Артефакт"]))
    power = f"усиливает ритуалы в домене {domain}"
    return CultArtifact(f"{name} {cult_name}", domain, power)
