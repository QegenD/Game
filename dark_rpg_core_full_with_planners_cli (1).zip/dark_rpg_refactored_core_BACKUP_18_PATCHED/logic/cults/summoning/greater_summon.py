
# greater_summon.py — сложные ритуалы вызова высших сущностей

import random

class GreaterSummon:
    def __init__(self, ritual_power, cult, location):
        self.ritual_power = ritual_power
        self.cult = cult
        self.location = location

    def attempt_summon(self):
        if self.ritual_power > 80 and self.location.is_attuned_to(self.cult):
            entity = random.choice(["Древний Демон", "Дух Света", "Безликое Зло", "Оракул"])
            self.location.spawn_entity(entity)
            self.location.corrupt_or_enlighten(entity)
            return f"🕯️ Сущность призвана: {entity}"
        return "Ритуал провален: недостаточно силы или место не подходящее"
