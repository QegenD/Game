
# religious_conflict.py — конфликты между культами, войны за веру

import random

class ReligiousConflictManager:
    def __init__(self, cults):
        self.cults = cults  # список всех культов

    def detect_conflicts(self):
        conflicts = []
        for i, c1 in enumerate(self.cults):
            for c2 in self.cults[i+1:]:
                if self._doctrines_conflict(c1, c2):
                    conflicts.append((c1.name, c2.name))
        return conflicts

    def _doctrines_conflict(self, c1, c2):
        return bool(set(c1.doctrine) & set(c2.doctrine) == False)

    def resolve_conflict(self, c1, c2):
        result = random.choice([c1.name, c2.name, "stalemate"])
        return f"⚔️ Конфликт между {c1.name} и {c2.name} закончился: {result}"
