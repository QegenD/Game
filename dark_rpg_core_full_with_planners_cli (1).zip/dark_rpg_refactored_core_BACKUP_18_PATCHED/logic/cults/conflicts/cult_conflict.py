
# cult_conflict.py — войны между культами за влияние

import random

class CultConflictManager:
    def __init__(self, world):
        self.world = world

    def resolve_conflict(self, cult1, cult2, region):
        winner = random.choice([cult1, cult2])
        loser = cult2 if winner == cult1 else cult1

        self.world.log_event(f"⚔️ Конфликт культов '{cult1}' и '{cult2}' в регионе {region}: победил '{winner}'")
        region.remove_cult_influence(loser)
        region.boost_influence(winner, amount=2)
