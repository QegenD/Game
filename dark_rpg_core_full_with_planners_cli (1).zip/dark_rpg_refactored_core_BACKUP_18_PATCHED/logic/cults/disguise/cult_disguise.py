
# cult_disguise.py — NPC и игрок могут скрывать свою принадлежность к культу

class CultDisguise:
    def __init__(self, character):
        self.character = character

    def activate_disguise(self):
        self.character.traits.add("маскируется")
        self.character.reputation["ересь"] = max(0, self.character.reputation.get("ересь", 0) - 10)

    def is_masked(self):
        return "маскируется" in self.character.traits
