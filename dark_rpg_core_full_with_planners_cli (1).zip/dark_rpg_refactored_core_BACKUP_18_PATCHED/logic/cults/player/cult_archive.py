
# cult_archive.py — хроника культа игрока

class CultArchive:
    def __init__(self):
        self.records = []

    def log_event(self, event):
        self.records.append(event)

    def get_chronicle(self):
        return "\n".join(self.records[-25:])  # последние 25 записей

    def save_to_scroll(self):
        return "\n".join(self.records)
