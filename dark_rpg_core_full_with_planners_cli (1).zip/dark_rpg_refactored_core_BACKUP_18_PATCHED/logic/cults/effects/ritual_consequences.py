
# ritual_consequences.py — эффекты ритуалов: метки, мутации, зависимости

import random

class RitualConsequences:
    def __init__(self, character):
        self.character = character

    def apply_random_consequence(self):
        consequence = random.choice([
            "метка культа", "зависимость от ритуалов",
            "мутация тела", "потеря рассудка", "усиление способностей"
        ])
        self.character.status_effects.append(consequence)
        self.character.log(f"Ритуал оставил последствия: {consequence}")
