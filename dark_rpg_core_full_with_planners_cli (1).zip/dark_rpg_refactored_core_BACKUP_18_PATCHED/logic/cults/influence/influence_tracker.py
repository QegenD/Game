
# influence_tracker.py — влияние культов на регионы мира

class CultInfluenceTracker:
    def __init__(self):
        self.region_influence = {}  # region_id -> {cult_name: influence_value}

    def update_influence(self, region_id, cult_name, value):
        if region_id not in self.region_influence:
            self.region_influence[region_id] = {}
        self.region_influence[region_id][cult_name] = self.region_influence[region_id].get(cult_name, 0) + value

    def get_influence(self, region_id):
        return self.region_influence.get(region_id, {})

    def most_influential(self, region_id):
        influence = self.get_influence(region_id)
        if not influence:
            return None
        return max(influence, key=influence.get)
