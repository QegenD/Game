
# cult_destruction.py — уничтожение культов игроком или фракциями

class CultDestructionManager:
    def __init__(self, cults, world):
        self.cults = cults
        self.world = world

    def destroy_cult(self, cult_name, reason="eradicated by force"):
        if cult_name not in self.cults:
            return f"Культ '{cult_name}' не найден."

        # Удаление влияния, артефактов, последователей
        self._purge_influence(cult_name)
        self._remove_artifacts(cult_name)
        self._exile_followers(cult_name)

        del self.cults[cult_name]
        self.world.log_event(f"☠️ Культ '{cult_name}' уничтожен. Причина: {reason}")
        return f"Культ '{cult_name}' был успешно уничтожен."

    def _purge_influence(self, cult_name):
        for region in self.world.regions:
            region.remove_cult_influence(cult_name)

    def _remove_artifacts(self, cult_name):
        self.world.artifact_registry = [
            art for art in self.world.artifact_registry if cult_name not in art.name
        ]

    def _exile_followers(self, cult_name):
        for npc in self.world.npcs:
            if getattr(npc, 'cult', None) == cult_name:
                npc.exile(reason="cult purging")
