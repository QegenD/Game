
# --- Запуск генерации мира, NPC, фракций, тайн, слухов, кризисов, сцен ---

import os
import random
import json

from logic.faction_ai import FactionAI
from logic.avatar_generator import save_avatar_data
from logic.rumor_system import generate_random_rumor, spread_rumor
from logic.deep_secrets import assign_secret
from logic.crisis_engine import spawn_crisis
from logic.gallery_manager import save_gallery_entry
from logic.newspaper_engine import generate_newspaper

NPC_PATH = "data/npc_data.json"
FACTIONS = ["Культ Пепла", "Черная Гильдия", "Королевский Дом", "Дикие Врата"]

def init_npcs(count=20):
    npcs = []
    for i in range(count):
        npc = {
            "id": f"npc_{i}",
            "name": f"NPC #{i}",
            "faction": random.choice(FACTIONS),
            "tags": random.sample(["noble", "commoner", "criminal", "mage", "warrior"], 2),
            "style": random.choice(["gothic", "elegant", "tribal", "military"])
        }
        npcs.append(npc)
        save_avatar_data(npc)
        assign_secret(npc["id"])
        rumor = generate_random_rumor(npcs)
        spread_rumor(rumor)
        if random.random() < 0.3:
            save_gallery_entry([npc["id"]], scene_type="forbidden encounter", tags=npc["tags"])
    with open(NPC_PATH, "w", encoding="utf-8") as f:
        json.dump(npcs, f, indent=2)

def init_factions():
    for name in FACTIONS:
        faction = FactionAI(name, influence=random.randint(80, 200))
        faction.tick()

def init_crises(count=2):
    for _ in range(count):
        spawn_crisis()

def init_newspaper():
    generate_newspaper()

def initialize_world():
    init_npcs()
    init_factions()
    init_crises()
    init_newspaper()
