from journal_and_reputation import QUEST_LOG
from quest_system import PLAYER_REPUTATION

def get_npc_quest_reaction(npc_name):
    failed = [q for q in QUEST_LOG if q["status"] == "провален"]
    completed = [q for q in QUEST_LOG if q["status"] == "выполнен"]
    score = len(completed) - len(failed)
    if score >= 3:
        return f"{npc_name} с уважением смотрит на вас — слава об успехах дошла до него."
    elif score <= -2:
        return f"{npc_name} презрительно морщится, вспоминая вашу репутацию неудачника."
    else:
        return f"{npc_name} оценивает вас сдержанно, не видя особых причин доверять."



# --- Long-term Emotional Memory ---
class EmotionalMemory:
    def __init__(self):
        self.events = []

    def add(self, event_type, intensity=1):
        self.events.append({"type": event_type, "intensity": intensity})
        if event_type == "оскорбление":
            self.become_trait("мстительный")

    def become_trait(self, trait):
        if trait not in self.owner.traits:
            self.owner.traits.append(trait)



# --- Personal Reputation Memory ---
def npc_reaction_to_player(npc, player):
    if player.reputation < -50:
        return "боится тебя"
    elif "извращенец" in player.titles:
        return "смотрит с вожделением"
