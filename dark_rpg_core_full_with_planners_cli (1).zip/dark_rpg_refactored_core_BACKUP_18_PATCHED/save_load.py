import json
from dataclasses import asdict
from typing import Any

def to_json(obj: Any) -> str:
    def default(o):
        try:
            return asdict(o)
        except Exception:
            return o.__dict__
    return json.dumps(obj, default=default, ensure_ascii=False, indent=2)

def save_to_file(obj: Any, path: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(to_json(obj))

