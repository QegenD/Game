from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any, Dict, List
import uvicorn, json
from .world_master import World, Entity
from .planner_advanced import AdvancedPlanner
from .actions import Action
import copy

app = FastAPI(title='DarkRPG AI Server')

# In-memory world instance for demo purposes
WORLD = World()

class ActionRequest(BaseModel):
    actor: str
    action: Dict[str, Any]

class PlanRequest(BaseModel):
    actor: str
    goal: Dict[str, Any] = None
    depth: int = 3
    beam: int = 6

@app.post('/state/add_entity')
def add_entity(e: Dict[str, Any]):
    if 'name' not in e:
        raise HTTPException(400, 'Missing name')
    ent = Entity(name=e['name'], pos=tuple(e.get('pos',(0,0))))
    WORLD.add_entity(ent)
    return {'ok': True}

@app.get('/state')
def get_state():
    # simple serializable state
    s = {
        'entities': {n: ent.as_dict() for n, ent in WORLD.entities.items()},
        'time': str(WORLD.time)
    }
    return s

@app.get('/actions/{actor}')
def list_actions(actor: str):
    acts = WORLD.list_actions(actor)
    # return serializable forms
    return [ {'name': a.name, 'params': a.params} for a in acts ]

@app.post('/plan')
def plan(req: PlanRequest):
    if req.actor not in WORLD.entities:
        raise HTTPException(404, 'Actor not found')
    planner = AdvancedPlanner(WORLD, beam_width=req.beam, max_depth=req.depth)
    seq = planner.plan(req.actor, goal=req.goal)
    return {'plan': [ {'name': a.name, 'params': a.params} for a in seq ] }

@app.post('/do_action')
def do_action(req: ActionRequest):
    if req.actor not in WORLD.entities:
        raise HTTPException(404, 'Actor not found')
    a = Action(name=req.action.get('name'), params=req.action.get('params',{}))
    ok, msg, data = WORLD.do_action(req.actor, a)
    return {'ok': ok, 'msg': msg, 'data': data}

# Note: to run server: uvicorn dark_rpg_refactored_core_BACKUP_18_PATCHED.ai_server:app --reload --port 8000

