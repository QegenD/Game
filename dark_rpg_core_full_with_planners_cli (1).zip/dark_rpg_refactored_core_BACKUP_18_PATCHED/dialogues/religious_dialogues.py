import random

RELIGIOUS_QUOTES = {
    "anger": [
        "Во имя {god}, ты будешь сожжён за ересь!",
        "Гнев {god} падёт на тебя!",
        "Ты посмел оскорбить святыню. Приготовься к каре!"
    ],
    "joy": [
        "Да благословит тебя {god} в этот светлый день.",
        "Сердце поёт от радости — {god} рядом.",
        "Ты принёс радость в храм {god}."
    ],
    "trust": [
        "Вера в {god} объединяет нас.",
        "Ты наш брат по вере, не забывай это.",
        "Я знаю, ты не подведёшь волю {god}."
    ],
    "fear": [
        "Ты ведь не отвергнешь {god}, верно?",
        "Гнев божий ужасен... не испытывай судьбу.",
        "Ты знаешь, что бывает с предателями веры."
    ],
    "neutral": [
        "{god} следит за нами.",
        "Ты веришь в {god}?",
        "Покой тебе, путник. Храм {god} всегда открыт."
    ]
}

def get_religious_quote(god_name="Бог", fanatic=False, emotion="neutral"):
    quotes = RELIGIOUS_QUOTES.get(emotion, RELIGIOUS_QUOTES["neutral"])
    text = random.choice(quotes).replace("{god}", god_name)
    return {
        "text": text,
        "emotion": emotion,
        "tone": "fanatic" if fanatic else "sermon"
    }
