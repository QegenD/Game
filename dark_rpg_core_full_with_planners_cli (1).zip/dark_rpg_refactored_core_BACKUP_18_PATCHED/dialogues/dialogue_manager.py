import random
from core.npc_emotion_state import NPCEmotionState
from core.face_emotion_matcher import FaceEmotionMatcher
from core.response_emotion_tagger import ResponseEmotionTagger
from data.dialogue_sets import generic
from dialogue.religious_dialogues import get_religious_quote
from dialogue.cult_dialogues import get_cult_dialogue

class DialogueManager:
    def __init__(self):
        self.emotion_tagger = ResponseEmotionTagger()
        self.face_matcher = FaceEmotionMatcher()
        self.npc_states = {}

    def get_npc_state(self, npc_id):
        if npc_id not in self.npc_states:
            self.npc_states[npc_id] = NPCEmotionState(npc_id)
        return self.npc_states[npc_id]

    def update_npc_emotion(self, npc_id, player_action):
        npc_state = self.get_npc_state(npc_id)
        npc_state.update(player_action)

    def get_response(self, npc_id, npc_type="generic", context=None):
        npc_state = self.get_npc_state(npc_id)
        emotion = npc_state.get_dominant_emotion()
        tone = self.face_matcher.get_expression(emotion)

        # Select dialogue source
        if npc_type == "religious":
            text = get_religious_quote(fanatic=True if context == "fanatic" else False, emotion=emotion)
        elif npc_type == "cult":
            text = get_cult_dialogue(tone=emotion, context=context)
        else:
            text = random.choice(generic.dialogue_templates.get(emotion, generic.dialogue_templates["neutral"]))

        tagged_emotion = self.emotion_tagger.get_emotion_tag(text)

        return {
            "npc_id": npc_id,
            "text": text,
            "emotion": tagged_emotion,
            "tone": tone,
            "raw_emotion_state": npc_state.get_state()
        }
