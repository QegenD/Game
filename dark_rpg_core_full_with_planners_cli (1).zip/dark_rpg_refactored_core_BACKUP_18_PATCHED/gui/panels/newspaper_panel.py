
import tkinter as tk
import json

def build(frame):
    tk.Label(frame, text="Газеты мира", font=("Arial", 14)).pack()
    try:
        with open("data/newspapers.json", "r", encoding="utf-8") as f:
            papers = json.load(f)[-5:]
        for paper in papers:
            tk.Label(frame, text=f"{paper['title']} — {paper['date']}", font=("Arial", 12, "bold")).pack(anchor="w")
            for article in paper["articles"][:5]:
                text = f" - {article['headline']}"
                tk.Label(frame, text=text, anchor="w", justify="left", wraplength=600).pack()
            tk.Label(frame, text="").pack()
    except:
        tk.Label(frame, text="Нет газетных записей.").pack()
