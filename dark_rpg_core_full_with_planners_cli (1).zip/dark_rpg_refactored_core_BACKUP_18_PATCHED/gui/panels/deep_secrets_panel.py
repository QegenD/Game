
import tkinter as tk
import json

def build(frame):
    tk.Label(frame, text="🕵️ Глубокие тайны NPC", font=("Arial", 14)).pack()
    try:
        with open("data/deep_secrets.json", "r", encoding="utf-8") as f:
            secrets = json.load(f)
        for s in secrets[-20:]:
            text = f"NPC: {s['npc_id']} — {s['secret_type']} (Угроза: {s['risk_level']})"
            if s.get("revealed"):
                text += " — 💥 Разоблачено!"
            tk.Label(frame, text=text, anchor="w", justify="left").pack(fill="x")
    except:
        tk.Label(frame, text="Нет данных о тайнах.").pack()
