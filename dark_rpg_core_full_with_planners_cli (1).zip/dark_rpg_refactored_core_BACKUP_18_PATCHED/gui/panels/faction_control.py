
import tkinter as tk

def build(frame):
    tk.Label(frame, text="Faction Control Panel", font=("Arial", 14)).pack()
    # Здесь отображаются фракции, влияние, цели
