
# world_chronicle_panel.py

from event_journal import get_recent_events

def render_world_chronicle_panel():
    print("=== Хроника мира ===")
    events = get_recent_events(limit=20)
    if not events:
        print("Нет доступных записей.")
        return
    for e in events:
        print(f"[{e['timestamp']}] ({e['type']}) — {e['description']}")
        if e['npcs']:
            print(f"   NPC: {', '.join(e['npcs'])}")
        if e['factions']:
            print(f"   Фракции: {', '.join(e['factions'])}")
