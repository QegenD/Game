
from goals_engine import GoalEngine
from emotion_memory import EmotionProfile

def render_npc_psychology_panel(npc):
    print(f"=== Психология NPC: {npc.name} ===")

    if not hasattr(npc, "emotion_profile"):
        npc.emotion_profile = EmotionProfile()

    emotions = npc.emotion_profile.describe_emotions(npc.name)
    print("\n[ЭМОЦИИ]:")
    for emotion, value in emotions.items():
        print(f" - {emotion.capitalize()}: {value}")

    engine = GoalEngine()
    engine.generate_goals_from_emotions(npc.name, npc.emotion_profile)

    print("\n[ЦЕЛИ]:")
    for goal in engine.get_goals():
        print(f" - {goal}")
