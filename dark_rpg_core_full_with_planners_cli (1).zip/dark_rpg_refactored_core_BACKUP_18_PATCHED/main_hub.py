
# main_hub.py — главный UI-хаб игры

import tkinter as tk
from tkinter import ttk
from ui.chronicle_ui import ChronicleUI
from ui.faction_visualizer import FactionVisualizer
from ui.map_ui import MapUI
from ui.npc_panel import NPCPanel
from ui.nsfw_gallery import NSFWGallery
from ui.inventory_ui import InventoryUI
from ui.prophecy_ui import ProphecyUI

class MainHub:
    def __init__(self, master):
        self.master = master
        self.master.title("Dark RPG World Hub")
        self.master.geometry("1024x768")

        self.notebook = ttk.Notebook(master)
        self.notebook.pack(fill="both", expand=True)

        # Chronicle tab
        self.chronicle_frame = tk.Frame(self.notebook)
        self.notebook.add(self.chronicle_frame, text="📜 Chronicle")
        self.chronicle = ChronicleUI(self.chronicle_frame, "data/world_log.json", "generated")

        # Factions tab
        self.faction_frame = tk.Frame(self.notebook)
        self.notebook.add(self.faction_frame, text="🏛️ Factions")
        self.faction = FactionVisualizer(self.faction_frame, "data/faction_graph.json", "generated")

        # Map tab
        self.map_frame = tk.Frame(self.notebook)
        self.notebook.add(self.map_frame, text="🗺️ Map")
        self.map_ui = MapUI(self.map_frame, "data/current_location.txt", "generated")

        # NPCs tab
        self.npc_frame = tk.Frame(self.notebook)
        self.notebook.add(self.npc_frame, text="🧑‍🤝‍🧑 NPCs")
        self.npc_panel = NPCPanel(self.npc_frame, "data/npc_data.json")

        # NSFW Gallery tab
        self.nsfw_frame = tk.Frame(self.notebook)
        self.notebook.add(self.nsfw_frame, text="💞 NSFW")
        self.nsfw = NSFWGallery(self.nsfw_frame, "generated/nsfw")

        # Inventory tab
        self.inventory_frame = tk.Frame(self.notebook)
        self.notebook.add(self.inventory_frame, text="🎒 Inventory")
        self.inventory = InventoryUI(self.inventory_frame, "data/inventory.json")

        # Prophecies tab
        self.prophecy_frame = tk.Frame(self.notebook)
        self.notebook.add(self.prophecy_frame, text="🔮 Prophecies")
        self.prophecy_ui = ProphecyUI(self.prophecy_frame, "data/prophecies.json")

if __name__ == "__main__":
    root = tk.Tk()
    app = MainHub(root)
    root.mainloop()
