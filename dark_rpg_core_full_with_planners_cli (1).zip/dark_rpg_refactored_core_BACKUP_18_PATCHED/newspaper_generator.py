from typing import List, Dict
import random

TEMPLATES = [
    "Local hero {a} repelled {b} near {place}. Witnesses report {detail}.",
    "Trade caravan led by {a} reached {place}; tensions with {b} ease.",
    "{place} Gazette: Council debates treaty after {a} clashed with {b}.",
]

DETAILS = ["no casualties", "minor damage", "spirited negotiations", "a tense standoff"]

PLACES = ["Grayport", "Ebonford", "Red Hollow", "Moonwell"]

def headline(events: List[Dict]) -> str:
    if not events:
        return "Quiet day across the realm."
    e = random.choice(events)
    a = e.get("a", "Unknown")
    b = e.get("b", "Unknown")
    return random.choice(TEMPLATES).format(a=a, b=b, place=random.choice(PLACES), detail=random.choice(DETAILS))
