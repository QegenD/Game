from dataclasses import dataclass, field
from typing import Dict
from .items import Item

@dataclass
class Inventory:
    items: Dict[str, int] = field(default_factory=dict)

    def add(self, item: Item, qty: int = 1):
        self.items[item.id] = self.items.get(item.id, 0) + qty

    def remove(self, item: Item, qty: int = 1) -> bool:
        cur = self.items.get(item.id, 0)
        if cur < qty: return False
        if cur == qty: self.items.pop(item.id, None)
        else: self.items[item.id] = cur - qty
        return True

    def has(self, item: Item, qty: int = 1) -> bool:
        return self.items.get(item.id, 0) >= qty

