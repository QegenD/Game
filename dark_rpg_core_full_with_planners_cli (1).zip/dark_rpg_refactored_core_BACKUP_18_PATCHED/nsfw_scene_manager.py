import random
from nsfw_flags import NSFW_SETTINGS
from training_context import generate_dynamic_response

NSFW_IMAGE_PATHS = [
    "assets/nsfw/nsfw_scene_1.jpg",
    "assets/nsfw/nsfw_scene_2.jpg",
    "assets/nsfw/nsfw_scene_3.jpg",
    "assets/nsfw/nsfw_scene_4.jpg"
]

NPC_SEXUAL_PROFILES = {
    "Лилит": {"fetishes": ["доминирование", "наказание"], "openness": 5},
    "Серафина": {"fetishes": ["ласка", "поцелуи"], "openness": 3},
    "Геката": {"fetishes": ["связь", "тайна"], "openness": 4},
    "Инкубис": {"fetishes": ["покорность", "контроль"], "openness": 2}
}

def generate_nsfw_scene(npc_name, emotion="lust", player_role="dom"):
    if not NSFW_SETTINGS.get("enable_nsfw"):
        return None, None

    npc_profile = NPC_SEXUAL_PROFILES.get(npc_name, {"fetishes": ["поцелуи"], "openness": 2})
    taboo = NSFW_SETTINGS.get("taboo_threshold", 3)
    desire = NSFW_SETTINGS.get("player_desire_level", 3)

    base_context = f"NPC: {npc_name}. Фетиши: {', '.join(npc_profile['fetishes'])}. " + \
                   f"Табу: {taboo}, Желание игрока: {desire}, Эмоция: {emotion}"

    description = generate_dynamic_response(
        npc_name=npc_name,
        input_type="nsfw_scene",
        intent="desire",
        emotion=emotion,
        game_context=base_context
    )

    image = random.choice(NSFW_IMAGE_PATHS)
    return description, image

def get_npc_fetishes(npc_name):
    return NPC_SEXUAL_PROFILES.get(npc_name, {}).get("fetishes", [])

def get_npc_openness(npc_name):
    return NPC_SEXUAL_PROFILES.get(npc_name, {}).get("openness", 1)


from world_state import WORLD_STATE

def adapt_nsfw_description(base_desc):
    weather = WORLD_STATE["weather"]
    time = WORLD_STATE["time_of_day"]

    conditions = f"В это {time}, при погоде '{weather}',"
    if weather in ["туман", "ночь"]:
        style = " всё выглядит таинственно и возбуждающе опасно."
    elif weather in ["гроза"]:
        style = " каждый всполох молнии будто усиливает страсть."
    elif weather == "ясно":
        style = " яркий свет подчёркивает каждый изгиб тел."
    else:
        style = " атмосфера придаёт сцене дополнительный тон."

    return f"{conditions}{style}\n{base_desc}"


def generate_nsfw_role_scene(player_role="dom", npc_role="sub", base_desc="..."):
    if player_role == "dom" and npc_role == "sub":
        return "Вы берёте инициативу в свои руки, диктуя ритм событий...\n" + base_desc
    elif player_role == "sub" and npc_role == "dom":
        return "Она властно прижимает вас к себе, диктуя каждое движение...\n" + base_desc
    elif player_role == "switch" or npc_role == "switch":
        return "Вы словно танцуете — меняясь ролями, теряя контроль и возвращая его...\n" + base_desc
    else:
        return "Сцена развивается мягко, по взаимному согласию...\n" + base_desc



# --- Arousal and Consent System ---
class NSFWState:
    def __init__(self):
        self.arousal = 0        # 0 to 100
        self.consent = 50       # -100 (non-consensual) to 100 (enthusiastic)

    def change_arousal(self, amount):
        self.arousal = max(0, min(100, self.arousal + amount))

    def change_consent(self, amount):
        self.consent = max(-100, min(100, self.consent + amount))



# --- Dynamic Dialogue Generation ---
def get_nsfw_phrase(npc):
    if "доминирующий" in npc.traits:
        return "На колени. Немедленно."
    elif "покорный" in npc.traits:
        return "Сделай со мной, что пожелаешь..."
    elif "фетишист" in npc.traits:
        return "Ты принес плеть? Я ждал этого..."
    else:
        return "Я не знаю, что чувствую, но продолжай..."



# --- NSFW Karma and Desire Drift ---
def update_nsfw_karma(player, action_type):
    if action_type == "доминирование":
        player.karma -= 10
        player.desires.append("контроль")
    elif action_type == "помощь":
        player.karma += 10
        player.desires.append("уход")
