from dataclasses import dataclass, field
from typing import Dict

@dataclass
class RomanceEngine:
    affection: Dict[tuple, float] = field(default_factory=dict)

    def add_affection(self, a: str, b: str, amount: float = 5.0):
        key = tuple(sorted((a,b)))
        self.affection[key] = self.affection.get(key, 0.0) + amount

    def bond_level(self, a: str, b: str) -> float:
        key = tuple(sorted((a,b)))
        return self.affection.get(key, 0.0)

    def bonded(self, a: str, b: str) -> bool:
        return self.bond_level(a,b) >= 50.0
