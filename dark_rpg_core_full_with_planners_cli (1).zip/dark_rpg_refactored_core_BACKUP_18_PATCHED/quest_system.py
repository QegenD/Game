import random
from training_context import get_game_context, generate_dynamic_response
from creative_control import CREATIVE_FLAGS

MAIN_QUEST = None
RANDOM_EVENTS = []
PLAYER_REPUTATION = {
    "morality": 0,
    "infamy": 0,
    "charm": 0,
    "violence": 0
}

def generate_main_quest():
    global MAIN_QUEST
    if MAIN_QUEST:
        return MAIN_QUEST
    context = get_game_context()
    intent = "epic_resolution" if CREATIVE_FLAGS.get("goal_based_story") else "quest"
    description = generate_dynamic_response(
        npc_name="легенда",
        input_type="main_quest",
        intent=intent,
        game_context=context
    )
    rumors = generate_dynamic_response(
        npc_name="странствующий мудрец",
        input_type="rumor",
        intent="lore",
        game_context=context + f" Квест: {description}"
    )
    MAIN_QUEST = {
        "title": "Предназначение Тени",
        "description": description,
        "rumor": rumors,
        "completed": False
    }
    return MAIN_QUEST

def random_event_chance(chance=0.35):
    roll = random.random()
    return roll <= chance

def generate_random_event():
    context = get_game_context()
    event_types = [
        ("смешное", "comedy", {"charm": +1}),
        ("романтическое", "romance", {"charm": +2}),
        ("ужасное", "horror", {"infamy": +1}),
        ("странное", "weird", {"morality": -1}),
        ("эпичное", "epic", {"violence": +1}),
        ("жуткое", "creepy", {"infamy": +2}),
        ("искушение", "desire", {"morality": -2}),
        ("моральный выбор", "morality", {"morality": +1}),
        ("обман", "trickery", {"infamy": +3}),
        ("сюрприз", "twist", {"violence": +1, "charm": +1})
    ]
    type_label, intent, consequence = random.choice(event_types)

    description = generate_dynamic_response(
        npc_name="мир",
        input_type="event",
        intent=intent,
        game_context=context
    )

    # Apply consequences
    for k, v in consequence.items():
        PLAYER_REPUTATION[k] = PLAYER_REPUTATION.get(k, 0) + v

    event = {
        "type": type_label,
        "description": description,
        "consequence": consequence,
        "resolved": False
    }
    RANDOM_EVENTS.append(event)
    return event

def get_npc_attitude(npc_traits):
    # npc_traits = {"morality": +2, "charm": -1, ...}
    score = 0
    for trait, modifier in npc_traits.items():
        score += PLAYER_REPUTATION.get(trait, 0) * modifier
    if score >= 5:
        return "обожает"
    elif score >= 2:
        return "доверяет"
    elif score >= -1:
        return "нейтрален"
    elif score >= -4:
        return "осторожен"
    else:
        return "ненавидит"



# --- Moral Choices with Consequences ---
def moral_event(player_choice):
    if player_choice == "спасти":
        adjust_reputation("Церковь", 20)
    elif player_choice == "предать":
        adjust_reputation("Культ", 30)
    elif player_choice == "игнорировать":
        add_rumor("Герой проигнорировал зов о помощи")



# --- Faction Intrigue ---
faction_relations = {
    ("Церковь", "Культ"): -80,
    ("Академия", "Церковь"): -50,
    ("Торговая Гильдия", "Культ"): +20
}

def get_faction_relation(f1, f2):
    return faction_relations.get((f1, f2), 0)
