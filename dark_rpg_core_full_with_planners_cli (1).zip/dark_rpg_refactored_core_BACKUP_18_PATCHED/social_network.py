from collections import defaultdict

# connections[npc_id] = { 'friends': [], 'enemies': [], 'family': [], ... }
connections = defaultdict(lambda: defaultdict(list))

def add_connection(npc1, npc2, relation_type):
    if npc2 not in connections[npc1][relation_type]:
        connections[npc1][relation_type].append(npc2)

def remove_connection(npc1, npc2, relation_type):
    if npc2 in connections[npc1][relation_type]:
        connections[npc1][relation_type].remove(npc2)

def get_relations(npc_id):
    return connections[npc_id]