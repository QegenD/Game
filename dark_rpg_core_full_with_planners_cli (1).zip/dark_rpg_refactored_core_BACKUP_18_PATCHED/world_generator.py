import random
from training_context import generate_dynamic_response, get_game_context

creative_mode = True

def generate_world_map(seed=None, size=5):
    if seed is not None:
        random.seed(seed)

    world = []
    context = get_game_context()

    for i in range(size):
        row = []
        for j in range(size):
            if creative_mode:
                desc = generate_dynamic_response(
                    npc_name="локация",
                    input_type="environment",
                    intent="mystery",
                    game_context=context
                )
                name = f"Локация {i},{j}"
                    # Генерация изображения локации
    prompt = f"{name}, fantasy environment, detailed concept art"
    image_path = f"images/locations/{name.replace(' ', '_')}.png"
    generate_image(prompt, image_path)

    location = {
                    "name": name,
                    "description": desc,
                    "coords": (i, j)
                }
            else:
                terrain = random.choice(["болото", "пустошь", "руины"])
                structure = random.choice(["алтарь", "крепость"])
                tag = random.choice(["проклятый", "древний"])
                name = f"{tag.capitalize()} {structure} среди {terrain}"
                    # Генерация изображения локации
    prompt = f"{name}, fantasy environment, detailed concept art"
    image_path = f"images/locations/{name.replace(' ', '_')}.png"
    generate_image(prompt, image_path)

    location = {
                    "name": name,
                    "terrain": terrain,
                    "structure": structure,
                    "tag": tag,
                    "coords": (i, j),
                    "description": f"Вы стоите у {tag} {structure}."
                }
            row.append(location)
        world.append(row)
    return world



# --- Erotic Lore Items ---
erotic_books = [
    {"title": "Тайные позы духов", "effect": "разблокирует новую NSFW-сцену"},
    {"title": "Дневник послушницы", "effect": "меняет мораль NPC"}
]
