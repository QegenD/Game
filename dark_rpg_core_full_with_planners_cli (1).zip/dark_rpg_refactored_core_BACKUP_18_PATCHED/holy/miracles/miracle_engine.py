
# miracle_engine.py — генерация чудес в мире

from random import choice

class Miracle:
    def __init__(self, location, triggering_npc=None):
        self.location = location
        self.triggering_npc = triggering_npc
        self.type = choice([
            "healing light", "divine fire", "flood of purity",
            "statue weeping blood", "rain of feathers", "holy song"
        ])

    def perform(self):
        result = f"A miracle occurred: {self.type} at {self.location}"
        if self.triggering_npc:
            result += f", witnessed by {self.triggering_npc.name}"
        return result
