
# chapel_builder.py — строительство капелл и алтарей игроком и NPC

class Chapel:
    def __init__(self, founder, location, deity):
        self.founder = founder
        self.location = location
        self.deity = deity
        self.status = "in construction"
        self.progress = 0

    def build_step(self):
        self.progress += 20
        if self.progress >= 100:
            self.status = "completed"
            return f"Chapel to {self.deity} completed in {self.location}!"
        return f"Chapel to {self.deity} construction progress: {self.progress}%"
