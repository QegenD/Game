
# saint_registry.py — список святых, их влияние, легенды и чудеса

class Saint:
    def __init__(self, name, domain, miracles=None):
        self.name = name
        self.domain = domain
        self.miracles = miracles if miracles else []

    def perform_miracle(self, npc, world):
        from holy.miracles.miracle_engine import Miracle
        m = Miracle(location=npc.location, triggering_npc=npc)
        world.log.append(f"Miracle by Saint {self.name}: {m.type} at {npc.location}")
        return m.perform()
