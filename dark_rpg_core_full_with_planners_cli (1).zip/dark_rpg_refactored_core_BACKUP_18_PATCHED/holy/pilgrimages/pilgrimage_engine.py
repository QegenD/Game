
# pilgrimage_engine.py — паломничества NPC и игроков в святые места

from random import randint

class Pilgrimage:
    def __init__(self, npc, destination):
        self.npc = npc
        self.destination = destination
        self.progress = 0
        self.completed = False

    def journey(self):
        self.progress += randint(10, 40)
        if self.progress >= 100:
            self.completed = True
            self.npc.journal.append(f"Completed pilgrimage to {self.destination.name}")
            self.destination.bless(self.npc)
            return f"{self.npc.name} completed pilgrimage to {self.destination.name}"
        return f"{self.npc.name} is traveling toward {self.destination.name}..."
