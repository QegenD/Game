
# ritual_engine.py — молитвы, подношения, жертвоприношения

from random import choice

class HolyRitual:
    def __init__(self, performer, location):
        self.performer = performer
        self.location = location
        self.ritual_type = choice(["prayer", "offering", "blood sacrifice"])
        self.effect = None

    def perform(self):
        if self.ritual_type == "prayer":
            self.effect = "blessing of clarity"
        elif self.ritual_type == "offering":
            self.effect = "luck increased"
        elif self.ritual_type == "blood sacrifice":
            self.effect = "miracle chance boosted"
            self.location.corruption += 1
        return f"{self.performer.name} performed {self.ritual_type} in {self.location.name}: effect — {self.effect}"
