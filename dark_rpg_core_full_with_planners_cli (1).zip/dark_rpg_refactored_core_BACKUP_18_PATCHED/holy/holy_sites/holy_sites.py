
# holy_sites.py — список святых мест и их эффекты

class HolySite:
    def __init__(self, name, blessing_type, location_name):
        self.name = name
        self.blessing_type = blessing_type
        self.location_name = location_name
        self.is_corrupted = False

    def bless(self, npc):
        if self.is_corrupted:
            npc.status_effects.append("tainted_blessing")
            npc.mood = "uneasy"
        else:
            npc.status_effects.append(self.blessing_type)
            npc.mood = "hopeful"

    def corrupt(self):
        self.is_corrupted = True

    def purify(self):
        self.is_corrupted = False


HOLY_SITES = [
    HolySite("Sanctum of Dawn", "blessing_strength", "Silver Hills"),
    HolySite("Shrine of Mercy", "blessing_healing", "Valenwood"),
    HolySite("Temple of Light", "blessing_luck", "Sunspire")
]
