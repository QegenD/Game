
# territory_conflict.py — святые земли и конфликты за них

class HolyTerritory:
    def __init__(self, name, faction):
        self.name = name
        self.controlled_by = faction
        self.is_blessed = True
        self.in_conflict = False

    def desecrate(self, attacker_faction):
        self.in_conflict = True
        self.is_blessed = False
        self.controlled_by = attacker_faction

    def bless(self, new_faction):
        self.in_conflict = False
        self.is_blessed = True
        self.controlled_by = new_faction


HOLY_TERRITORIES = [
    HolyTerritory("Cleansed Plateau", "Holy Order"),
    HolyTerritory("Ashen Valley", "Neutral"),
    HolyTerritory("Ruined Spire", "Unclaimed")
]
