
# crusade_campaign.py — Крестовые походы инквизиции

from random import choice

class Crusade:
    def __init__(self, target_faction, holy_leader):
        self.target = target_faction
        self.leader = holy_leader
        self.army_size = 1000 + holy_leader.stats.get("leadership", 0) * 100
        self.outcome = None

    def launch(self):
        if self.target in ["Cultists", "Necromancers"]:
            self.outcome = choice(["victory", "draw", "massacre"])
        else:
            self.outcome = "disbanded"

        return f"Crusade against {self.target} led by {self.leader.name} resulted in {self.outcome}"
