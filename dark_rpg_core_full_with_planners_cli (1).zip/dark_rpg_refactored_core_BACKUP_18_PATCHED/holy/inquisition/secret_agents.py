
# secret_agents.py — Тайные агенты инквизиции, внедрение и разоблачения

from random import randint

class InquisitionAgent:
    def __init__(self, npc):
        self.npc = npc
        self.cover_identity = npc.role
        self.loyalty = 100
        self.successes = 0

    def investigate(self, suspect):
        suspicion = randint(0, 10)
        stealth = self.npc.stats.get("stealth", 5)

        if suspicion > stealth:
            suspect.flags.append("heretic_suspected")
            self.successes += 1
            return f"{self.npc.name} flagged {suspect.name} as heretic"
        else:
            self.loyalty -= 5
            return f"{self.npc.name} failed to gather proof"
