import random

RUMORS = [
    "{a} was seen near the old ruins—alone.",
    "They say {b} owes {a} a life-debt.",
    "A whisper claims {a} and {b} share a secret map.",
]

def random_rumor(a: str, b: str) -> str:
    return random.choice(RUMORS).format(a=a, b=b)
