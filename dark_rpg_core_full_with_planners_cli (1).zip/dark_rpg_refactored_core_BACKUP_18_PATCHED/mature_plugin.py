from pathlib import Path
import json
from typing import Dict, Optional

MATURE_DIR = Path("mature_content")  # relative to game root
METADATA_FILENAME = "meta.json"

class MatureContentError(Exception):
    pass

class MatureContent:
    def __init__(self, meta_path: Path):
        self.meta_path = meta_path
        self.base = meta_path.parent
        data = json.loads(meta_path.read_text(encoding="utf-8"))
        self.data = data
        required = {"id","title","explicit","file","author"}
        if not required.issubset(set(self.data.keys())):
            raise MatureContentError(f"Missing required fields in {meta_path}: required={required}")
        content_file = self.base / self.data["file"]
        if not content_file.exists():
            raise MatureContentError(f"Missing content file: {content_file}")


    @property
    def id(self):
        return self.data["id"]

    def load_text(self) -> str:
        return (self.base / self.data["file"]).read_text(encoding="utf-8")

def discover_all(dir_path: Path = MATURE_DIR) -> Dict[str, MatureContent]:
    found = {}
    if not dir_path.exists():
        return found
    for meta in dir_path.rglob(METADATA_FILENAME):
        try:
            mc = MatureContent(meta)
            found[mc.id] = mc
        except Exception as e:
            # keep going - surface errors for manual fix
            print("[mature_plugin] load error:", meta, e)
    return found

def suggest_scene_for_view(world, a: str, b: str, viewer_is_adult: bool, preferred_tag: Optional[str]=None) -> str:
    # Safety checks
    if not viewer_is_adult:
        return f"{a} и {b} проводят тёплый, дружеский вечер — сцена скрыта для несовершеннолетних."
    if getattr(world, "content_rating", "PG-13") != "Mature" and getattr(world, "content_rating", None) is not None:
        return "Mature content disabled in this build."

    pool = discover_all()
    if not pool:
        return "Нет доступного взрослого контента."

    choices = list(pool.values())
    if preferred_tag:
        filtered = [c for c in choices if preferred_tag in c.data.get("tags",[])]
        if filtered:
            choices = filtered
    # Basic selection policy: deterministic order (sorted by id) then first
    choices.sort(key=lambda c: c.id)
    scene = choices[0]
    return scene.load_text()
