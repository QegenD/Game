from quest_system import PLAYER_REPUTATION

QUEST_LOG = []

def add_quest_to_log(quest_title, description, status="активен"):
    entry = {
        "title": quest_title,
        "description": description,
        "status": status
    }
    QUEST_LOG.append(entry)

def complete_quest(quest_title):
    for entry in QUEST_LOG:
        if entry["title"] == quest_title:
            entry["status"] = "выполнен"
            break

def abandon_quest(quest_title):
    for entry in QUEST_LOG:
        if entry["title"] == quest_title:
            entry["status"] = "провален"
            break

def get_quest_log():
    return QUEST_LOG

def get_shop_price_modifier():
    """Возвращает множитель цен в магазине в зависимости от обаяния и морали"""
    charm = PLAYER_REPUTATION.get("charm", 0)
    morality = PLAYER_REPUTATION.get("morality", 0)
    base = 1.0
    if charm > 2:
        base -= 0.1
    if morality < -2:
        base += 0.1
    return round(max(0.7, min(1.3, base)), 2)

def is_access_allowed(npc_traits):
    """Некоторые NPC не будут взаимодействовать с аморальным или агрессивным игроком"""
    if PLAYER_REPUTATION.get("morality", 0) < -3 and npc_traits.get("morality_sensitive", False):
        return False
    if PLAYER_REPUTATION.get("violence", 0) > 5 and npc_traits.get("peaceful", False):
        return False
    return True



# --- Faction Reputation and Rumors ---
factions = ["Церковь", "Культ", "Скрытая Академия", "Торговая Гильдия"]
reputation = {name: 0 for name in factions}
rumors = []

def adjust_reputation(faction, amount):
    if faction in reputation:
        reputation[faction] += amount

def add_rumor(text):
    rumors.append(text)



# --- Rumor Domino System ---
def rumor_trigger_event(rumor_text, event_id):
    rumors.append(rumor_text)
    world.trigger_event(event_id)
