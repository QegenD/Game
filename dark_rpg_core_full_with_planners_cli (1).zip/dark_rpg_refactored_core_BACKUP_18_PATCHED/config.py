settings = {
    "player_data_path": "data/player_data.json",
    "update_interval_seconds": 5,
    "llm_endpoint": "http://localhost:11434/api/generate",
    "sd_api_url": "http://127.0.0.1:7860",
    "max_game_ticks": 5,
    "tick_delay_seconds": 1,
    "event_log_path": "data/world_events.json",
    "enable_nsfw": true
}
