from dataclasses import dataclass
from typing import List, Dict, Any
import json, random, os
from pathlib import Path

DIALOGUE_DIR = Path('dialogues')

@dataclass
class DialogueNode:
    id: str
    text: str
    choices: List[Dict[str,Any]]  # {'text':..., 'next': node_id, 'effect': {'befriend':5}}

class DialogueSystem:
    def __init__(self, base_dir: str = 'dialogues'):
        self.base = Path(base_dir)
        self.nodes: Dict[str, DialogueNode] = {}
        self.load_all()

    def load_all(self):
        self.nodes = {}
        if not self.base.exists(): return
        for p in self.base.glob('*.json'):
            try:
                data = json.loads(p.read_text(encoding='utf-8'))
                for n in data.get('nodes',[]):
                    node = DialogueNode(id=n['id'], text=n['text'], choices=n.get('choices',[]))
                    self.nodes[node.id] = node
            except Exception as e:
                print('dialogue load error', p, e)

    def start(self, node_id: str):
        return self.nodes.get(node_id)

    def apply_choice(self, world, actor: str, target: str, choice: Dict[str,Any]):
        # apply simple effects from choice metadata
        eff = choice.get('effect',{})
        if 'befriend' in eff:
            world.social.befriend(actor, target, eff['befriend'])
            world.chronicles.log('dialogue_befriend', actor=actor, target=target, amount=eff['befriend'])
        if 'give_item' in eff:
            iid = eff['give_item']
            world.entities[target].inv.add(world.entities[target].inv.__class__.__annotations__.get('items', {}), 0)  # noop placeholder
        return True

