from dataclasses import dataclass

@dataclass
class GameTime:
    day: int = 1
    hour: int = 8

    def advance_hours(self, h: int = 1):
        self.hour += h
        while self.hour >= 24:
            self.hour -= 24
            self.day += 1

    def __str__(self):
        return f"Day {self.day}, {self.hour:02d}:00"

