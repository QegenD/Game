
# news_generator.py — еженедельная генерация газет и таблоидов

import random
from datetime import datetime

def generate_news(world, week):
    headlines = [
        "Скандал на турнире: дуэль из-за любви!",
        "Игрок замечен в объятиях таинственного незнакомца.",
        "Секта Плоти устраивает очередной праздник.",
        "В городе прошёл суд над героем. Вердикт — {verdict}!",
        "Казнь на площади вызвала бурю эмоций."
    ]
    events = world.get("events", [])
    selected = random.sample(headlines, min(3, len(headlines)))
    filename = f"news/gazette_week{week}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"☼ Газета недели #{week} — {datetime.now().strftime('%Y-%m-%d')} ☼\n\n")
        for h in selected:
            f.write("- " + h.format(verdict=random.choice(["виновен", "оправдан"])) + "\n")
        f.write("\nПодпишитесь на наши таблоиды — правду узнают только смелые!")
