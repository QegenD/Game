from dataclasses import dataclass
from typing import Callable, Dict, List, Any, DefaultDict
from collections import defaultdict

Listener = Callable[[str, Any], None]

class EventBus:
    def __init__(self):
        self._listeners: DefaultDict[str, List[Listener]] = defaultdict(list)

    def on(self, event: str, fn: Listener):
        self._listeners[event].append(fn)

    def emit(self, event: str, payload: Any = None):
        for fn in list(self._listeners.get(event, [])):
            fn(event, payload)

BUS = EventBus()

