
# forbidden_magic.py — запретные заклинания: контроль, мучения, искажения

import random

class ForbiddenMagic:
    def __init__(self):
        self.spells = {
            "Pain Lance": "Deals internal pain without visible damage",
            "Obedience Mark": "Forces target to obey simple commands",
            "Mind Cage": "Locks victim in hallucinatory nightmare",
            "Flesh Twist": "Deforms target's body temporarily",
            "Ecstatic Agony": "Mixes pleasure and pain for domination"
        }

    def cast(self, spell_name, target):
        if spell_name not in self.spells:
            print("Unknown forbidden spell.")
            return
        effect = self.spells[spell_name]
        print(f"Cast '{spell_name}' on {target.name}: {effect}")
        target.status_effects.append(spell_name)
