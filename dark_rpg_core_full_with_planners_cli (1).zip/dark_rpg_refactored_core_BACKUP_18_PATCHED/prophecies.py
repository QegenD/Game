import random

OMENS = [
    "When twin moons mirror the sea, a hidden door will open.",
    "A crown of ash will weigh upon the unready brow.",
    "The seed you bury today becomes the forest you will lose or save.",
]

def random_prophecy() -> str:
    return random.choice(OMENS)
