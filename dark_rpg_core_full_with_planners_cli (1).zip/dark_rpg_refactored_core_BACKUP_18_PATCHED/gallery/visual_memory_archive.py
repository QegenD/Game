
# visual_memory_archive.py — Хранение и генерация ключевых SD-сцен

def save_visual_event(world, event_type, description, image_path):
    if not hasattr(world, "visual_archive"):
        world.visual_archive = []
    world.visual_archive.append({
        "type": event_type,
        "desc": description,
        "image": image_path
    })

def get_visual_archive(world):
    return world.visual_archive if hasattr(world, "visual_archive") else []
