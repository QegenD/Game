from dataclasses import dataclass
from typing import Dict

@dataclass
class StatusEffect:
    name: str
    duration: int
    modifiers: Dict[str, float]

def tick_effects(effects: Dict[str, StatusEffect]):
    expired = []
    for k, eff in list(effects.items()):
        eff.duration -= 1
        if eff.duration <= 0:
            expired.append(k)
    for k in expired:
        effects.pop(k, None)

