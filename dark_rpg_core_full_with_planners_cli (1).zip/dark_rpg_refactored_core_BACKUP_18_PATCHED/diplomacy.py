from dataclasses import dataclass, field
from typing import Dict
from .social_graph import SocialGraph

@dataclass
class FactionState:
    name: str
    power: int = 1
    stance: Dict[str, int] = field(default_factory=dict)  # -100..100 per faction

@dataclass
class Diplomacy:
    factions: Dict[str, FactionState] = field(default_factory=dict)
    social: SocialGraph = field(default_factory=SocialGraph)

    def add_faction(self, name: str, power: int = 1):
        self.factions[name] = FactionState(name, power)

    def set_stance(self, a: str, b: str, v: int):
        self.factions[a].stance[b] = max(-100, min(100, v))
        # update social avg between members would be game-specific

    def get_stance(self, a: str, b: str) -> int:
        return self.factions.get(a, FactionState(a)).stance.get(b, 0)

