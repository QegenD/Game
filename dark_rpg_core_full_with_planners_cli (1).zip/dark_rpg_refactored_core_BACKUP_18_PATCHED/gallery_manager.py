# Safe gallery manager placeholder that tracks and returns image paths/ids.
from dataclasses import dataclass, field
from typing import List

@dataclass
class GalleryManager:
    images: List[str] = field(default_factory=list)

    def add(self, path: str):
        if path not in self.images:
            self.images.append(path)

    def list(self) -> List[str]:
        return list(self.images)

    def random(self):
        import random
        return random.choice(self.images) if self.images else None
