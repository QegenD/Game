import logging

logger = logging.getLogger(__name__)

def draw_main_ui(player, world_state):
    try:
        location = getattr(player, "location", "unknown")
        mood = getattr(player, "mood", "neutral")

        ui_output = (
            f"=== UI HUB ===\n"
            f"📍 Location: {location}\n"
            f"😐 Mood: {mood}"
        )

        logger.debug("Main UI drawn successfully.")
        return ui_output

    except Exception as e:
        logger.exception("Failed to draw main UI.")
        return "⚠️ Error rendering UI"
