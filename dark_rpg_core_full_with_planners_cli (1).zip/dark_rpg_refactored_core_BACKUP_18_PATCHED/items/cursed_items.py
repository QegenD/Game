
# cursed_items.py — проклятые предметы, демонические артефакты

import random

class CursedItem:
    def __init__(self, name, curse_effect):
        self.name = name
        self.curse_effect = curse_effect
        self.bound = False

    def bind_to(self, npc):
        self.bound = True
        npc.inventory.append(self)
        npc.status_effects.append(self.curse_effect)
        print(f"{self.name} bound to {npc.name}. Effect: {self.curse_effect}")

def generate_random_cursed_item():
    names = ["Blade of Thirst", "Ring of Chains", "Veil of Lust", "Idol of Hunger"]
    effects = ["madness", "lust", "bloodlust", "obedience"]
    return CursedItem(random.choice(names), random.choice(effects))
