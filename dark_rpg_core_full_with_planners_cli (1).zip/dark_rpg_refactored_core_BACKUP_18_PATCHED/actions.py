from dataclasses import dataclass
from typing import Dict, Any, Tuple, List, Optional
from .items import get_item, Item
from .status_effects import StatusEffect
from .map_ai import astar, GridMap
import random

ActionResult = Tuple[bool, str, Dict[str, Any]]  # success, message, extra data

@dataclass
class Action:
    name: str
    params: Dict[str, Any]

def possible_actions(world, actor_name: str) -> List[Action]:
    '''Enumerate plausible actions for actor in the current world state.'''
    actor = world.entities.get(actor_name)
    if actor is None:
        return []
    actions = []
    # Move to adjacent tiles
    x,y = actor.pos
    for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
        nx,ny = x+dx, y+dy
        if world.map.in_bounds((nx,ny)) and world.map.passable((nx,ny)):
            actions.append(Action("move", {"to": (nx,ny)}))
    # Attack adjacent enemies
    for other_name, other in world.entities.items():
        if other_name == actor_name: continue
        if abs(other.pos[0]-x)+abs(other.pos[1]-y) == 1:
            actions.append(Action("attack", {"target": other_name}))
    # Use consumables
    for iid, qty in actor.inv.items.items():
        it = get_item(iid)
        if it.type == "consumable":
            actions.append(Action("use_item", {"item_id": iid}))
    # Pick up items on ground (world may have dropped items list)
    ground = getattr(world, "ground_items", {})
    loc_items = ground.get(actor.pos, [])
    for iid in loc_items:
        actions.append(Action("pick_up", {"item_id": iid}))
    # Rest (regain morale/fatigue)
    actions.append(Action("rest", {}))
    # Trade / talk with adjacent
    for other_name, other in world.entities.items():
        if other_name == actor_name: continue
        if abs(other.pos[0]-x)+abs(other.pos[1]-y) <= 1:
            actions.append(Action("talk", {"target": other_name}))
            actions.append(Action("trade", {"target": other_name}))
    # Hide / disguise if actor has disguise items or skill
    if "sword" not in actor.inv.items and actor.skills.get("sneak") > 0:
        actions.append(Action("sneak", {}))
    # Fallback: wait
    actions.append(Action("wait", {}))
    return actions

def perform_action(world, actor_name: str, action: Action) -> ActionResult:
    actor = world.entities.get(actor_name)
    if actor is None:
        return False, "Actor not found", {}
    name = action.name
    params = action.params or {}

    if name == "move":
        to = tuple(params.get("to"))
        if not world.map.in_bounds(to) or not world.map.passable(to):
            return False, "Can't move there", {}
        actor.pos = to
        world.chronicles.log("move_action", actor=actor_name, to=to)
        return True, f"{actor_name} moves to {to}", {"pos": to}

    if name == "attack":
        target = params.get("target")
        if target not in world.entities:
            return False, "Target missing", {}
        if abs(world.entities[target].pos[0]-actor.pos[0])+abs(world.entities[target].pos[1]-actor.pos[1]) > 1:
            return False, "Target out of range", {}
        log = world._attack(actor_name, target)
        return True, f"Attacked {target}", {"combat": log.__dict__}

    if name == "use_item":
        item_id = params.get("item_id")
        success = world.use_item(actor_name, item_id)
        if success:
            return True, f"Used {item_id}", {}
        return False, "No item or can't use", {}

    if name == "pick_up":
        iid = params.get("item_id")
        ground = getattr(world, "ground_items", {})
        items_here = ground.get(actor.pos, [])
        if iid in items_here:
            actor.inv.add(get_item(iid), 1)
            items_here.remove(iid)
            world.chronicles.log("pick_up", actor=actor_name, item=iid)
            return True, f"Picked up {iid}", {}
        return False, "Item not found on ground", {}

    if name == "rest":
        actor.needs.fulfill(food=10, rest=20, joy=5)
        world.chronicles.log("rest", actor=actor_name)
        return True, "Rested", {}

    if name == "talk":
        target = params.get("target")
        if target in world.entities:
            # simple dialog effect: increase social score
            world.social.befriend(actor_name, target, amount=2)
            world.chronicles.log("talk", a=actor_name, b=target)
            return True, f"Talked to {target}", {}
        return False, "No target", {}

    if name == "trade":
        target = params.get("target")
        if target in world.entities:
            # simplistic trade: transfer a potion if target has one
            targ = world.entities[target]
            if targ.inv.has(get_item("potion")):
                targ.inv.remove(get_item("potion"),1)
                actor.inv.add(get_item("potion"),1)
                world.chronicles.log("trade", from_=target, to=actor_name, item="potion")
                return True, f"Traded and received potion from {target}", {}
            return False, "Target has nothing to trade", {}
        return False, "No target", {}

    if name == "sneak":
        # chance to hide: compare skill to random
        skill = actor.skills.get("sneak")
        if random.random() < 0.3 + 0.05*skill:
            world.chronicles.log("sneak_success", actor=actor_name)
            return True, "Successfully sneaked", {}
        world.chronicles.log("sneak_fail", actor=actor_name)
        return False, "Failed to sneak", {}

    if name == "wait":
        world.chronicles.log("wait", actor=actor_name)
        return True, "Waited", {}

    return False, "Unknown action", {}
