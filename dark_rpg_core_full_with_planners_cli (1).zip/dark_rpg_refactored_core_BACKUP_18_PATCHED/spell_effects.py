from world_state import WORLD_STATE

def modify_spell_power(base_power):
    weather = WORLD_STATE["weather"]
    time = WORLD_STATE["time_of_day"]
    multiplier = 1.0

    if weather == "гроза" and time == "ночь":
        multiplier += 0.4  # темные заклинания сильнее
    elif weather in ["ясно", "снег"] and time == "день":
        multiplier += 0.2  # светлые заклинания усиливаются
    elif weather == "туман":
        multiplier -= 0.2  # магия менее точная

    return int(base_power * multiplier)

def is_stealth_easier():
    if WORLD_STATE["time_of_day"] == "ночь":
        return True
    if WORLD_STATE["weather"] in ["туман", "дождь"]:
        return True
    return False



# --- Ritual Integration ---
def perform_ritual(player, ritual_type):
    if ritual_type == "эротический":
        trigger_nsfw_ritual_scene(player)
        player.learn_spell("Изгиб воли")
