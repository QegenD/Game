
# skill_progression.py

class SkillTree:
    def __init__(self):
        self.skills = {}

    def gain_experience(self, npc_id, skill, amount):
        self.skills.setdefault(npc_id, {}).setdefault(skill, 0)
        self.skills[npc_id][skill] += amount

    def get_skill_level(self, npc_id, skill):
        return self.skills.get(npc_id, {}).get(skill, 0)
