from dataclasses import dataclass
from typing import List, Tuple, Dict, Any, Optional
from .actions import possible_actions, perform_action, Action
import random

@dataclass
class PlanStep:
    action: Action
    reason: str

class SimplePlanner:
    '''
    Simple heuristic planner for NPCs/AI players.
    It enumerates possible actions and scores them by heuristics to pick one,
    or builds a short plan (1-3 steps) aiming at a top-level goal.
    '''
    def __init__(self, world):
        self.world = world

    def enumerate_and_score(self, actor_name: str):
        acts = possible_actions(self.world, actor_name)
        scored = []
        actor = self.world.entities.get(actor_name)
        for a in acts:
            score = 0.0
            # heuristics
            if a.name == "attack":
                # prefer attacking weak targets
                tgt = a.params.get("target")
                if tgt and tgt in self.world.entities:
                    hp = self.world.entities[tgt].hp
                    score += max(0, 10 - hp)
            if a.name == "use_item":
                score += 3.0
            if a.name == "rest":
                # prefer rest when tired/hungry
                if actor.needs.fatigue > 40 or actor.needs.hunger > 50:
                    score += 5.0
            if a.name == "pick_up":
                score += 2.0
            if a.name == "talk":
                score += 1.0
            if a.name == "move":
                score += 0.5
            # randomness to break ties
            score += random.random()*0.5
            scored.append((score, a))
        scored.sort(key=lambda x: -x[0])
        return scored

    def pick_action(self, actor_name: str):
        scored = self.enumerate_and_score(actor_name)
        if not scored:
            return None
        # pick top choice
        return scored[0][1]

    def make_plan(self, actor_name: str, steps: int = 3):
        plan = []
        for _ in range(steps):
            a = self.pick_action(actor_name)
            if not a: break
            plan.append(PlanStep(action=a, reason="heuristic"))
            # simulate locally applying action effects simplistically to change scoring
            # For simplicity we won't mutate the real world here.
        return plan

    def execute_one(self, actor_name: str):
        a = self.pick_action(actor_name)
        if not a:
            return False, "no action"
        return perform_action(self.world, actor_name, a)
