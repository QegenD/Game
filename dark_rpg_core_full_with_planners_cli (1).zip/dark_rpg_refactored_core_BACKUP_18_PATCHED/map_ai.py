from typing import List, Tuple, Set, Dict
import heapq

Vec = Tuple[int,int]

class GridMap:
    def __init__(self, width: int, height: int, walls: Set[Vec] = None):
        self.width = width
        self.height = height
        self.walls = set(walls or set())

    def in_bounds(self, v: Vec) -> bool:
        x,y = v
        return 0 <= x < self.width and 0 <= y < self.height

    def passable(self, v: Vec) -> bool:
        return v not in self.walls

    def neighbors(self, v: Vec) -> List[Vec]:
        x,y = v
        cand = [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]
        res = [c for c in cand if self.in_bounds(c) and self.passable(c)]
        return res

def heuristic(a: Vec, b: Vec) -> int:
    return abs(a[0]-b[0]) + abs(a[1]-b[1])

def astar(grid: GridMap, start: Vec, goal: Vec) -> List[Vec]:
    frontier = [(0, start)]
    came_from: Dict[Vec, Vec] = {start: None}  # type: ignore
    cost_so_far: Dict[Vec, int] = {start: 0}
    while frontier:
        _, current = heapq.heappop(frontier)
        if current == goal:
            break
        for nxt in grid.neighbors(current):
            new_cost = cost_so_far[current] + 1
            if nxt not in cost_so_far or new_cost < cost_so_far[nxt]:
                cost_so_far[nxt] = new_cost
                priority = new_cost + heuristic(nxt, goal)
                heapq.heappush(frontier, (priority, nxt))
                came_from[nxt] = current
    if goal not in came_from:
        return []
    # reconstruct
    path = []
    cur = goal
    while cur is not None:
        path.append(cur)
        cur = came_from.get(cur)
    path.reverse()
    return path
