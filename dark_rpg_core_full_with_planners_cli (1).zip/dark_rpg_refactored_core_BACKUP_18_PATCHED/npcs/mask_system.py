
# mask_system.py — NPC скрывают принадлежность к секте/культу

def assign_mask(npc):
    npc["mask"] = {
        "hidden_affiliation": npc.get("cult_affiliation", None),
        "is_masked": True
    }

def reveal_mask(npc):
    if npc.get("mask", {}).get("is_masked"):
        npc["mask"]["is_masked"] = False
        return f"🎭 Маска NPC {npc['name']} снята! Принадлежность: {npc['mask']['hidden_affiliation']}"
    return f"Маска у NPC {npc['name']} не обнаружена или уже снята."
