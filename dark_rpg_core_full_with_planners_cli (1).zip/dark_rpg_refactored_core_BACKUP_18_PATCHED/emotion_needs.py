from dataclasses import dataclass

@dataclass
class Needs:
    hunger: float = 0.0  # 0..100
    fatigue: float = 0.0
    morale: float = 50.0

    def tick(self, dt: float = 1.0):
        self.hunger = min(100.0, self.hunger + 0.5*dt)
        self.fatigue = min(100.0, self.fatigue + 0.4*dt)
        if self.hunger > 80 or self.fatigue > 80:
            self.morale = max(0.0, self.morale - 0.5*dt)
        else:
            self.morale = min(100.0, self.morale + 0.2*dt)

    def fulfill(self, food: float = 20.0, rest: float = 20.0, joy: float = 10.0):
        self.hunger = max(0.0, self.hunger - food)
        self.fatigue = max(0.0, self.fatigue - rest)
        self.morale = min(100.0, self.morale + joy)
