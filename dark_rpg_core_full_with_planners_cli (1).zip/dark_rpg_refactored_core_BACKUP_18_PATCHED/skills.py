from dataclasses import dataclass
from typing import Dict

@dataclass
class Skills:
    values: Dict[str, int]

    def get(self, name: str) -> int:
        return self.values.get(name, 0)

    def add(self, name: str, v: int = 1):
        self.values[name] = self.get(name) + v

