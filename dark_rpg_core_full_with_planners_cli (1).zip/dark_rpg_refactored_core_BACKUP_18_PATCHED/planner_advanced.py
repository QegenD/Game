from dataclasses import dataclass
from typing import List, Tuple, Dict, Any, Optional
from .actions import possible_actions, perform_action, Action
import copy, math, random

@dataclass
class PlanNode:
    actions: List[Action]
    score: float

class AdvancedPlanner:
    """Beam-search forward-simulating planner.
    It simulates actions on deep-copies of the world and scores resulting states with a utility function.
    The planner supports high-level goals by providing simple heuristics to reward desired conditions."""

    def __init__(self, world, beam_width: int = 6, max_depth: int = 4):
        self.world = world
        self.beam_width = beam_width
        self.max_depth = max_depth

    def utility(self, world_copy, actor_name: str, goal: Optional[Dict[str,Any]] = None) -> float:
        # Basic utility: actor HP + morale + inventory value + friends score
        a = world_copy.entities.get(actor_name)
        if a is None:
            return -1e6
        val = 0.0
        val += a.hp * 2.0
        val += a.needs.morale * 0.5
        # inventory value: count items times economy price (if available)
        inv_val = 0.0
        try:
            from .economy import Economy
            econ = world_copy.economy if hasattr(world_copy, 'economy') else Economy()
            for iid, qty in a.inv.items.items():
                inv_val += econ.price(iid) * qty
        except Exception:
            inv_val += sum(a.inv.items.values())
        val += inv_val * 0.3
        # social value: sum positive relations to others
        try:
            for other in world_copy.entities.keys():
                if other == actor_name: continue
                rel = world_copy.social.get(actor_name, other)
                if rel > 0:
                    val += rel * 0.05
        except Exception:
            pass
        # goal-specific bonuses
        if goal:
            if goal.get('type') == 'survive':
                # reward high HP / avoid death
                val += a.hp * 5.0
            if goal.get('type') == 'loot':
                # reward inventory size
                val += sum(a.inv.items.values()) * 2.0
            if goal.get('type') == 'socialize':
                # reward social sum
                ssum = 0.0
                for other in world_copy.entities.keys():
                    if other == actor_name: continue
                    ssum += world_copy.social.get(actor_name, other)
                val += ssum * 0.2
        # small random to break ties
        val += random.random()*0.01
        return val

    def plan(self, actor_name: str, goal: Optional[Dict[str,Any]] = None) -> List[Action]:
        root_world = self.world
        # initial beam: single empty plan with current score
        beam = [ ([], self.utility(root_world, actor_name, goal)) ]  # list of (actions, score)
        for depth in range(self.max_depth):
            candidates = []
            for actions_so_far, _ in beam:
                # simulate world by applying actions_so_far
                wc = copy.deepcopy(root_world)
                success_all = True
                for act in actions_so_far:
                    ok, msg, data = perform_action(wc, actor_name, act)
                    # apply world tick to reflect time passage for multi-step simulation
                    wc.tick()
                # enumerate next actions from wc
                acts = possible_actions(wc, actor_name)
                for a in acts:
                    # create new action sequence
                    seq = actions_so_far + [a]
                    # simulate seq on a fresh copy of root_world to avoid cumulative side-effects across beams
                    sim = copy.deepcopy(root_world)
                    for act in seq:
                        perform_action(sim, actor_name, act)
                        sim.tick()
                    sc = self.utility(sim, actor_name, goal)
                    candidates.append((seq, sc))
            if not candidates:
                break
            # sort and keep top beam_width
            candidates.sort(key=lambda x: -x[1])
            beam = candidates[:self.beam_width]
        # return best sequence actions
        if not beam:
            return []
        best_seq, best_score = beam[0]
        return best_seq

