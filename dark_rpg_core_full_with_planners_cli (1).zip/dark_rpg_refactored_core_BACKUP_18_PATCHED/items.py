from dataclasses import dataclass, field
from typing import Dict

@dataclass(frozen=True)
class Item:
    id: str
    name: str
    type: str  # weapon, armor, consumable, misc
    stats: Dict[str, float] = field(default_factory=dict)

WEAPONS = {
    "sword": Item("sword", "Iron Sword", "weapon", {"attack": 4, "crit_chance": 0.05}),
    "bow": Item("bow", "Short Bow", "weapon", {"attack": 3, "crit_chance": 0.08}),
}

ARMOR = {
    "leather": Item("leather", "Leather Armor", "armor", {"defense": 2}),
    "chain": Item("chain", "Chainmail", "armor", {"defense": 4}),
}

CONSUMABLES = {
    "potion": Item("potion", "Healing Potion", "consumable", {"heal": 8}),
}

def get_item(item_id: str) -> Item:
    for d in (WEAPONS, ARMOR, CONSUMABLES):
        if item_id in d: return d[item_id]
    raise KeyError(item_id)

