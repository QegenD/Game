from dataclasses import dataclass
from typing import Any, List, Tuple, Optional
import math, random, copy
from .actions import possible_actions, perform_action, Action

@dataclass
class MCTSNode:
    parent: Optional['MCTSNode']
    action: Optional[Action]
    state: Any
    visits: int = 0
    value: float = 0.0
    children: List['MCTSNode'] = None

    def __post_init__(self):
        if self.children is None:
            self.children = []

class MCTSPlanner:
    def __init__(self, world, iterations: int = 200, rollout_depth: int = 6):
        self.world = world
        self.iterations = iterations
        self.rollout_depth = rollout_depth

    def uct(self, node: MCTSNode, child: MCTSNode, c: float = 1.4):
        if child.visits == 0:
            return float('inf')
        return (child.value / child.visits) + c * math.sqrt(math.log(node.visits) / child.visits)

    def rollout(self, state, actor_name: str):
        # random rollout using possible_actions heuristically
        wc = copy.deepcopy(state)
        for _ in range(self.rollout_depth):
            acts = possible_actions(wc, actor_name)
            if not acts:
                break
            a = random.choice(acts)
            perform_action(wc, actor_name, a)
            wc.tick()
        # evaluate terminal state using simple utility
        a = wc.entities.get(actor_name)
        if a is None:
            return -1e6
        return a.hp + a.needs.morale*0.1 + sum(a.inv.items.values())*0.5

    def best_action(self, actor_name: str):
        root_state = copy.deepcopy(self.world)
        root = MCTSNode(parent=None, action=None, state=root_state)
        for it in range(self.iterations):
            node = root
            # selection
            while node.children:
                node = max(node.children, key=lambda ch: self.uct(node, ch))
            # expansion
            acts = possible_actions(node.state, actor_name)
            if acts:
                for a in acts:
                    st = copy.deepcopy(node.state)
                    perform_action(st, actor_name, a)
                    st.tick()
                    child = MCTSNode(parent=node, action=a, state=st)
                    node.children.append(child)
                # pick one child to simulate
                node = random.choice(node.children)
            # simulation
            reward = self.rollout(node.state, actor_name)
            # backup
            while node is not None:
                node.visits += 1
                node.value += reward
                node = node.parent
        # pick best child of root by value/visits
        if not root.children:
            return None
        best = max(root.children, key=lambda ch: ch.value/ch.visits if ch.visits>0 else -1e9)
        return best.action

