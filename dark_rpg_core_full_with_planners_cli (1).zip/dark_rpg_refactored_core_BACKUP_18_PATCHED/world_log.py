import json
import logging
from datetime import datetime
from config import settings

logger = logging.getLogger(__name__)
event_log_path = settings.get("event_log_path", "data/world_events.json")

def log_event(event_type, participants, description, consequences=None):
    entry = {
        "time": datetime.utcnow().isoformat(),
        "type": event_type,
        "participants": participants,
        "description": description,
        "consequences": consequences or {}
    }

    try:
        try:
            with open(event_log_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            data = []

        data.append(entry)

        with open(event_log_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        logger.debug(f"Logged event: {entry['type']} ({description})")

    except Exception as e:
        logger.exception("Failed to write world event to log.")
