import json
import os

class NSFWGallery:
    def __init__(self, gallery_path="data/nsfw_gallery.json"):
        self.gallery_path = gallery_path
        self.gallery = []
        self.load()

    def load(self):
        if os.path.exists(self.gallery_path):
            with open(self.gallery_path, "r", encoding="utf-8") as f:
                self.gallery = json.load(f)
        else:
            self.gallery = []

    def save(self):
        with open(self.gallery_path, "w", encoding="utf-8") as f:
            json.dump(self.gallery, f, indent=2, ensure_ascii=False)

    def add_scene(self, scene_data):
        tags = scene_data.get("tags", [])
        trust_required = scene_data.get("trust_level", 0)
        npc = scene_data.get("npc")
        auto_gallery = scene_data.get("auto_gallery", False)

        entry = {
            "npc": npc,
            "description": scene_data.get("description", ""),
            "tags": tags,
            "trust_level": trust_required,
            "timestamp": scene_data.get("timestamp")
        }

        self.gallery.append(entry)
        self.save()

        if auto_gallery:
            from auto_image_generator import generate_scene_image
            generate_scene_image(scene_data)

    def get_by_tag(self, tag):
        return [entry for entry in self.gallery if tag in entry["tags"]]

    def get_all_for_npc(self, npc_name):
        return [entry for entry in self.gallery if entry["npc"] == npc_name]