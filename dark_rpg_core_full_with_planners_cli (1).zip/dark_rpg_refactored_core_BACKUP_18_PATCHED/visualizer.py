# visualizer.py — визуализация связей
def visualize_npc_network(npc_list):
    print("NPC Network Graph:")
    for npc in npc_list:
        print(f" - {npc.name} connected to: {', '.join(npc.relationships)}")
