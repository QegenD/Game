import random
from training_context import get_game_context, generate_dynamic_response
from creative_control import CREATIVE_FLAGS
from world_state import get_world_flavor

scene_history = []

def generate_synthetic_scene(user_id=None):
    context = get_game_context()
    flavor = get_world_flavor()
    context += f" Сейчас {flavor}. Это влияет на атмосферу и ощущения."

    goal = "исследование" if CREATIVE_FLAGS.get("goal_based_story") else "перемещение"
    emotion = "тревога, волнение" if CREATIVE_FLAGS.get("deep_emotion_context") else "нейтрально"
    input_type = "story" if CREATIVE_FLAGS.get("full_creative") else "narration"

    scene_text = generate_dynamic_response(
        npc_name="мир",
        input_type=input_type,
        intent=goal,
        game_context=context + f" Эмоции: {emotion}."
    )

    if CREATIVE_FLAGS.get("no_repeat_scene") and scene_text in scene_history:
        return generate_synthetic_scene(user_id)
    scene_history.append(scene_text)

    image_path = f"assets/backgrounds/auto_scene_{random.randint(1,10)}.jpg"
    fight_triggered = random.choices([False, True], weights=[2, 1])[0] if "ночь" in flavor else random.choice([False, False, True])
    return scene_text, image_path, fight_triggered



# --- Psychological Dangers ---
psych_dangers = ["сталкинг", "проклятие", "галлюцинации"]

def trigger_fear(player, source):
    player.fear += 10
    if player.fear > 70:
        player.status_effects.append("паника")



# --- Post-Battle Scenes ---
def post_battle_options(enemy):
    if enemy.defeated:
        return ["убить", "пощадить", "подчинить", "соблазнить"]
