
# auto_image_generator.py — подключение SD по описанию событий

def generate_image(description, context="nsfw"):
    # Здесь будет вызов локального Stable Diffusion
    print(f"[SD] Генерация изображения для: {context.upper()} — {description[:60]}...")
