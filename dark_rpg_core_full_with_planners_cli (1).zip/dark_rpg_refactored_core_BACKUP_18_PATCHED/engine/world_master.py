
# world_master.py — Финальная интеграция AI-директора мира

import random
import json
from datetime import datetime

from engine.identity_system import IdentitySystem
from core.npc.npc_emotion_tracker import NPCEmotionTracker
from core.npc.secrets_system import SecretsSystem
from logic.social.gossip_engine import GossipEngine
from core.npc.npc_knowledge import NPCKnowledge

class WorldMaster:
    def __init__(self, world):
        self.world = world
        self.identity_system = IdentitySystem()
        self.secrets_system = SecretsSystem()
        self.gossip_engine = GossipEngine()
        self.world_log_path = "data/world_log.json"
        self.ticks = 0

    def tick(self):
        self.ticks += 1
        self.check_global_events()
        self.spread_gossip()
        self.update_emotions()
        self.detect_mask_breaks()
        self.write_log_if_needed()

    def check_global_events(self):
        # Периодически создаём мировые события (кризисы, катастрофы)
        if self.ticks % 100 == 0:
            crisis = random.choice(["plague", "war", "revolution", "religious_awakening"])
            self.log_event(f"WORLD CRISIS: {crisis.upper()} spreads across the realm.")
            for npc in self.world.npcs:
                if hasattr(npc, 'mood'):
                    npc.set_mood("afraid")

    def spread_gossip(self):
        self.gossip_engine.simulate_gossip(self.world.npcs, chance=0.3)

    def update_emotions(self):
        for npc in self.world.npcs:
            if not hasattr(npc, "emotions"):
                npc.emotions = NPCEmotionTracker()
            # Понижаем сильные эмоции со временем
            for key in npc.emotions.emotions:
                npc.emotions.emotions[key] = max(0, npc.emotions.emotions[key] - 1)

    def detect_mask_breaks(self):
        for npc in self.world.npcs:
            if hasattr(npc, "id") and self.identity_system.is_disguised(npc.id):
                if random.random() < 0.05:
                    true_identity = self.identity_system.reveal(npc.id)
                    self.log_event(f"{npc.name}'s true identity was revealed: {true_identity}!")
                    if hasattr(npc, 'emotions'):
                        npc.emotions.update_emotion("afraid", 80)

    def log_event(self, message):
        now = datetime.utcnow().isoformat()
        log_entry = {"tick": self.ticks, "timestamp": now, "message": message}
        try:
            with open(self.world_log_path, "r", encoding="utf-8") as f:
                logs = json.load(f)
        except Exception:
            logs = []
        logs.append(log_entry)
        with open(self.world_log_path, "w", encoding="utf-8") as f:
            json.dump(logs, f, indent=2)

    def write_log_if_needed(self):
        if self.ticks % 20 == 0:
            self.log_event(f"World tick {self.ticks}: routine cycle executed.")
