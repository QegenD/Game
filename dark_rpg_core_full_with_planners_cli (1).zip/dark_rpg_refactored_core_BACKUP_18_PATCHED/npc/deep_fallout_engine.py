
# deep_fallout_engine.py — глубинные последствия дуэлей и NSFW-революции

def process_duel_aftermath(winner, loser, world):
    if loser.get("bonded_to_player"):
        loser["bonded_to_player"] = False
        loser["mood"] = "broken"
        loser["status"] = "depressed"
        world.setdefault("rumors", []).append(f"{loser['name']} отверг игрока после проигрыша в дуэли.")

    if winner.get("bonded_to_player"):
        winner["mood"] = "proud"
        world.setdefault("rumors", []).append(f"{winner['name']} сразился за любовь и победил!")

    if loser.get("personality") in ["dominant", "vengeful"]:
        world.setdefault("plots", []).append(f"{loser['name']} поклялся отомстить за поражение.")

def escalate_nsfw_revolution(city, factions, world):
    if "nsfw_hotspot" in city.get("tags", []):
        extremist_factions = [f for f in factions if f.get("morality") == "strict"]
        for faction in extremist_factions:
            faction["attitude_to_player"] = "aggressive"
            faction.setdefault("plots", []).append("exorcise city")
            world.setdefault("events", []).append(f"{faction['name']} начали поход против {city['name']}!")

        if city.get("features", []).count("underground_club") >= 2:
            cult = {
                "name": f"Секта Плоти ({city['name']})",
                "influence": "growing",
                "morality": "corrupt",
                "goal": "spread lust"
            }
            world.setdefault("factions", []).append(cult)
            world.setdefault("events", []).append(f"В {city['name']} появилась секта наслаждения.")
