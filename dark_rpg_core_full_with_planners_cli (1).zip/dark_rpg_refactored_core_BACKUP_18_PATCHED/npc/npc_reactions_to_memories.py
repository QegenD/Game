
# npc_reactions_to_memories.py — NPC реагируют на прошлые сцены

from nsfw.memories.nsfw_memories import find_memories_by_npc
from random import randint, choice

def determine_behavior_from_memories(npc):
    memories = find_memories_by_npc(npc.name)
    if not memories:
        return

    recent = memories[-1]
    desc = recent["description"].lower()

    if "насилие" in desc or "жертвоприношение" in desc:
        if randint(0, 100) < 40:
            npc.set_goal("avoid_location")
            npc.set_mood("тревожный")
            npc.log_event(f"⚠️ {npc.name} избегает мест, связанных с: {recent['description']}")
    elif "секс" in desc or "соблазнение" in desc:
        if randint(0, 100) < 50:
            npc.set_goal("find_same_pleasure")
            npc.set_mood("одержим")
            npc.log_event(f"🔥 {npc.name} одержим желанием повторить: {recent['description']}")
    elif "любовь" in desc or "романтика" in desc:
        if randint(0, 100) < 30:
            npc.set_goal("reconnect_with_past")
            npc.set_mood("меланхолия")
            npc.log_event(f"💘 {npc.name} вспоминает любовь из прошлого: {recent['description']}")
