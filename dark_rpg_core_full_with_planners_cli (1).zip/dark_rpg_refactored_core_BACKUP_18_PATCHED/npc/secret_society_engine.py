
# secret_society_engine.py — генерация тайных обществ и участие NPC

import random

SECRET_ORDERS = [
    {"name": "Орден Крови", "motto": "Сила в жертве", "focus": "NSFW_ритуалы"},
    {"name": "Маска Бездны", "motto": "Никто не должен знать", "focus": "шпионаж"},
    {"name": "Наследие Света", "motto": "Истина через кровь", "focus": "магия"},
]

def assign_society(npc, world):
    if random.random() < 0.07:
        order = random.choice(SECRET_ORDERS)
        npc["secret_order"] = order["name"]
        world.setdefault("secret_members", []).append(npc["name"])
        world.setdefault("rumors", []).append(
            f"Ходят слухи, что {npc['name']} принадлежит к тайному обществу: {order['name']}."
        )

def society_event(world):
    if random.random() < 0.25:
        order = random.choice(SECRET_ORDERS)
        world.setdefault("rituals", []).append({
            "order": order["name"],
            "event": f"Тайный ритуал прошёл в тени. Мотто: {order['motto']}",
            "effect": order["focus"]
        })
