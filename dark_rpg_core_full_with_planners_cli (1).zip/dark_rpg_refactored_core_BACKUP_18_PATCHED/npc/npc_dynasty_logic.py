
# npc_dynasty_logic.py — NPC реагируют на династическую принадлежность и конфликты

import json
import os
import random

DYNASTY_FILE = os.path.join("world", "npc_dynasties.json")
CONFLICT_FILE = os.path.join("world", "dynasty_conflicts.json")

def load_json(path):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

class DynastyAwareness:
    def __init__(self, npc):
        self.npc = npc
        self.dynasty_name = npc.get("dynasty")
        self.conflicts = load_json(CONFLICT_FILE).get("conflicts", [])

    def is_enemy_of(self, other_dynasty):
        for conflict in self.conflicts:
            if conflict["status"] == "активный":
                if (conflict["dynasty1"] == self.dynasty_name and conflict["dynasty2"] == other_dynasty) or                    (conflict["dynasty2"] == self.dynasty_name and conflict["dynasty1"] == other_dynasty):
                    return True
        return False

    def react_to(self, other_npc):
        other_dynasty = other_npc.get("dynasty")
        if not self.dynasty_name or not other_dynasty:
            return None

        if self.is_enemy_of(other_dynasty):
            return random.choice([
                f"{self.npc['name']} презирает представителя династии {other_dynasty}.",
                f"{self.npc['name']} шепчет, что род {other_dynasty} предатели.",
                f"{self.npc['name']} отказывается сотрудничать с династией {other_dynasty}."
            ])
        elif self.dynasty_name == other_dynasty:
            return random.choice([
                f"{self.npc['name']} приветствует сородича из дома {self.dynasty_name}.",
                f"{self.npc['name']} доверяет представителю родного дома {self.dynasty_name}."
            ])
        else:
            return random.choice([
                f"{self.npc['name']} нейтрально относится к династии {other_dynasty}.",
                f"{self.npc['name']} наблюдает за {other_npc['name']} без эмоций."
            ])
