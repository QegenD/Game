
# goals_dynastic_expansion.py — цели NPC: потомство и объединение родов

import random

def assign_family_goal(npc):
    options = [
        "родить наследника",
        "выдать дочь за влиятельного лорда",
        "объединить два враждующих рода",
        "улучшить династическую репутацию",
        "выйти замуж за принца"
    ]
    npc['long_term_goal'] = random.choice(options)
    return npc['long_term_goal']
