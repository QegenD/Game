
# npc_allegiance_logic.py — конфликты лояльностей NPC

def resolve_allegiances(npc):
    allegiance = {
        "family": npc.get("family_name"),
        "order": npc.get("secret_order"),
        "player_loyalty": npc.get("player_loyalty")
    }

    loyalty_score = 0
    if allegiance["family"]:
        loyalty_score += 1
    if allegiance["order"]:
        loyalty_score += 1
    if allegiance["player_loyalty"]:
        loyalty_score += 2

    npc["allegiance_conflict"] = loyalty_score >= 2
