
# dynasty_faction_ai.py — династии как фракции, если влиятельны

def promote_dynasty_to_faction(world):
    for npc in world.get("npcs", {}).values():
        fam = npc.get("family_name")
        if not fam:
            continue

        influence = npc.get("titles", []) + npc.get("lands", []) + npc.get("wealth", [])
        if len(influence) >= 5:
            factions = world.setdefault("dynasty_factions", {})
            if fam not in factions:
                factions[fam] = {
                    "name": f"Дом {fam}",
                    "leader": npc["name"],
                    "goal": "власть, контроль и наследие",
                    "members": [npc["name"]],
                    "faction_type": "династия"
                }
