
# cursed_bloodlines.py — проклятия родов

import random

POSSIBLE_CURSES = [
    "bloodlust", "madness", "infertility", "lust", "betrayal", "incest", "demonic_visions"
]

def assign_curse_if_needed(npc, world):
    if "family_name" not in npc:
        return

    family = npc["family_name"]
    cursed = world.setdefault("cursed_families", {})

    if family in cursed:
        npc.setdefault("curses", []).append(cursed[family])
    else:
        if random.randint(0, 20) == 0:
            curse = random.choice(POSSIBLE_CURSES)
            cursed[family] = curse
            npc.setdefault("curses", []).append(curse)
            world.setdefault("rumors", []).append(f"Ходят слухи, что род {family} проклят: {curse}")
