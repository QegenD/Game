
# npc_lineage_engine.py — династии и наследие

import random

def create_child(parents):
    first, second = parents
    child_name = f"{random.choice(['Al', 'Ri', 'Ser', 'Ka', 'Vel'])}{random.choice(['dor', 'lina', 'mir', 'eth'])}"
    child = {
        "name": child_name,
        "race": first["race"] if random.random() < 0.5 else second["race"],
        "class": random.choice([first["class"], second["class"]]),
        "traits": list(set(first.get("traits", []) + second.get("traits", [])))[:3],
        "faction": random.choice([first.get("faction"), second.get("faction")]),
        "relations": {
            "father": first["name"],
            "mother": second["name"]
        }
    }
    return child
