
# dynasty_inheritance_engine.py — наследование титулов, земель и богатства

import random

def process_inheritance(npc, world):
    heirs = npc.get("children", []) or npc.get("siblings", [])
    if not heirs:
        return

    heir = random.choice(heirs)
    heir_obj = world["npcs"].get(heir)
    if not heir_obj:
        return

    inheritance = npc.get("titles", []) + npc.get("wealth", []) + npc.get("lands", [])
    if inheritance:
        heir_obj.setdefault("titles", []).extend(npc.get("titles", []))
        heir_obj.setdefault("wealth", []).extend(npc.get("wealth", []))
        heir_obj.setdefault("lands", []).extend(npc.get("lands", []))
        world.setdefault("rumors", []).append(f"{heir} унаследовал всё от {npc['name']}.")

        # Запись в хронику
        world.setdefault("dynasty_events", []).append({
            "type": "inheritance",
            "from": npc["name"],
            "to": heir,
            "items": inheritance
        })
