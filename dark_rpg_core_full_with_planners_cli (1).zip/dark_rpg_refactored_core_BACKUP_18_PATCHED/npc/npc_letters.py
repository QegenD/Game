
# npc_letters.py — NPC пишут письма, дневники, заметки

import random

def generate_npc_letter(npc):
    if not hasattr(npc, "letters"):
        npc.letters = []

    templates = [
        f"Я боюсь, что правда выйдет наружу. Подпись: {npc.name}",
        f"Они забрали её. Я никому не могу доверять...",
        f"Если ты читаешь это — я, возможно, уже мёртв(а).",
        f"Я люблю тебя, но они следят за мной. Прости.",
    ]
    letter = random.choice(templates)
    npc.letters.append(letter)
    return letter

def get_letters(npc):
    return npc.letters if hasattr(npc, "letters") else []
