import readline  # better input experience
from .world_master import World, Entity
from .items import get_item
from .planner_advanced import AdvancedPlanner
from .planner_mcts import MCTSPlanner
from .planner_strips import StripsPlanner
from .actions import Action
from .dialogue_system import DialogueSystem
import sys, json

def print_header(w):
    print('=== DarkRPG Local ===')
    print('Time:', w.time)
    print('Entities:', ', '.join(w.entities.keys()))

def choose_actions_cli(world, name):
    acts = world.list_actions(name)
    for i,a in enumerate(acts):
        print(f'[{i}] {a.name} {a.params}')
    print('[p] planner suggestions, [q] quit')
    cmd = input('Action> ').strip()
    if cmd == 'q': sys.exit(0)
    if cmd == 'p':
        # ask which planner
        print('Choose planner: [1] Advanced Beam [2] MCTS [3] STRIPS')
        p = input('planner> ').strip()
        if p == '1':
            planner = world.get_planner()
            plan = planner.make_plan(name, steps=1)
            if plan:
                return plan[0].action
        if p == '2':
            m = MCTSPlanner(world, iterations=200)
            a = m.best_action(name)
            return a
        if p == '3':
            goal = {}
            g = input('Goal (have_item:item_id / at:x,y / hp_gt:n) > ').strip()
            if g.startswith('have_item:'):
                goal = {'have_item': g.split(':',1)[1]}
            elif g.startswith('at:'):
                coords = g.split(':',1)[1].split(',')
                goal = {'at': (int(coords[0]), int(coords[1]))}
            elif g.startswith('hp_gt:'):
                goal = {'hp_gt': int(g.split(':',1)[1])}
            sp = StripsPlanner(world)
            seq = sp.plan(name, goal)
            if seq:
                act = seq[0]
                return Action(name=act['name'], params=act.get('params',{}))
            return None
        return None
    try:
        idx = int(cmd)
        acts = world.list_actions(name)
        return acts[idx]
    except Exception as e:
        print('invalid input', e)
        return None

def main():
    w = World()
    # create demo entities if none
    hero = Entity('Player', pos=(1,1)); hero.inv.add(get_item('sword')); hero.inv.add(get_item('potion'),2)
    gob = Entity('Gob', pos=(3,1)); gob.inv.add(get_item('potion'),1)
    w.add_entity(hero); w.add_entity(gob)
    ds = DialogueSystem()
    while True:
        print_header(w)
        action = choose_actions_cli(w, 'Player')
        if action is None:
            print('No action chosen. Skipping.')
        else:
            ok, msg, data = w.do_action('Player', action)
            print('Result:', ok, msg, data)
        w.tick()
        input('Press Enter to continue...')

if __name__ == '__main__':
    main()

