from dataclasses import dataclass, field
from typing import Dict

@dataclass
class Economy:
    prices: Dict[str, int] = field(default_factory=lambda: {"potion": 10, "sword": 40, "leather": 30, "bow": 50, "chain": 80})

    def price(self, item_id: str) -> int:
        return self.prices.get(item_id, 5)

    def set_price(self, item_id: str, v: int):
        self.prices[item_id] = max(1, v)

