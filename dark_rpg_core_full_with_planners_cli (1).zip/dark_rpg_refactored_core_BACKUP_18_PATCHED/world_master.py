from dataclasses import dataclass, field
from typing import Dict, Tuple, List
import random

from .social_graph import SocialGraph
from .combat import perform_attack, CombatLog
from .map_ai import GridMap, astar
from .mature_plugin import suggest_scene_for_view as _suggest_scene_for_view
from .actions import possible_actions, perform_action, Action
from .planner import SimplePlanner

from .emotion_needs import Needs
from .chronicles import Chronicles
from .romance_engine import RomanceEngine
from .violence_system import decide_violence
from .newspaper_generator import headline
from .items import get_item, Item
from .inventory import Inventory
from .status_effects import StatusEffect, tick_effects
from .skills import Skills
from .quests import QuestLog, Quest
from .loot import drop_table
from .economy import Economy
from .event_bus import BUS
from .time_calendar import GameTime

Vec = Tuple[int,int]

@dataclass
class Entity:
    name: str
    hp: int = 10
    attack: int = 5
    defense: int = 2
    pos: Vec = (0,0)
    faction: str = "Neutral"
    needs: Needs = field(default_factory=Needs)
    inv: Inventory = field(default_factory=Inventory)
    skills: Skills = field(default_factory=lambda: Skills({"melee": 1, "ranged": 0, "sneak": 0, "speech": 0}))
    effects: Dict[str, StatusEffect] = field(default_factory=dict)

    def as_dict(self):
        attack_bonuses = []
        defense_bonuses = []
        # derive from equipment simple bonuses (first weapon/armor found)
        if "sword" in self.inv.items: attack_bonuses.append(4)
        if "bow" in self.inv.items: attack_bonuses.append(3)
        if "chain" in self.inv.items: defense_bonuses.append(4)
        if "leather" in self.inv.items: defense_bonuses.append(2)
        return {
            "name": self.name,
            "hp": self.hp,
            "attack": self.attack + self.skills.get("melee"),
            "defense": self.defense,
            "attack_bonuses": attack_bonuses,
            "defense_bonuses": defense_bonuses,
            "crit_chance": 0.05 + 0.01*self.skills.get("melee"),
            "resist": 0
        }

@dataclass
class World:
    size: Tuple[int,int] = (24, 18)
    walls: List[Vec] = field(default_factory=list)
    entities: Dict[str, Entity] = field(default_factory=dict)
    social: SocialGraph = field(default_factory=SocialGraph)
    romance: RomanceEngine = field(default_factory=RomanceEngine)
    chronicles: Chronicles = field(default_factory=Chronicles)
    questlog: QuestLog = field(default_factory=QuestLog)
    economy: Economy = field(default_factory=Economy)
    time: GameTime = field(default_factory=GameTime)

    def __post_init__(self):
        self.map = GridMap(self.size[0], self.size[1], set(self.walls))
        BUS.on("attack", lambda e,p: self.chronicles.log("attack_event", **p))

    def add_entity(self, e: Entity):
        self.entities[e.name] = e
        self.chronicles.log("spawn", entity=e.name, pos=e.pos)

    def move_towards(self, name: str, goal: Vec) -> List[Vec]:
        e = self.entities[name]
        path = astar(self.map, e.pos, goal)
        if len(path) >= 2:
            e.pos = path[1]
            self.chronicles.log("move", entity=name, to=e.pos)
        return path

    def use_item(self, name: str, item_id: str) -> bool:
        e = self.entities[name]
        from .items import get_item
        it = get_item(item_id)
        if it.type == "consumable" and e.inv.remove(it, 1):
            heal = int(it.stats.get("heal", 0))
            if heal:
                e.hp = min( e.hp + heal, 10 + e.defense*2 )
                self.chronicles.log("use_item", entity=name, item=it.name, heal=heal)
                return True
        return False

    def tick(self):
        self.time.advance_hours(1)
        # update needs & statuses
        for e in self.entities.values():
            e.needs.tick()
            tick_effects(e.effects)

        # random interactions
        names = list(self.entities.keys())
        if len(names) >= 2:
            a,b = random.sample(names, 2)
            rel = self.social.get(a,b)
            vio = decide_violence(hostility=-rel, morale=self.entities[a].needs.morale)
            if vio.should_attack and self._adjacent(a,b):
                log = self._attack(a,b)
                BUS.emit("attack", {"a": a, "b": b, "hit": log.hit, "dmg": log.damage})
                if self.entities[b].hp <= 0:
                    self._on_defeat(b, a)
            else:
                if rel < 60 and random.random() < 0.3:
                    self.social.befriend(a,b, amount=5)
                    self.chronicles.log("befriend", a=a, b=b, score=self.social.get(a,b))

        # progress active quests
        self.questlog.tick()

    def _adjacent(self, a: str, b: str) -> bool:
        pa = self.entities[a].pos
        pb = self.entities[b].pos
        return abs(pa[0]-pb[0]) + abs(pa[1]-pb[1]) == 1

    def _attack(self, a: str, b: str) -> CombatLog:
        A = self.entities[a]
        B = self.entities[b]
        log = perform_attack(A.as_dict(), B.as_dict())
        B.hp = log.remaining_hp
        self.chronicles.log("attack", a=a, b=b, hit=log.hit, dmg=log.damage, crit=log.crit, hp=B.hp)
        if B.hp <= 0:
            self.chronicles.log("defeat", loser=b, by=a)
        return log

    def _on_defeat(self, loser: str, by: str):
        # loot drops
        tier = 1 + self.entities[by].skills.get("melee")//3
        drops = drop_table(tier)
        for iid in drops:
            self.entities[by].inv.add(get_item(iid), 1)
        self.chronicles.log("loot", winner=by, loser=loser, items=drops)

    def daily_news(self) -> str:
        events = []
        for e in self.chronicles.entries[-40:]:
            if e.type in {"attack","befriend","defeat"}:
                events.append({"a": e.data.get("a"), "b": e.data.get("b")})
        return headline(events)

    # --- Content rating & hooks ---
    content_rating: str = "PG-13"  # enforced in this build

    def suggest_intimate_scene(self, a: str, b: str, viewer_is_adult: bool = False, preferred_tag: str = None) -> str:
        # Use external mature plugin to supply scene text if available. The plugin loads
        # local content only and does NOT generate explicit content automatically.
        try:
            return _suggest_scene_for_view(self, a, b, viewer_is_adult, preferred_tag)
        except Exception as e:
            # fallback safe behavior
            return f"{a} и {b} проводят тёплый вечер вместе. Камера плавно отъезжает — дальше сцена за кадром."

    # --- Action API for agents/players ---
    def list_actions(self, actor_name: str):
        return possible_actions(self, actor_name)

    def do_action(self, actor_name: str, action):
        return perform_action(self, actor_name, action)

    def get_planner(self):
        return SimplePlanner(self)

