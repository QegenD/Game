import random
from dataclasses import dataclass

@dataclass
class Crisis:
    name: str
    severity: int  # 1..5

CRISES = [
    Crisis("Blight", 3),
    Crisis("Bandit Uprising", 2),
    Crisis("Arcane Storm", 4),
    Crisis("Famine", 5),
]

def roll_crisis() -> Crisis:
    return random.choice(CRISES)
