
# inquisition_torture.py — пытки разоблачённых NPC

def torture_npc(npc):
    if "interrogated" in npc.status_effects:
        npc.fear += 15
        npc.loyalty = max(npc.loyalty - 10, 0)
        npc.trauma.append("tortured")
        if npc.secret_affiliation == "cult":
            npc.exposed = True
