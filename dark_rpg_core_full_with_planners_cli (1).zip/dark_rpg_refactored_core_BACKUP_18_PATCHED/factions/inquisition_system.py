
# inquisition_system.py — Инквизиция: охота на тьму, допросы, изгнание

class Inquisition:
    def __init__(self):
        self.agents = []
        self.accusations = []

    def assign_agent(self, npc):
        npc.faction = "Inquisition"
        npc.role = "inquisitor"
        self.agents.append(npc)
        print(f"{npc.name} was appointed as inquisitor.")

    def accuse(self, target_npc):
        self.accusations.append(target_npc)
        print(f"{target_npc.name} has been accused of heresy!")

    def investigate(self, target_npc):
        print(f"Inquisition investigates {target_npc.name}...")
        if getattr(target_npc, 'cultist', False):
            print(f"{target_npc.name} is found guilty and sentenced.")
            target_npc.status = "imprisoned"
        else:
            print(f"{target_npc.name} found innocent.")
