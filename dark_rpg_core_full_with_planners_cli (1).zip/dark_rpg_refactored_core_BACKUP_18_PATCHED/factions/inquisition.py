
# inquisition.py — Следящие за культом и охотники на ведьм

from random import choice

class Inquisitor:
    def __init__(self, name, rank="Охотник"):
        self.name = name
        self.rank = rank
        self.reputation = 0
        self.investigations = []

    def investigate(self, npc):
        if getattr(npc, 'is_cultist', False):
            self.reputation += 1
            return f"{self.name} разоблачает культ в лице {npc.name}!"
        return f"{self.name} не нашёл улик против {npc.name}"

    def interrogate(self, npc):
        responses = [
            "Я ничего не знаю!", "Вы ошибаетесь!", "Я служу только Свету!", "Скоро ты познаешь Истину..."
        ]
        return f"{self.name} допрашивает {npc.name}: '{choice(responses)}'"

    def purge(self, npc):
        if getattr(npc, 'is_cultist', False):
            npc.status = "убит инквизицией"
            return f"{npc.name} был очищен огнём по приговору {self.name}"
        return f"{npc.name} был оправдан"

def generate_inquisitor():
    names = ["Валентин", "Сибилла", "Рафаэль", "Маркус", "Аделаида"]
    return Inquisitor(name=choice(names))
