
# holy_inquisition.py — инквизиция против культов

import random

def scan_for_heresy(world_state, cults, npcs):
    log = []
    for cult in cults:
        region = cult.get('region')
        infected = [npc for npc in npcs if npc.get('cult_id') == cult['id']]
        if len(infected) >= 3:
            log.append(f"⚔️ Инквизиция мобилизована против культа '{cult['name']}' в регионе {region}.")

            # Репрессии
            for npc in random.sample(infected, min(2, len(infected))):
                npc['arrested'] = True
                npc['status'] = 'пойман инквизицией'
                log.append(f"🕯️ NPC {npc['name']} арестован за еретическую деятельность.")
    return log
