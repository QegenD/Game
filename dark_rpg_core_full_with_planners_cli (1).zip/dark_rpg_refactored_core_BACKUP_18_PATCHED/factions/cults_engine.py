
# cults_engine.py — управление культами, их членами и поведением

import random

CULT_TYPES = [
    {
        "name": "Культ Огня",
        "theme": "жертвоприношения",
        "symbol": "пылающий кинжал",
        "rituals": ["сожжение", "пламя страсти"]
    },
    {
        "name": "Культ Крови",
        "theme": "наследие и родство",
        "symbol": "капля крови на черепе",
        "rituals": ["скрещивание крови", "жертвенный союз"]
    },
    {
        "name": "Культ Безликой Истины",
        "theme": "запретные знания",
        "symbol": "глаз без лица",
        "rituals": ["поглощение сознания", "прикосновение к забвению"]
    },
    {
        "name": "Культ Плетущих Страсть",
        "theme": "эротическое доминирование",
        "symbol": "плетёный венок из тел",
        "rituals": ["танец подчинения", "ритуальный акт"]
    }
]

def assign_cult(npc):
    if random.random() < 0.1:  # 10% шанс, что NPC принадлежит культу
        cult = random.choice(CULT_TYPES)
        npc['cult'] = cult['name']
        npc['cult_role'] = random.choice(["адепт", "жрец", "одержимый"])
        npc['known_rituals'] = random.sample(cult['rituals'], k=1)
    return npc
