
# persecution_engine.py — гонения NPC и игрока, если их разоблачает Инквизиция

def apply_persecution(world_state, player, npcs):
    persecuted = []

    for npc in npcs:
        if npc.faction == "cult" and npc.exposed:
            npc.status_effects.append("persecuted")
            npc.reputation["inquisition"] -= 10
            npc.fear += 5
            persecuted.append(npc.name)

    if player.faction == "cult" and player.exposed:
        player.status_effects.append("persecuted")
        player.reputation["inquisition"] -= 15
        player.fear += 10
        persecuted.append(player.name)

    world_state.setdefault("persecution_log", []).extend(persecuted)
    return persecuted
