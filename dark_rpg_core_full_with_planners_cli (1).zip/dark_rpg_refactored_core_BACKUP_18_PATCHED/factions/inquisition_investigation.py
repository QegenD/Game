
# inquisition_investigation.py — расследования и разоблачения

def conduct_inquisition_investigation(world_state, targets):
    for t in targets:
        suspicion = t.traits.get("suspicion", 0)
        if suspicion > 7:
            t.exposed = True
            t.status_effects.append("interrogated")
