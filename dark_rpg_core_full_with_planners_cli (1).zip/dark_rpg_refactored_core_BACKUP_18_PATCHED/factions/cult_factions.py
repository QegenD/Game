
# cult_factions.py — демонические ордена, фракции боли, фракции искажения

class CultFaction:
    def __init__(self, name, doctrine, leader_npc=None):
        self.name = name
        self.doctrine = doctrine
        self.leader = leader_npc
        self.reputation = -20
        self.members = []

    def add_member(self, npc):
        npc.faction = self
        npc.cultist = True
        self.members.append(npc)
        print(f"{npc.name} has joined the cult faction: {self.name}")

    def perform_dark_action(self):
        print(f"The cult '{self.name}' performs a vile act in line with '{self.doctrine}'...")
        self.reputation -= 1
