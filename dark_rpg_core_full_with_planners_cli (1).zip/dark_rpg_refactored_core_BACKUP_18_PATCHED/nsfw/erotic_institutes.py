
# erotic_institutes.py — школы соблазна, бордели, элитные ученики

import random

class EroticSchool:
    def __init__(self, name):
        self.name = name
        self.specialties = random.sample(["тантра", "владение телом", "доминирование", "ароматерапия"], 2)

    def train_npc(self, npc):
        npc.tags.append("seducer")
        npc.dialogue.append(f"Я прошёл обучение в школе '{self.name}' ({', '.join(self.specialties)})")

class Brothel:
    def __init__(self):
        self.workers = []

    def hire_worker(self, npc):
        npc.tags.append("courtesan")
        npc.dialogue.append("Я — элитная куртизанка. Моё тело — моё оружие.")
        self.workers.append(npc)
