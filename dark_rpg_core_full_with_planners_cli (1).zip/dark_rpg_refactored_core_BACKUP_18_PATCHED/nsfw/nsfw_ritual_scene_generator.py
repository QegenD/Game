
# nsfw_ritual_scene_generator.py — генерация NSFW сцен ритуалов

import random

def generate_nsfw_ritual_scene(cult_name, participants):
    poses = ["на алтаре", "в кругу свечей", "в масках", "в трансе"]
    acts = ["прикосновения", "слияние тел", "жертвенный экстаз", "ритуальный танец"]

    scene = {
        "title": f"Ритуал культа: {cult_name}",
        "description": f"{random.choice(participants)} и {random.choice(participants)} {random.choice(acts)} {random.choice(poses)}.",
        "nsfw_level": "extreme" if cult_name in ["Культ Крови", "Культ Плетущих Страсть"] else "mild"
    }
    return scene
