
# nsfw_slave_markets.py — нелегальные теневые рынки рабства

import random

def generate_slave_market(world):
    cities = [loc for loc in world.get("locations", []) if loc.get("type") == "city"]
    if not cities:
        return None

    market = {
        "location": random.choice(cities)["name"],
        "slaves": [],
        "reputation_hit": -2
    }

    candidates = [npc for npc in world["npcs"] if npc.get("captured")]
    market["slaves"] = random.sample(candidates, min(5, len(candidates)))

    world.setdefault("slave_markets", []).append(market)
    return market
