
# nsfw_arena_consequences.py — спасения, разоблачения, фракционное вмешательство

import random

def attempt_rescue(world, npc_name):
    npc = next((n for n in world["npcs"] if n["name"] == npc_name), None)
    if not npc or not npc.get("black_market_tag"):
        return {"success": False, "reason": "NPC не найден или не в рабстве."}

    chance = 0.3
    if "heroic_faction" in world:
        chance += 0.2

    result = random.random() < chance
    if result:
        npc["rescued"] = True
        npc["black_market_tag"] = False
        npc["gratitude"] = 10
        return {"success": True, "message": f"{npc_name} спасён(а)!"}
    else:
        return {"success": False, "reason": "Попытка спасения провалена."}

def expose_arena(world, arena_name):
    for arena in world.get("underground_arenas", []):
        if arena["name"] == arena_name:
            arena["exposed"] = True
            arena["prestige"] = 0
            return {"exposed": True, "message": f"Арена '{arena_name}' разоблачена!"}
    return {"exposed": False, "message": "Арена не найдена."}

def faction_influence_arena(world, faction):
    if "underground_arenas" not in world:
        return None

    for arena in world["underground_arenas"]:
        influence = random.choice(["поддержка", "преследование", "подкуп"])
        arena.setdefault("faction_interactions", []).append({
            "faction": faction["name"],
            "action": influence
        })
