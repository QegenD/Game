
# nsfw_arena_and_blackmarket.py — подпольные арены и чёрный рынок плоти

import random

def create_underground_arena(world):
    city = random.choice([l for l in world["locations"] if l["type"] == "city"])
    arena = {
        "location": city["name"],
        "name": f"Арена Теней {city['name']}",
        "participants": [],
        "shows": [],
        "slave_bets": [],
        "prestige": random.randint(1, 5)
    }

    world.setdefault("underground_arenas", []).append(arena)
    return arena

def host_nsfw_show(arena, slaves):
    show = {
        "type": random.choice(["порочное шоу", "обряд похоти", "насильственное зрелище"]),
        "slaves": [s["name"] for s in slaves],
        "success": random.choice([True, False]),
        "reactions": []
    }

    for s in slaves:
        s["humiliated"] = True
        if random.random() < 0.3:
            s["broken"] = True
            show["reactions"].append(f"{s['name']} сломлен(а) на глазах у толпы.")
        else:
            show["reactions"].append(f"{s['name']} с трудом выдержал(а) выступление.")

    arena["shows"].append(show)
    return show

def place_on_black_market(npc):
    npc["black_market_tag"] = True
    npc["value"] = random.randint(100, 1000)
    npc["fetish_tag"] = random.choice(["exotic", "rare", "broken", "virgin"])
    return npc
