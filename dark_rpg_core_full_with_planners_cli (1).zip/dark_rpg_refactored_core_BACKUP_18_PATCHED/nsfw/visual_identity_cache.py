
# visual_identity_cache.py — кеш описаний внешности NPC/игрока для консистентных NSFW-изображений

identity_cache = {}

def get_or_create_visual_identity(entity):
    if entity["id"] in identity_cache:
        return identity_cache[entity["id"]]

    identity = {
        "race": entity.get("race", "human"),
        "class": entity.get("class", "commoner"),
        "hair": entity.get("hair", "unknown"),
        "body": entity.get("body", "slim"),
        "style": entity.get("style", "default"),
        "gear": entity.get("gear", []),
        "special": entity.get("special_traits", [])
    }

    prompt = (
        f"{identity['race']} {identity['class']}, {identity['body']} body, "
        f"{identity['hair']} hair, wearing: {', '.join(identity['gear'])}. "
        f"Traits: {', '.join(identity['special']) if identity['special'] else 'none'}."
    )

    identity_cache[entity["id"]] = prompt
    return prompt
