
# black_market.py — теневой рынок: рабы, тела, артефакты, зелья

import random

class BlackMarket:
    def __init__(self):
        self.goods = []

    def generate_goods(self):
        self.goods = random.sample([
            {"name": "Рабыня-эльф", "type": "slave", "price": 500},
            {"name": "Наркозелье", "type": "potion", "price": 120},
            {"name": "Пленённый демон", "type": "entity", "price": 800},
            {"name": "Камень вожделения", "type": "artifact", "price": 1000}
        ], k=2)

    def buy(self, item_name, player):
        item = next((g for g in self.goods if g["name"] == item_name), None)
        if item and player.gold >= item["price"]:
            player.gold -= item["price"]
            return f"Покупка успешна: {item_name}"
        return "Недостаточно золота или товар отсутствует"
