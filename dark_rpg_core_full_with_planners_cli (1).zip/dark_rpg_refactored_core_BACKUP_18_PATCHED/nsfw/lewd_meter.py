
# lewd_meter.py — шкала порочности

class LewdMeter:
    def __init__(self, npc):
        self.npc = npc
        self.level = npc.get("lewd_level", 0)

    def increase(self, amount):
        self.level = min(100, self.level + amount)
        self.npc["lewd_level"] = self.level

    def decrease(self, amount):
        self.level = max(0, self.level - amount)
        self.npc["lewd_level"] = self.level

    def describe(self):
        if self.level < 10:
            return "практически невинный"
        elif self.level < 30:
            return "немного развращённый"
        elif self.level < 60:
            return "открыт к извращениям"
        elif self.level < 85:
            return "глубоко порочный"
        else:
            return "абсолютный развратник"
