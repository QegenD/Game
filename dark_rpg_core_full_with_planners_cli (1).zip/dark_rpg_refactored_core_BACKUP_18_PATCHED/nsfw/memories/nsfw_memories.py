
# nsfw_memories.py — система воспоминаний, карточек и визуальных сцен NSFW

from datetime import datetime
import uuid

NSFW_MEMORIES = []

def create_nsfw_memory(scene_type, description, image_prompt=None, participants=None):
    memory = {
        "id": str(uuid.uuid4()),
        "scene_type": scene_type,
        "description": description,
        "image_prompt": image_prompt,
        "participants": [p.get("name", "unknown") for p in (participants or [])],
        "timestamp": datetime.now().isoformat()
    }
    NSFW_MEMORIES.append(memory)
    return memory

def get_recent_memories(limit=10):
    return NSFW_MEMORIES[-limit:]

def find_memories_by_npc(npc_name):
    return [m for m in NSFW_MEMORIES if npc_name in m["participants"]]
