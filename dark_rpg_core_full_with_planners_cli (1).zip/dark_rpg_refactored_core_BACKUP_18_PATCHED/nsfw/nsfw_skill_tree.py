
# nsfw_skill_tree.py — эротические навыки персонажей

NSFW_SKILLS = {
    "oral_technique": "Оральные техники",
    "bdsm": "БДСМ",
    "domination": "Доминирование",
    "submission": "Подчинение",
    "groupplay": "Групповое участие",
    "erotic_theatre": "Театр тела",
    "tantric": "Тантра",
    "public_exposure": "Публичность"
}

class NSFWSkillTree:
    def __init__(self, npc):
        self.npc = npc
        self.skills = {skill: 0 for skill in NSFW_SKILLS}

    def gain_xp(self, skill, amount=1):
        if skill in self.skills:
            self.skills[skill] = min(self.skills[skill] + amount, 5)

    def get_skills(self):
        return {NSFW_SKILLS[k]: v for k, v in self.skills.items() if v > 0}
