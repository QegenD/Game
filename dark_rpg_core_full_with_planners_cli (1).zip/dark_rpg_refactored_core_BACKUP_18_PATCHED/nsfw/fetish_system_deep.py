
# fetish_system_deep.py — продвинутые фетиши и их влияние на сцены

import random

FETISH_POOL = [
    "vanilla", "domination", "submission", "public", "ritual",
    "lingerie", "voice", "hands", "restraints", "nonverbal"
]

def assign_fetishes(npc):
    npc["fetish"] = random.choice(FETISH_POOL)
    if random.random() < 0.2:
        npc["secondary_fetish"] = random.choice([f for f in FETISH_POOL if f != npc["fetish"]])

def compatibility(player, npc):
    match = npc.get("fetish") == player.get("fetish")
    secondary = npc.get("secondary_fetish") == player.get("fetish")
    return match or secondary
