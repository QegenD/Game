
from nsfw.visual_identity_cache import get_or_create_visual_identity

PHASES = ["prelude", "foreplay", "main_act", "climax", "afterglow"]

def generate_nsfw_scene_phase(npc, player, context, phase):
    fetish = npc.get("fetish", "vanilla")
    place = context.get("place", "комната")
    time = context.get("time", "ночь")
    mood = npc.get("mood", "neutral")
    dominance = player.get("dominance", 0)
    intensity = npc.get("desire", 5) + dominance

    visuals = {
        "prelude": "взгляды, прикосновения, напряжение",
        "foreplay": "игривость, обнажение, ласки",
        "main_act": "союз тел, страсть, ритм",
        "climax": "экстаз, эмоции, крик",
        "afterglow": "объятия, усталость, тепло"
    }

    scene_type = visuals.get(phase, "интимность")

    npc_desc = get_or_create_visual_identity(npc)
    player_desc = get_or_create_visual_identity(player)

    prompt = (
        f"{scene_type}, {fetish}, {place}, {time}. "
        f"NPC: {npc_desc}. Player: {player_desc}."
    )

    return {
        "description": f"{scene_type.capitalize()} ({phase}). Место: {place}, Время: {time}, Фетиш: {fetish}, Настроение: {mood}",
        "image_prompt": prompt,
        "intensity": intensity,
        "phase": phase
    }


from nsfw.nsfw_attire_system import get_nsfw_outfit_prompt, calculate_reaction_bonus

def generate_nsfw_scene_phase(npc, player, context, phase):
    base = generate_nsfw_scene_phase.__wrapped__(npc, player, context, phase) if hasattr(generate_nsfw_scene_phase, '__wrapped__') else {}
    npc_gear = npc.get("gear", [])
    player_gear = player.get("gear", [])

    attire_prompt_npc = get_nsfw_outfit_prompt(npc_gear)
    attire_prompt_player = get_nsfw_outfit_prompt(player_gear)

    attire_bonus = calculate_reaction_bonus(npc_gear) + calculate_reaction_bonus(player_gear)
    base["description"] += f" Одежда NPC: {attire_prompt_npc}. Одежда игрока: {attire_prompt_player}."
    base["image_prompt"] += f" NPC wears: {attire_prompt_npc}. Player wears: {attire_prompt_player}."
    base["intensity"] += attire_bonus

    base['memory_prompt'] = scene_memory.build_next_phase_prompt(npc, player)
    base['npc_line'] = get_nsfw_line(mood)
    if mood in ['tender', 'devoted']:
        base['npc_line'] += ' ' + get_romantic_line()
    scene_memory.remember(base)
    base['image_prompt'] += f" Aftermath: {get_aftermath_prompt(npc, player, scene_memory.history)}."
    return base


from nsfw.nsfw_behavior_engine import choose_position, choose_initiative
from nsfw.visual_mood_engine import get_visual_mood_prompt
from nsfw.nsfw_emotion_shift_engine import evolve_emotion
from nsfw.nsfw_memory_engine import NSFWMemory
from nsfw.nsfw_aftermath_engine import get_aftermath_prompt
from nsfw.nsfw_dialogue_engine import get_nsfw_line
from nsfw.romance_engine import get_romantic_line
scene_memory = NSFWMemory()

def generate_nsfw_scene_phase(npc, player, context, phase):
    base = generate_nsfw_scene_phase.__wrapped__(npc, player, context, phase) if hasattr(generate_nsfw_scene_phase, '__wrapped__') else {}
    position = choose_position(npc)
    initiative = choose_initiative(npc, player)

    base["description"] += f" Поза: {position}, инициатива: {initiative}."
    base["image_prompt"] += f" Position: {position}. Initiative: {initiative}."
    
    # Эволюция эмоций
    mood = evolve_emotion(mood)

    mood_visual = get_visual_mood_prompt(mood)
    base["image_prompt"] += f" Emotion: {mood_visual}."

    base['memory_prompt'] = scene_memory.build_next_phase_prompt(npc, player)
    base['npc_line'] = get_nsfw_line(mood)
    if mood in ['tender', 'devoted']:
        base['npc_line'] += ' ' + get_romantic_line()
    scene_memory.remember(base)
    base['image_prompt'] += f" Aftermath: {get_aftermath_prompt(npc, player, scene_memory.history)}."
    return base
