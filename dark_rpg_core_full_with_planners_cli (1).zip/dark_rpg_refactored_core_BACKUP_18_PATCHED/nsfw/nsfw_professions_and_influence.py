
# nsfw_professions_and_influence.py — порочные профессии, экономическое влияние

import random

NSFW_PROFESSIONS = [
    "куртизанка", "раб страсти", "артист эротики", "ритуальный проводник", "модель запретного искусства"
]

def assign_nsfw_profession(npc):
    if random.random() < 0.2:
        npc["nsfw_profession"] = random.choice(NSFW_PROFESSIONS)
        npc["reputation"] = npc.get("reputation", 0) - 1

def calculate_economy_impact(world):
    total = sum(1 for npc in world["npcs"] if npc.get("nsfw_profession"))
    world["economy"]["nsfw_sector"] = total * 100
    return total
