
# ritual_image_generator.py — генерация изображений для NSFW-ритуалов

def generate_ritual_image(ritual_name, participants, intensity="medium"):
    prompt = f"NSFW ritual scene: {ritual_name}, involving {len(participants)} participants, "
    prompt += f"emotion: {' + '.join([p.get('mood', 'neutral') for p in participants])}, "
    prompt += f"styles: {'mystical, sensual, dark' if intensity == 'high' else 'mystical, dim'}, "
    prompt += f"details: {'nude bodies, glowing runes, magical aura' if intensity == 'high' else 'silhouettes, shadows, ritual symbols'}."
    return prompt
