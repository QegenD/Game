
# nsfw_rituals.py — эротические ритуалы, жертвы страсти, магия единения душ

import random

RITUALS = [
    {"name": "Обряд страсти", "effect": "усиление связи между NPC", "nsfw": True},
    {"name": "Слияние душ", "effect": "обмен чувствами и знаниями", "nsfw": True},
    {"name": "Жертва оргазма", "effect": "призывает духа желания", "nsfw": True},
    {"name": "Темный поцелуй", "effect": "создаёт узы подчинения", "nsfw": True},
]

def perform_nsfw_ritual(participants):
    ritual = random.choice(RITUALS)
    for npc in participants:
        npc["status"] = "marked_by_ritual"
        npc["ritual_effect"] = ritual["effect"]
    from nsfw.rituals.ritual_image_generator import generate_ritual_image\n        img_prompt = generate_ritual_image(ritual['name'], participants, intensity='high')\n        from nsfw.memories.nsfw_memories import create_nsfw_memory\n        scene = f"🔮 {ritual['name']} совершен. Эффект: {ritual['effect']}.\n🖼️ Prompt: {img_prompt}"\n        create_nsfw_memory(scene_type='ritual', description=scene, image_prompt=img_prompt, participants=participants)
    return scene
