
# nsfw_art_culture.py — эротическое искусство, выставки, влияние на культуру

import random

def create_erotic_exhibition(world):
    cities = [l["name"] for l in world.get("locations", []) if l["type"] == "city"]
    if not cities:
        return None

    city = random.choice(cities)
    theme = random.choice([
        "Пороки власти", "Свет и похоть", "Тени и рабство", "Соблазн богов", "Искусство тел"
    ])

    event = {
        "city": city,
        "theme": theme,
        "prestige": random.randint(1, 5),
        "nsfw_impact": True
    }

    world.setdefault("nsfw_exhibitions", []).append(event)
    return event
