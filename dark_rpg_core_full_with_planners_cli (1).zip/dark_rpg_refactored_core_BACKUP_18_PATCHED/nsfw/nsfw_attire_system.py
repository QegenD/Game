
# nsfw_attire_system.py — влияние одежды на сцены и поведение

NSFW_WARDROBE = {
    "black_silk_corset": {
        "nsfw_tag": "lingerie",
        "reaction_bonus": 2,
        "description": "чёрный шёлковый корсет с кружевами"
    },
    "chains_of_submission": {
        "nsfw_tag": "bondage",
        "reaction_bonus": 3,
        "description": "цепи покорности, блестящие и тяжелые"
    },
    "holy_veil": {
        "nsfw_tag": "religious",
        "reaction_bonus": 1,
        "description": "полупрозрачная вуаль с вышивкой храма"
    },
    "latex_suit": {
        "nsfw_tag": "latex",
        "reaction_bonus": 4,
        "description": "облегающий латексный костюм"
    }
}

def get_nsfw_outfit_prompt(gear):
    prompt_parts = []
    for item in gear:
        if item in NSFW_WARDROBE:
            desc = NSFW_WARDROBE[item]["description"]
            tag = NSFW_WARDROBE[item]["nsfw_tag"]
            prompt_parts.append(f"{desc} ({tag})")
    return ", ".join(prompt_parts) if prompt_parts else "обычная одежда"

def calculate_reaction_bonus(gear):
    return sum(NSFW_WARDROBE.get(item, {}).get("reaction_bonus", 0) for item in gear)
