
# prophecies.py
import random
from datetime import datetime

PROPHECY_TEMPLATES = [
    "Когда ${event}, падёт ${faction}.",
    "${npc} встретит свою судьбу в ${location}.",
    "В год ${year} произойдёт великое предательство.",
    "Тот, кто носит ${item}, вызовет ${disaster}.",
]

def generate_prophecy(world_state):
    template = random.choice(PROPHECY_TEMPLATES)
    filled = template.replace("${event}", "луна окрасится в красный")
    filled = filled.replace("${faction}", "Орден Теней")
    filled = filled.replace("${npc}", "Безликий")
    filled = filled.replace("${location}", "Ржавый Маяк")
    filled = filled.replace("${year}", str(datetime.now().year + random.randint(1, 5)))
    filled = filled.replace("${item}", "кольцо из костей")
    filled = filled.replace("${disaster}", "вторжение извне")
    return filled

def attach_prophecy_to_world(world):
    prophecy = generate_prophecy(world)
    world["prophecies"].append(prophecy)
    return prophecy
