import json
from datetime import datetime
from config import event_log_path

def log_event(event_type, participants, description, consequences=None):
    entry = {
        "time": datetime.utcnow().isoformat(),
        "type": event_type,
        "participants": participants,
        "description": description,
        "consequences": consequences or {}
    }
    try:
        with open(event_log_path, 'r') as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = []
    data.append(entry)
    with open(event_log_path, 'w') as f:
        json.dump(data, f, indent=2)