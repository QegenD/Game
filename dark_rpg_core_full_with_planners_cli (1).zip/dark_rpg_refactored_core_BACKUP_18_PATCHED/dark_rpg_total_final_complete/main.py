import os
from character_creation_gui import run_gui

if not os.path.exists("player_data.json"):
    run_gui()

from core.npc_faction_dynamics import NPCFactionManager
from core.world_crisis_manager import WorldCrisisManager
from core.rumor_system import RumorSystem
from game_loop import game_loop

# Новые модули
from world_master import run_world_director_tick
from prophecies import generate_prophecy
from social_network import connections
from config import update_interval_seconds

# Инициализация систем
faction_manager = NPCFactionManager()
crisis_manager = WorldCrisisManager()
rumor_system = RumorSystem()

if __name__ == "__main__":
    game_loop(faction_manager, crisis_manager, rumor_system,
              run_world_director_tick, generate_prophecy, connections,
              update_interval_seconds)