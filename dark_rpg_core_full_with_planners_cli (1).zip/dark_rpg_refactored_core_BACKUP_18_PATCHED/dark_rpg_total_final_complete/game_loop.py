import time
import random
from world_log import log_event

def game_loop(faction_manager, crisis_manager, rumor_system,
              run_world_director_tick, generate_prophecy, connections,
              update_interval_seconds):
    tick = 0
    factions = list(faction_manager.factions)

    while tick < 5:  # демо-цикл из 5 шагов
        print(f"\n[ИГРОВОЙ ЦИКЛ] Шаг: {tick + 1}")
        time.sleep(1)  # имитация времени

        # Генерация NPC и назначение фракции
        npc = f"NPC_{random.randint(100, 999)}"
        faction = random.choice(factions)
        faction_manager.assign_npc(npc, faction)
        print(f"{npc} присоединяется к фракции {faction}")
        log_event("join_faction", [npc, faction], f"{npc} присоединился к {faction}")

        # Обработка кризисов
        result = crisis_manager.evaluate_crisis(npc, alert_level=5, recent_events=['магическая буря'])
        print(result)
        log_event("crisis_check", [npc], result)

        # Добавим слух
        rumor = rumor_system.generate_rumor(npc)
        print(f"Слух: {rumor}")
        log_event("rumor", [npc], rumor)

        # Каждые 2 тика — дирижёр мира
        if tick % 2 == 0:
            print("[AI-ДИРИЖЁР] Управление миром...")
            run_world_director_tick(factions)

        # Каждые 3 тика — пророчество
        if tick % 3 == 0:
            prophecy = generate_prophecy(npc)
            print(f"[ПРОРОЧЕСТВО] {prophecy}")

        # Обновим социальную сеть (рандомная дружба)
        if random.random() < 0.5:
            target = f"NPC_{random.randint(100, 999)}"
            connections[npc]['friends'].append(target)
            print(f"{npc} подружился с {target}")
            log_event("relationship_update", [npc, target], f"{npc} подружился с {target}")

        tick += 1