NSFW_GALLERY = []

def save_nsfw_scene(scene_text, image_path, npc_name=None):
    entry = {
        "npc": npc_name or "Неизвестно",
        "text": scene_text,
        "image": image_path
    }
    NSFW_GALLERY.append(entry)

def get_gallery():
    return NSFW_GALLERY
