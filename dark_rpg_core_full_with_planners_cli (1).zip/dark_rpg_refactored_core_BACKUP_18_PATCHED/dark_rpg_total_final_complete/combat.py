import random
from world_state import WORLD_STATE

def calculate_combat_modifiers():
    weather = WORLD_STATE["weather"]
    time_of_day = WORLD_STATE["time_of_day"]
    mods = {"player_defense": 0, "enemy_attack": 0}

    # Влияние погоды
    if weather == "туман":
        mods["enemy_attack"] -= 1
    elif weather == "гроза":
        mods["enemy_attack"] += 2
    elif weather == "дождь":
        mods["player_defense"] += 1
    elif weather == "ветер":
        mods["player_defense"] -= 1

    # Влияние времени
    if time_of_day == "ночь":
        mods["enemy_attack"] += 1
    elif time_of_day == "утро":
        mods["player_defense"] += 1

    return mods

def simulate_combat(player_stats, enemy_stats):
    mods = calculate_combat_modifiers()
    player_def = player_stats["defense"] + mods["player_defense"]
    enemy_atk = enemy_stats["attack"] + mods["enemy_attack"]

    log = []
    while player_stats["hp"] > 0 and enemy_stats["hp"] > 0:
        enemy_hit = random.randint(0, enemy_atk)
        player_stats["hp"] -= max(0, enemy_hit - player_def)
        log.append(f"Враг атакует на {enemy_hit}, вы теряете {max(0, enemy_hit - player_def)} хп.")

        player_hit = random.randint(0, player_stats["attack"])
        enemy_stats["hp"] -= max(0, player_hit - enemy_stats["defense"])
        log.append(f"Вы бьёте на {player_hit}, враг теряет {max(0, player_hit - enemy_stats['defense'])} хп.")

    result = "Победа" if player_stats["hp"] > 0 else "Поражение"
    log.append(f"Исход боя: {result}")
    return log, result



# --- Psychological Battle System ---
def apply_battle_emotion(npc, emotion_type, amount):
    if emotion_type == "страх":
        npc.fear += amount
    elif emotion_type == "стыд":
        npc.shame += amount
    elif emotion_type == "возбуждение":
        npc.arousal += amount

    if npc.fear > 80:
        npc.flee()
    if npc.shame > 60:
        npc.skip_turn()
    if npc.arousal > 90:
        npc.lower_defense()
