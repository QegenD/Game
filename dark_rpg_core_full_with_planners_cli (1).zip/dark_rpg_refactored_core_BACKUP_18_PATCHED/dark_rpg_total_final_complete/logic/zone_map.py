
# logic/zone_map.py

import random

class Zone:
    def __init__(self, name, danger, corruption):
        self.name = name
        self.danger = danger
        self.corruption = corruption

    def describe(self):
        return {
            "локация": self.name,
            "опасность": self.danger,
            "порча": self.corruption
        }

class ZoneMap:
    def __init__(self):
        self.zones = [
            Zone("Руины Ар-Таир", danger=7, corruption=9),
            Zone("Окрестности храма Солнца", danger=3, corruption=1),
            Zone("Тайный квартал Гильдии", danger=5, corruption=6),
            Zone("Болотистая чаща", danger=6, corruption=8)
        ]
        self.current_zone = random.choice(self.zones)

    def travel_to(self, zone_name):
        for zone in self.zones:
            if zone.name == zone_name:
                self.current_zone = zone
                return True
        return False

    def get_current_zone(self):
        return self.current_zone.describe()

    def get_all_zones(self):
        return [zone.describe() for zone in self.zones]
