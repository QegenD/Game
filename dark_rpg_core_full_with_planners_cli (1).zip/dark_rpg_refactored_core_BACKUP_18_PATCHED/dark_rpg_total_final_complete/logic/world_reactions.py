
# logic/world_reactions.py

import random

class WorldReactions:
    def __init__(self, npcs):
        self.npcs = npcs

    def react_to_event(self, event_text):
        affected_npcs = []
        if "вспыхнуло восстание" in event_text:
            for npc in self.npcs:
                if npc["kingdom"] and npc["role"] in ["гражданин", "раб"]:
                    npc["attitude"] = "бунтарь"
                    affected_npcs.append(npc["name"])
        elif "магическая буря" in event_text:
            for npc in self.npcs:
                if npc["role"] == "жрец" or npc["role"] == "маг":
                    npc["fear"] = True
                    affected_npcs.append(npc["name"])
        elif "налёт" in event_text:
            for npc in self.npcs:
                if npc["clan"] is None and npc["role"] not in ["рыцарь", "жрец"]:
                    npc["status"] = "покинул деревню"
                    affected_npcs.append(npc["name"])
        elif "ересь" in event_text:
            for npc in self.npcs:
                if npc["role"] == "жрец":
                    npc["loyalty"] = "радикал" if random.random() < 0.5 else "еретик"
                    affected_npcs.append(npc["name"])
        return affected_npcs
