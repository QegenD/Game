
# logic/player_roles.py

import random

class PlayerPaths:
    def __init__(self, conspiracies):
        self.conspiracies = conspiracies
        self.player_alignment = None
        self.history = []

    def choose_path(self, path):
        self.player_alignment = path
        self.history.append(f"Игрок выбрал путь: {path}")

    def interact_with_conspiracies(self):
        log = []
        for conspiracy in self.conspiracies:
            if conspiracy["status"] != "тайно":
                continue

            roll = random.random()
            if self.player_alignment == "шпион" and roll < 0.6:
                conspiracy["status"] = "раскрыто"
                log.append(f"Вы раскрыли заговор: {conspiracy['plan']} против {conspiracy['target']}")
            elif self.player_alignment == "заговорщик" and roll < 0.7:
                conspiracy["status"] = "успешно"
                log.append(f"Вы помогли реализовать заговор: {conspiracy['plan']} против {conspiracy['target']}")
            elif self.player_alignment == "детектив" and roll < 0.5:
                conspiracy["status"] = "раскрыто"
                log.append(f"Вы нашли улики против зачинщика: {conspiracy['initiator']}")
        return log
