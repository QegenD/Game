
# logic/survival_status.py

class SurvivalStatus:
    def __init__(self):
        self.hunger = 0
        self.thirst = 0
        self.fatigue = 0

    def tick(self):
        self.hunger += 1
        self.thirst += 1
        self.fatigue += 1

    def rest(self):
        self.fatigue = max(0, self.fatigue - 5)

    def eat(self):
        self.hunger = max(0, self.hunger - 5)

    def drink(self):
        self.thirst = max(0, self.thirst - 5)

    def get_status(self):
        return {
            "голод": self.hunger,
            "жажда": self.thirst,
            "усталость": self.fatigue
        }

    def is_in_danger(self):
        return self.hunger > 10 or self.thirst > 10 or self.fatigue > 15
