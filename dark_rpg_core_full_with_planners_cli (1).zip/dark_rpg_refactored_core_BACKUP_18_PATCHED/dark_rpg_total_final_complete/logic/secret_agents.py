
# secret_agents.py
import random

class SecretAgent:
    def __init__(self, npc_id):
        self.is_agent = random.random() < 0.2  # 20% шанс
        self.works_for = random.choice(["Культ", "Церковь", "Никто"]) if self.is_agent else "Никто"

    def reveal(self):
        return {"агент": self.is_agent, "фракция": self.works_for}
