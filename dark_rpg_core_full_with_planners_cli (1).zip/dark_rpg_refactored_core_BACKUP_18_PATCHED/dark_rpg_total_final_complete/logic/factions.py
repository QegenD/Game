
# logic/factions.py

import random

class Faction:
    def __init__(self, name, faction_type):
        self.name = name
        self.faction_type = faction_type
        self.influence = random.randint(10, 100)
        self.region = random.choice(["Север", "Юг", "Восток", "Запад", "Центр"])
        self.public_face = random.choice([True, False])
        self.purpose = random.choice([
            "захватить власть", "защитить народ", "поддерживать баланс", 
            "уничтожить магов", "развивать технологии", "контролировать торговлю"
        ])

    def get_summary(self):
        return {
            "name": self.name,
            "type": self.faction_type,
            "region": self.region,
            "public": self.public_face,
            "purpose": self.purpose,
            "influence": self.influence
        }

class WorldFactions:
    def __init__(self):
        self.factions = self.generate_factions()

    def generate_factions(self):
        names = ["Орден Тени", "Кровавое Перо", "Звезда Рассвета", "Ковен Слёз", "Легион Истинных"]
        types = ["клан", "магическая школа", "королевство", "наёмники", "религиозная секта"]
        return [Faction(random.choice(names), random.choice(types)) for _ in range(10)]

    def get_random_faction(self):
        return random.choice(self.factions).get_summary()

    def list_all(self):
        return [f.get_summary() for f in self.factions]



class FactionRelation:
    def __init__(self, faction_a, faction_b):
        self.faction_a = faction_a
        self.faction_b = faction_b
        self.relation = random.choice(["союз", "нейтралитет", "вражда", "подозрение"])

    def get_summary(self):
        return {
            "между": f"{self.faction_a.name} и {self.faction_b.name}",
            "отношение": self.relation
        }

class FactionConflictChronicle:
    def __init__(self):
        self.log = []

    def record(self, event):
        self.log.append(event)

    def latest_events(self, limit=10):
        return self.log[-limit:]

class WorldFactions:
    def __init__(self):
        self.factions = self.generate_factions()
        self.conflicts = FactionConflictChronicle()
        self.relations = self.generate_relations()

    def generate_factions(self):
        names = ["Орден Тени", "Кровавое Перо", "Звезда Рассвета", "Ковен Слёз", "Легион Истинных"]
        types = ["клан", "магическая школа", "королевство", "наёмники", "религиозная секта"]
        return [Faction(random.choice(names), random.choice(types)) for _ in range(10)]

    def generate_relations(self):
        rels = []
        for i in range(len(self.factions)):
            for j in range(i + 1, len(self.factions)):
                r = FactionRelation(self.factions[i], self.factions[j])
                rels.append(r)
                if r.relation == "вражда":
                    self.conflicts.record(f"{r.faction_a.name} вступил в конфликт с {r.faction_b.name}")
        return rels

    def get_conflicts(self):
        return self.conflicts.latest_events()

    def get_diplomatic_relations(self):
        return [r.get_summary() for r in self.relations]
