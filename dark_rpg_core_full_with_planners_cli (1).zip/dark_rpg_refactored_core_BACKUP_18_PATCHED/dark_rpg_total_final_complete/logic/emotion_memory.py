
# logic/emotion_memory.py

class EmotionMemory:
    def __init__(self):
        self.memory = {}

    def record(self, player_action, impact):
        self.memory[player_action] = self.memory.get(player_action, 0) + impact

    def recall(self):
        return sorted(self.memory.items(), key=lambda x: -abs(x[1]))

    def get_attitude(self):
        score = sum(self.memory.values())
        if score > 10:
            return "доверие"
        elif score < -10:
            return "враждебность"
        else:
            return "нейтральность"
