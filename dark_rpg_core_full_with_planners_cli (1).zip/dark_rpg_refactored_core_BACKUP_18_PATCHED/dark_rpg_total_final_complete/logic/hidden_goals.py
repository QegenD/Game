
# hidden_goals.py
import random

class NPCHiddenGoal:
    def __init__(self, npc_id):
        self.goal = random.choice(["месть", "соблазнение", "власть", "смерть игрока", "союз с культом", "шпионаж"])
        self.priority = random.randint(1, 100)  # важность цели

    def get_goal(self):
        return self.goal

    def get_priority(self):
        return self.priority
