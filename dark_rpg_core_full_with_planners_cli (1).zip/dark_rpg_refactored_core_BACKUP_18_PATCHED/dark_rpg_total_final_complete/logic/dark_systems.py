
# logic/dark_systems.py

import random

class RitualSystem:
    def perform_tribal_ritual(self, tribe_name):
        effects = [
            "усиление физической мощи", 
            "призыв духов-хранителей", 
            "жертвоприношение для богов"
        ]
        return f"Племя {tribe_name} провело ритуал: {random.choice(effects)}"

class InfectionSystem:
    def spread_disease(self, npc_name, origin_city):
        diseases = ["Костяная горячка", "Сонная хворь", "Сердечный гниль"]
        return {
            "npc": npc_name,
            "болезнь": random.choice(diseases),
            "откуда": origin_city
        }

class ImmortalityCult:
    def seek_immortality(self, npc_name):
        method = random.choice([
            "через кровавое жертвоприношение", 
            "путём переселения души", 
            "поглощая магию артефакта"
        ])
        return f"{npc_name} ищет бессмертие: {method}"

class BloodArena:
    def gladiator_fight(self, npc1, npc2):
        winner = random.choice([npc1, npc2])
        return {
            "арена": "Кровавая яма",
            "бойцы": [npc1, npc2],
            "победитель": winner
        }
