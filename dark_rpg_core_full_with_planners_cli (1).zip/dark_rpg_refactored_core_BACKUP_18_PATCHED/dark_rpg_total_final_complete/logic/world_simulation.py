
# logic/world_simulation.py

import random

class WorldSimulation:
    def __init__(self, clans, kingdoms):
        self.clans = clans
        self.kingdoms = kingdoms
        self.global_events = []
        self.year = 1000

    def tick(self):
        self.year += 1
        event = self.generate_event()
        if event:
            self.global_events.append((self.year, event))
        return event

    def generate_event(self):
        roll = random.random()
        if roll < 0.2:
            clan = random.choice(self.clans).name
            return f"Клан {clan} совершил налёт на торговый путь."
        elif roll < 0.4:
            kingdom = random.choice(self.kingdoms)
            return f"В {kingdom} вспыхнуло восстание против знати."
        elif roll < 0.6:
            return f"Магическая буря разрушила деревню у границ Империи."
        elif roll < 0.75:
            return "Церковь провозгласила ересь в новых школах магии."
        elif roll < 0.85:
            return "Торговая гильдия устроила ярмарку знаний и артефактов."
        else:
            return None  # не каждый год должно быть событие

    def get_recent_events(self, n=10):
        return self.global_events[-n:]
