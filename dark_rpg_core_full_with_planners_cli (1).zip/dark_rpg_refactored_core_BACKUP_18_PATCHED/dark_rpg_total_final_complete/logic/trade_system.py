
# logic/trade_system.py

import random

class TradeSystem:
    def __init__(self):
        self.base_prices = {
            "еда": 10,
            "вода": 5,
            "зелье": 25,
            "артефакт": 100
        }
        self.town_factors = {}

    def update_town_factors(self, town_name, anomaly, npc_attitude):
        multiplier = 1.0

        if anomaly and anomaly != "отсутствует":
            multiplier += 0.5  # Магия нарушает поставки

        if npc_attitude == "дружественный":
            multiplier -= 0.2
        elif npc_attitude == "враждебный":
            multiplier += 0.3

        self.town_factors[town_name] = multiplier

    def get_prices_for_town(self, town_name):
        factor = self.town_factors.get(town_name, 1.0)
        return {item: int(price * factor) for item, price in self.base_prices.items()}
