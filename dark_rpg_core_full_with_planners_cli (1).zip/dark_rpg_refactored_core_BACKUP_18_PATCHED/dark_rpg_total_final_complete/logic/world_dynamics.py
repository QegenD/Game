
# logic/world_dynamics.py

import random

class HistoricalEraManager:
    def __init__(self):
        self.eras = ["Эпоха Пламени", "Золотой Век", "Тьма Возмездия", "Эра Пепла"]
        self.current_era = random.choice(self.eras)

    def cycle_era(self):
        self.current_era = random.choice(self.eras)
        return f"Мир вступает в новую эпоху: {self.current_era}"

class DynastySystem:
    def create_dynasty(self, founder):
        surname = founder + random.choice(["ар", "вен", "тар", "дис", "мон"])
        return f"Создан новый дом: династия {surname}"

    def inherit_title(self, parent, child):
        return f"{child} унаследовал титул от {parent}"

class EmotionalAttachment:
    def emotional_state(self, npc):
        states = ["ненависть", "любовь", "дружба", "страх", "восхищение"]
        return f"{npc} испытывает чувство: {random.choice(states)}"

class GhostSystem:
    def return_as_ghost(self, npc_name):
        reason = random.choice([
            "из-за нерешённой мести", 
            "из-за разрушенного культа", 
            "в поисках наследника"
        ])
        return f"Дух {npc_name} возвращается в мир живых: {reason}"
