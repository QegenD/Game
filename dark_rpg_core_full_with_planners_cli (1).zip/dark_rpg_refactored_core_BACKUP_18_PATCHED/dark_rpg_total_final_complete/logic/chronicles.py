
# logic/chronicles.py

class Chronicle:
    def __init__(self):
        self.events = []

    def record_event(self, description, year):
        self.events.append(f"{year} год: {description}")

    def get_timeline(self):
        return self.events[-15:]  # последние события
