
# world_reaction.py

class WorldReaction:
    def __init__(self):
        self.reputation = 50  # нейтрально
        self.karma = 0

    def apply_action(self, action):
        if action == "спасение":
            self.reputation += 10
            self.karma += 5
        elif action == "предательство":
            self.reputation -= 15
            self.karma -= 10
        elif action == "насилие":
            self.reputation -= 5
            self.karma -= 15
        elif action == "пожертвование":
            self.reputation += 5
            self.karma += 10
        elif action == "соблазнение":
            self.karma += 3
        elif action == "магия_порчи":
            self.karma -= 20
        else:
            self.karma += 0

        self.reputation = max(0, min(100, self.reputation))
        self.karma = max(-100, min(100, self.karma))

    def get_state(self):
        return {
            "репутация": self.reputation,
            "карма": self.karma
        }
