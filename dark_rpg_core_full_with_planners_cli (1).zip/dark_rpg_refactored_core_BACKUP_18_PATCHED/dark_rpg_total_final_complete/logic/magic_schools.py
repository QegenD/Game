
# logic/magic_schools.py

import random

class MagicSchool:
    def __init__(self, name, element):
        self.name = name
        self.element = element
        self.rivalries = []

    def form_rivalry(self, target_school):
        self.rivalries.append(target_school)
        return f"Магическая школа {self.name} вступила в соперничество с {target_school.name}!"

class MagicParliament:
    def __init__(self):
        self.schools = [
            MagicSchool("Аркана Пламени", "Огонь"),
            MagicSchool("Ледяной Круг", "Лёд"),
            MagicSchool("Орден Гниения", "Тьма"),
            MagicSchool("Ветра Духа", "Воздух"),
        ]

    def conflict(self):
        s1, s2 = random.sample(self.schools, 2)
        return s1.form_rivalry(s2)

    def get_schools(self):
        return [s.name for s in self.schools]
