
# logic/religions.py

import random

class Religion:
    def __init__(self, name, god_type, belief_system):
        self.name = name
        self.god_type = god_type
        self.belief_system = belief_system
        self.followers = random.randint(200, 5000)
        self.conflicts = []

    def generate_conflict(self, target):
        conflict = f"Конфликт между {self.name} и {target}"
        self.conflicts.append(conflict)
        return conflict

class ReligionSystem:
    def __init__(self):
        self.religions = [
            Religion("Культ Пламени", "разрушение", "жертвоприношения"),
            Religion("Свет Вечной Луны", "исцеление", "прощение"),
            Religion("Ткачи Судеб", "судьба", "предопределение")
        ]

    def get_religions(self):
        return [r.name for r in self.religions]

    def simulate_religious_conflict(self):
        r1, r2 = random.sample(self.religions, 2)
        return r1.generate_conflict(r2.name)
