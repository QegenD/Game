
# logic/world_time.py

import random

class WorldCalendar:
    def __init__(self):
        self.year = 1432
        self.month = "Листопад"
        self.era = "Эпоха Пепла"
        self.season = "Осень"

    def advance_time(self):
        # Простейшее продвижение времени
        self.year += 1
        self.month = random.choice(["Листопад", "Морозень", "Цветень", "Знойник", "Грозень", "Песчарь"])
        self.era = random.choice(["Эпоха Пепла", "Век Лотоса", "Золотая Эра", "Сумрачный Век"])
        self.season = random.choice(["Зима", "Весна", "Лето", "Осень"])

    def get_current_time(self):
        return {
            "год": self.year,
            "месяц": self.month,
            "эпоха": self.era,
            "сезон": self.season
        }

class SpyNetwork:
    def __init__(self):
        self.agents = []

    def generate_agents(self, factions):
        self.agents = []
        for f in factions:
            if random.random() < 0.4:
                self.agents.append({
                    "фракция": f.name,
                    "миссия": random.choice(["подрыв", "шпионаж", "переманивание", "саботаж"]),
                    "маскировка": random.choice(["дворянин", "торговец", "жрица", "наёмник"])
                })

    def list_agents(self):
        return self.agents
