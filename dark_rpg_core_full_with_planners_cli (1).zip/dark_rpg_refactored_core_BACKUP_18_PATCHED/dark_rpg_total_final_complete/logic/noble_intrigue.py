
import random

class NobleIntrigueSystem:
    kingdoms = ["Королевство Ветра", "Королевство Песка", "Северный Трон", "Золотая Корона"]

    def plan_coup(self, noble_npcs):
        plotters = random.sample(noble_npcs, k=min(2, len(noble_npcs)))
        target = random.choice([npc for npc in noble_npcs if npc not in plotters])
        if random.random() < 0.4:
            return {
                "type": "дворцовый переворот",
                "plotters": [p["name"] for p in plotters],
                "target": target["name"],
                "success": random.random() < 0.6
            }
        return None

    def arrange_assassination(self, target_npc):
        if random.random() < 0.3:
            return {
                "type": "политическое убийство",
                "target": target_npc["name"],
                "weapon": random.choice(["яд", "кинжал", "магия"]),
                "discovered": random.random() < 0.4
            }
        return None

    def assign_knightly_order(self, npc):
        orders = [
            {
                "name": "Орден Света",
                "rank": ["Новичок", "Рыцарь", "Капитан"],
                "code": "Честь, Свет, Долг",
                "divisions": ["Инквизиция", "Храмовые стражи"],
                "kingdom": "Королевство Ветра"
            },
            {
                "name": "Теневой Орден",
                "rank": ["Шпион", "Убийца", "Мастер Теней"],
                "code": "Тень, Молчание, Лояльность",
                "divisions": ["Разведчики", "Смотрящие"],
                "kingdom": "Северный Трон"
            },
            {
                "name": "Орден Звёзд",
                "rank": ["Ученик", "Магистр", "Архонт"],
                "code": "Истина, Магия, Мудрость",
                "divisions": ["Часовые магии", "Хранители хроник"],
                "kingdom": "Золотая Корона"
            }
        ]
        order = random.choice(orders)
        npc["knightly_order"] = {
            "name": order["name"],
            "rank": random.choice(order["rank"]),
            "division": random.choice(order["divisions"]),
            "oath": order["code"],
            "kingdom": order["kingdom"],
            "betrayal": random.random() < 0.1
        }
        return npc

    def assign_court_position(self, npc):
        npc["council_role"] = random.choice([
            "советник по магии", "мастер шпионов", "казначей", "военный стратег", "посол"
        ])
        return npc

    def generate_knightly_conflict(self):
        factions = ["Орден Света", "Теневой Орден", "Орден Звёзд"]
        attacker, defender = random.sample(factions, 2)
        return {
            "type": "конфликт орденов",
            "attacker": attacker,
            "defender": defender,
            "cause": random.choice(["оскорбление", "спор о территории", "идеологические разногласия"]),
            "active": random.random() < 0.7
        }

    def generate_order_vs_bandits_conflict(self):
        orders = ["Орден Света", "Теневой Орден", "Орден Звёзд"]
        return {
            "type": "операция против бандитов",
            "order": random.choice(orders),
            "target": random.choice(["бандитский лагерь", "контрабандисты", "теневой рынок"]),
            "outcome": random.choice(["успех", "провал", "частичная зачистка"]),
            "casualties": random.randint(0, 12)
        }

    def organize_tournament(self):
        locations = ["Арена Света", "Тёмные Пески", "Вечный Круг"]
        disciplines = ["меч", "магия", "ловкость", "стратегия"]
        return {
            "type": "турнир",
            "location": random.choice(locations),
            "disciplines": random.sample(disciplines, k=2),
            "participants": random.randint(6, 16),
            "prize": random.choice(["золотой меч", "магическая печать", "титул чемпиона"])
        }

    def get_order_influence(self, city_name):
        return {
            "city": city_name,
            "influence": {
                "Орден Света": random.randint(10, 80),
                "Теневой Орден": random.randint(5, 60),
                "Орден Звёзд": random.randint(15, 70)
            }
        }

    def check_order_betrayal(self, player_reputation):
        if player_reputation < -20 and random.random() < 0.3:
            return {
                "event": "предательство ордена",
                "consequence": random.choice([
                    "атака на игрока", "исключение из ордена", "розыск за измену"
                ])
            }
        return None


    def trigger_rebellion(self, city_name):
        reasons = ["налоги", "тирания", "голод", "религиозные притеснения"]
        return {
            "city": city_name,
            "reason": random.choice(reasons),
            "factions_involved": random.sample(["крестьяне", "беженцы", "диссиденты", "наёмники"], k=2),
            "success": random.random() < 0.5
        }

    def player_becomes_order_leader(self, npc):
        if npc.get("knightly_order") and random.random() < 0.2:
            npc["knightly_order"]["rank"] = "Гроссмейстер"
            npc["knightly_order"]["founder"] = False
            return {
                "event": "возглавил орден",
                "order": npc["knightly_order"]["name"]
            }
        return None

    def player_founds_new_order(self, npc):
        new_order = {
            "name": f"Новый Орден {random.choice(['Тени', 'Пламени', 'Штормов'])}",
            "rank": "Основатель",
            "division": "Главный круг",
            "oath": random.choice(["Честь и Независимость", "Сила и Тайна"]),
            "kingdom": random.choice(self.kingdoms),
            "founder": True
        }
        npc["knightly_order"] = new_order
        return {
            "event": "основан новый орден",
            "details": new_order
        }

    def discover_order_lore(self, order_name):
        secrets = [
            "проводил ритуалы с демонами",
            "был создан для защиты древнего артефакта",
            "был замешан в исчезновении короля",
            "на самом деле управляется магами из Академии"
        ]
        return {
            "order": order_name,
            "secret_lore": random.choice(secrets),
            "reveal_cost": random.choice(["пожертвование", "допрос мага", "взлом летописей"])
        }


    def magic_order_conflict(self):
        cause = random.choice([
            "запрет на магию в королевстве",
            "публичная казнь мага орденом",
            "раскрытие заговора мага внутри ордена",
            "разрушенный магами форт ордена"
        ])
        return {
            "magic_school": random.choice(self.magic_schools),
            "knightly_order": random.choice([o["name"] for o in self.knightly_orders]),
            "cause": cause,
            "escalation": random.choice(["открытая война", "теневой конфликт", "дипломатический кризис"]),
            "impact": random.choice(["потеря влияния", "закрытие школы", "запрет ордена"])
        }

    def transfer_city_power(self, city_name):
        new_ruler = random.choice(["маг-аристократ", "военный совет", "орденский губернатор", "избранный народом"])
        return {
            "city": city_name,
            "new_ruler": new_ruler,
            "method": random.choice(["переворот", "мятеж", "реформы", "назначение короля"])
        }

    def rebirth_old_order(self, old_order_name):
        new_name = f"Наследие {old_order_name}"
        ideology_shift = random.choice(["либеральный", "жесткий милитаризм", "интеграция магии"])
        return {
            "old_order": old_order_name,
            "new_order": new_name,
            "ideology": ideology_shift,
            "leader": f"Новый наставник {random.choice(['Лео', 'Рейна', 'Скорн'])}",
            "relations": {
                "kingdoms": random.choice(["враждебные", "союзные", "нейтральные"]),
                "магические школы": random.choice(["партнёрство", "подозрение", "вражда"])
            }
        }


    def wandering_bard_tale(self, player_region):
        tale_type = random.choice(["о древнем ордене", "о магической катастрофе", "о падении короля", "о запретной школе"])
        source = random.choice(["старая песня", "летопись в таверне", "пьяный сказитель", "песнь слепой гадалки"])
        truth = random.choice(["правда", "легенда", "преувеличение", "забытая истина"])
        return {
            "region": player_region,
            "tale": tale_type,
            "source": source,
            "truth": truth
        }

    def magical_power_fluctuation(self, region):
        phase = random.choice(["расцвет", "упадок", "нестабильность"])
        reasons = {
            "расцвет": ["приток магов", "найден источник маны", "союз с магической школой"],
            "упадок": ["магическая буря", "запрет королевства", "уход магов"],
            "нестабильность": ["сбои в потоках", "артефакт пробуждён", "вмешательство богов"]
        }
        effects = {
            "расцвет": ["усиление магических квестов", "больше артефактов", "NPC-маги активны"],
            "упадок": ["ослабление магии", "закрытие школ", "изгнание магов"],
            "нестабильность": ["рандомные эффекты", "порча", "опасные зоны"]
        }
        return {
            "region": region,
            "state": phase,
            "cause": random.choice(reasons[phase]),
            "effects": effects[phase]
        }


    def simulate_dynamic_dialogue(self, npc_personality, topic):
        emotional_bias = {
            "жестокий": ["насмешки", "угрозы", "подозрения"],
            "харизматичный": ["юмор", "обаяние", "манипуляции"],
            "подчинённый": ["молчаливость", "согласие", "тревога"],
            "трусливый": ["извинения", "уклонение", "страх"],
            "фетишист": ["двусмысленность", "увлечённость", "волнение"]
        }
        emotion = random.choice(emotional_bias.get(npc_personality, ["нейтрально"]))
        response_style = {
            "угрозы": "Не лезь, пока жив.",
            "обаяние": "Ты мне уже нравишься.",
            "тревога": "Я не должен об этом говорить...",
            "страх": "Пожалуйста, не трогай меня.",
            "волнение": "Ты говоришь прямо как из моих фантазий.",
            "нейтрально": "Что ты хочешь узнать?",
        }
        return {
            "npc_mood": emotion,
            "response": response_style.get(emotion, "Что тебе нужно?")
        }

    def generate_mod_settings_template(self):
        return {
            "enable_factions": True,
            "enable_erotic_content": True,
            "npc_max_level": 40,
            "weather_random_events": True,
            "magic_power_variation": True,
            "kingdom_conflict_intensity": "dynamic",  # options: low/medium/dynamic
            "nsfw_consent_system": True
        }

    def register_custom_mod(self, mod_name, mod_logic):
        # Модульная загрузка
        return f"Модуль '{mod_name}' зарегистрирован как активный. Поведение: {mod_logic[:60]}..."
