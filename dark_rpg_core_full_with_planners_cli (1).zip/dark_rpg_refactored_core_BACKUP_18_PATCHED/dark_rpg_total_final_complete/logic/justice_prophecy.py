
# logic/justice_prophecy.py

import random

class JusticeSystem:
    def __init__(self):
        self.case_log = []

    def judge_case(self, npc_name, crime_type, reputation):
        if crime_type == "воровство":
            if reputation > 60:
                verdict = "оправдан"
            else:
                verdict = "штраф"
        elif crime_type == "ересь":
            verdict = random.choice(["сожжение", "прощение", "пытки"])
        else:
            verdict = random.choice(["заточение", "оправдание", "ссылка"])

        result = {
            "npc": npc_name,
            "преступление": crime_type,
            "приговор": verdict
        }
        self.case_log.append(result)
        return result

    def get_all_cases(self):
        return self.case_log


class ProphecySystem:
    def __init__(self):
        self.prophecies = self.generate_prophecies()

    def generate_prophecies(self):
        return [
            {"текст": "Когда кровь затопит храм, откроется путь в мир Теней.", "активна": True},
            {"текст": "Тот, кто услышит голос Змеи, станет Повелителем Бури.", "активна": True},
            {"текст": "Последний из рода Мальвис принесёт либо погибель, либо спасение.", "активна": True},
        ]

    def reveal_prophecy(self):
        for p in self.prophecies:
            if p["активна"]:
                p["активна"] = False
                return p
        return {"текст": "Все пророчества пока сокрыты.", "активна": False}

    def get_all_prophecies(self):
        return self.prophecies
