
# logic/npc_affiliations.py

import random

class NPCAffiliations:
    def __init__(self, clans, kingdoms):
        self.clans = clans
        self.kingdoms = kingdoms
        self.roles = ["гражданин", "раб", "шпион", "рыцарь", "дворянин", "жрец", "охотник", "предатель"]

    def assign_affiliations(self, npc_name):
        result = {
            "name": npc_name,
            "clan": random.choice(self.clans).name if random.random() < 0.6 else None,
            "kingdom": random.choice(self.kingdoms) if random.random() < 0.8 else None,
            "role": random.choice(self.roles)
        }

        if result["role"] == "раб":
            result["clan"] = None  # рабы не принадлежат к кланам
        return result
