
# logic/artifact_system.py

import random

class Artifact:
    def __init__(self, name, effect, cost, cursed=False):
        self.name = name
        self.effect = effect
        self.cost = cost
        self.cursed = cursed

    def describe(self):
        return {
            "название": self.name,
            "эффект": self.effect,
            "стоимость": self.cost,
            "проклятие": self.cursed
        }

class ArtifactSystem:
    def __init__(self):
        self.artifacts = [
            Artifact("Кольцо желания", "увеличивает харизму", 1200, False),
            Artifact("Глаз Хаоса", "раскрывает скрытые цели", 1800, True),
            Artifact("Осквернённый жезл", "усиливает порчу мира", 1000, True),
            Artifact("Сердце нимфы", "повышает возбуждение у NPC", 800, False)
        ]

    def get_random_artifact(self):
        return random.choice(self.artifacts).describe()
