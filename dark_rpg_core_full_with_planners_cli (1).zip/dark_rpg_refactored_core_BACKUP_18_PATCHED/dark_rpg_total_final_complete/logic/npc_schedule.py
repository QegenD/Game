
# npc_schedule.py
class NPCSchedule:
    def __init__(self, npc_name):
        self.npc_name = npc_name
        self.schedule = {
            "утро": "молитва",
            "день": "работа",
            "вечер": "исчезает",
            "ночь": "в тайном месте"
        }

    def get_schedule(self):
        return dict(self.schedule)

    def modify_schedule(self, time, new_activity):
        if time in self.schedule:
            self.schedule[time] = new_activity
