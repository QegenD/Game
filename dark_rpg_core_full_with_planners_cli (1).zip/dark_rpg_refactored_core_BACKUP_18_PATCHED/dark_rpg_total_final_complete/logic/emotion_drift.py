
# emotion_drift.py
import random

class EmotionDrift:
    def __init__(self, npc_emotions):
        self.emotions = npc_emotions  # dict: {эмоция: значение}

    def evolve(self):
        drifted = {}
        for emotion, value in self.emotions.items():
            drift = random.choice([-1, 0, 1])
            drifted[emotion] = max(0, min(100, value + drift))
        return drifted
