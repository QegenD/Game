
# logic/npc_growth.py

import random

class NPCGrowth:
    def evolve_appearance(self, npc):
        changes = []
        if random.random() < 0.3:
            changes.append("седые волосы")
        if random.random() < 0.2:
            changes.append("татуировка")
        if npc.get("job") in ["наёмник", "воин"] and random.random() < 0.4:
            changes.append("шрам")
        if "appearance" not in npc:
            npc["appearance"] = []
        npc["appearance"].extend(changes)
        return npc

    def generate_offspring(self, npc):
        if npc.get("can_have_children", True) and random.random() < 0.4:
            children = npc.get("children", [])
            child = {
                "name": f"Наследник {npc.get('name', 'Неизвестный')}",
                "traits": random.sample(npc.get("traits", []), k=min(2, len(npc.get("traits", [])))),
                "job": "ученик",
                "relationship": 50,
                "origin": npc.get("job"),
            }
            children.append(child)
            npc["children"] = children
        return npc

    def develop_arc(self, npc):
        arc_events = npc.get("arc", [])
        options = [
            "предательство друга",
            "любовь к врагу",
            "обнаружение древней магии",
            "борьба с зависимостью",
            "восстание против фракции"
        ]
        if random.random() < 0.5:
            arc_events.append(random.choice(options))
        npc["arc"] = arc_events
        return npc
