
# logic/justice_prophecy_extended.py

import random

class CourtRoom:
    def __init__(self):
        self.judges = ["Инквизитор Варрен", "Магистр Лиор", "Судья Алма"]
        self.bribes_allowed = True

    def hold_trial(self, npc_name, crime, reputation, bribe_attempt=False):
        judge = random.choice(self.judges)
        result = {"npc": npc_name, "преступление": crime, "судья": judge}

        if bribe_attempt and self.bribes_allowed and random.random() < 0.6:
            result["приговор"] = "оправдан (взятка)"
        else:
            if reputation > 70:
                result["приговор"] = "оправдан"
            elif reputation < 30:
                result["приговор"] = random.choice(["пытки", "ссылка"])
            else:
                result["приговор"] = random.choice(["штраф", "заточение", "оправдан"])

        return result


class ProphecyQuestSystem:
    def __init__(self):
        self.ancient_ruins = ["Руины Морриса", "Обелиск Древнего Заклятия", "Проклятые Крипты"]
        self.decoded_prophecies = []

    def discover_ruin(self):
        location = random.choice(self.ancient_ruins)
        content = random.choice([
            "Кровавая Луна восстанет, когда три королевства падут.",
            "Имя Спящего Бога откроется лишь в час Молний.",
            "В Бездне под Осколком спрятан Ключ Костей."
        ])
        self.decoded_prophecies.append({"локация": location, "текст": content})
        return {"локация": location, "текст": content}

    def get_all_decoded(self):
        return self.decoded_prophecies
