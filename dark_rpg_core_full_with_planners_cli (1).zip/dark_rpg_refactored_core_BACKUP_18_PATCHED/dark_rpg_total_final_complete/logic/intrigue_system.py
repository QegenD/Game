
# intrigue_system.py

import random

class Intrigue:
    def __init__(self, npc_a, npc_b):
        self.initiator = npc_a
        self.target = npc_b
        self.type = random.choice(["шантаж", "обман", "подкуп", "роман", "убийство", "сговор"])
        self.severity = random.randint(10, 100)

    def describe(self):
        return f"{self.initiator.name} плетёт интригу против {self.target.name} ({self.type}, интенсивность {self.severity})"
