
# logic/npc_nobility.py

import random

class NPCNobilitySystem:
    def propose_marriage(self, npc1, npc2):
        if npc1.get("family_id") == npc2.get("family_id"):
            return None  # запрет инцеста
        if random.random() < 0.6:
            marriage = {
                "partner_1": npc1["name"],
                "partner_2": npc2["name"],
                "political_union": random.random() < 0.5
            }
            npc1["married_to"] = npc2["name"]
            npc2["married_to"] = npc1["name"]
            return marriage
        return None

    def generate_lineage(self, family_id, generations=3):
        lineage = []
        for _ in range(generations):
            lineage.append({
                "ancestor_name": f"Древний {random.choice(['Арамис', 'Валор', 'Седрик', 'Элейн'])}",
                "feat": random.choice([
                    "основал город", "победил дракона", "изобрёл магию крови",
                    "освободил рабов", "основал клан убийц"
                ]),
                "relic": random.choice(["клинок", "свиток", "печать", "корона"]),
            })
        return lineage

    def assign_claim(self, npc, title="трон", legitimacy="сомнительная"):
        npc["claim"] = {
            "title": title,
            "legitimacy": legitimacy,
            "support": random.randint(0, 100)
        }
        return npc
