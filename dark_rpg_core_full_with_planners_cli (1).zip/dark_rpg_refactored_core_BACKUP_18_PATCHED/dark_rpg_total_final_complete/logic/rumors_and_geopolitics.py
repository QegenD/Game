
# logic/rumors_and_geopolitics.py

import random

class RumorSystem:
    def __init__(self):
        self.rumors = []

    def generate_rumor(self, subject):
        r = f"Слух: {subject} возможно замешан в заговоре..."
        self.rumors.append(r)
        return r

    def get_latest_rumors(self):
        return self.rumors[-10:]

class GeoPolitics:
    def __init__(self):
        self.factions = {
            "Королевство Айртал": {"alliances": [], "enemies": ["Царство Змей"]},
            "Царство Змей": {"alliances": [], "enemies": ["Королевство Айртал"]},
            "Свободные Гильдии": {"alliances": [], "enemies": []}
        }

    def simulate_pact_or_war(self):
        keys = list(self.factions.keys())
        f1, f2 = random.sample(keys, 2)
        relation = random.choice(["alliance", "war"])
        if relation == "alliance":
            self.factions[f1]["alliances"].append(f2)
            return f"{f1} и {f2} заключили союз."
        else:
            self.factions[f1]["enemies"].append(f2)
            return f"{f1} объявили войну {f2}."
