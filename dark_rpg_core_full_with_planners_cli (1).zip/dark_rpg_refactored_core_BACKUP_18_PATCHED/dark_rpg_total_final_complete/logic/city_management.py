
# logic/city_management.py

import random

class City:
    def __init__(self, name):
        self.name = name
        self.population = random.randint(1000, 5000)
        self.wealth = random.randint(50, 200)
        self.security = random.randint(0, 100)
        self.owner = None  # игрок, клан или фракция
        self.buildings = {"рынок": 1, "стража": 1, "гильдия": 0}

    def upgrade(self, building):
        if building in self.buildings:
            self.buildings[building] += 1
            self.wealth += 10
            self.security += 5
            return f"{building} в {self.name} улучшено."
        return "Невозможно улучшить."

    def assign_owner(self, owner_name):
        self.owner = owner_name

    def city_status(self):
        return {
            "name": self.name,
            "population": self.population,
            "wealth": self.wealth,
            "security": self.security,
            "owner": self.owner,
            "buildings": self.buildings
        }

class Tavern:
    def __init__(self, name):
        self.name = name
        self.reputation = random.randint(0, 100)
        self.income = 0
        self.events = []

    def host_event(self, event_type):
        gain = random.randint(10, 30)
        self.reputation += gain // 2
        self.income += gain
        self.events.append(event_type)
        return f"{self.name} провела {event_type}, репутация +{gain//2}, доход +{gain}"

    def status(self):
        return {
            "name": self.name,
            "reputation": self.reputation,
            "income": self.income,
            "events": self.events[-5:]
        }
