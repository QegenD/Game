
# psyche_progression.py
class PsycheProfile:
    def __init__(self):
        self.states = {
            "уверенность": 0,
            "травма": 0,
            "порча": 0,
            "безумие": 0,
        }

    def apply_event(self, event_type, value):
        if event_type in self.states:
            self.states[event_type] += value

    def get_psych_profile(self):
        return dict(self.states)
