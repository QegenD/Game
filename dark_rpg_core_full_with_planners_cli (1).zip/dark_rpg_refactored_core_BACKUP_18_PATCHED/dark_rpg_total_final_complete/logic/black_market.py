
# logic/black_market.py

import random

class BlackMarket:
    def __init__(self):
        self.secret_items = [
            {"название": "Яд королевы-змеи", "цена": 300},
            {"название": "Прах влюблённого духа", "цена": 450},
            {"название": "Талисман похоти", "цена": 500},
        ]
        self.availability = {}

    def update_black_market(self, towns):
        for town in towns:
            self.availability[town] = random.choice([True, False])

    def get_black_items(self, town):
        if self.availability.get(town, False):
            return self.secret_items
        return []

    def is_available(self, town):
        return self.availability.get(town, False)
