
# logic/consequences.py

class ConsequenceSystem:
    def __init__(self):
        self.reputation = 0
        self.wanted = False
        self.status = "свободен"
        self.title = None
        self.history = []

    def apply_consequence(self, role):
        if role == "заговорщик":
            self.reputation -= 30
            self.history.append("Игрок уличён в участии в заговоре.")
            if self.reputation < -50:
                self.wanted = True
                self.status = "разыскивается"
        elif role == "шпион":
            self.reputation += 10
            self.history.append("Игрок помог раскрыть заговор.")
        elif role == "детектив":
            self.reputation += 20
            self.history.append("Игрок расследовал и предотвратил заговор.")
        self.check_title()

    def check_title(self):
        if self.reputation > 70 and not self.title:
            self.title = "Герой королевства"
            self.history.append("Игрок удостоен титула Герой королевства.")
        elif self.reputation < -100 and not self.title:
            self.title = "Изгой"
            self.history.append("Игрок признан изгоем и отлучён от большинства фракций.")

    def get_consequence_summary(self):
        return {
            "reputation": self.reputation,
            "wanted": self.wanted,
            "status": self.status,
            "title": self.title,
            "history": self.history
        }
