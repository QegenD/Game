
# logic/world_events.py

import random

class RevolutionSystem:
    def check_for_revolt(self, city, oppression_level, hunger_level):
        if oppression_level + hunger_level > 15:
            return f"В {city} начинается революция!"
        return f"Жители {city} напряжены, но пока мирно."

class MagicalBeasts:
    def summon_beast(self, region):
        beasts = ["Аркано-Гидра", "Проклятый Древень", "Манажор Тени"]
        return f"В {region} появляется магическое чудовище: {random.choice(beasts)}"

class TradeConflictSystem:
    def trigger_trade_war(self, faction1, faction2):
        return f"Торговая война между {faction1} и {faction2} нарушает поставки товаров."

    def apply_blockade(self, city):
        return f"Город {city} блокирован. Цены растут, товары исчезают."

class MageGuildExpansion:
    def define_guild(self):
        philosophies = [
            "Чистота магии превыше всего",
            "Магия — дар, которым нельзя делиться",
            "Равенство магов и смертных"
        ]
        codes = ["Не учи немагов", "Наказывай нарушителей", "Храни знания в секрете"]
        return {
            "философия": random.choice(philosophies),
            "кодекс": random.choice(codes),
        }

    def conflict_between_guilds(self, guild1, guild2):
        return f"Гильдии магов {guild1} и {guild2} вступают в конфликт за идеологию и власть."
