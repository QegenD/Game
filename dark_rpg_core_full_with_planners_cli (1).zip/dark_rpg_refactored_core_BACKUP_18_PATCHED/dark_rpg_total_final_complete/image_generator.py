import requests
import base64
from io import BytesIO
from PIL import Image
import os

SD_API_URL = "http://127.0.0.1:7860"

def generate_image(prompt, output_path, negative_prompt="blurry, lowres, ugly, distorted", steps=25, cfg_scale=7):
    payload = {
        "prompt": prompt,
        "negative_prompt": negative_prompt,
        "steps": steps,
        "cfg_scale": cfg_scale,
        "width": 512,
        "height": 768
    }
    try:
        response = requests.post(f"{SD_API_URL}/sdapi/v1/txt2img", json=payload)
        response.raise_for_status()
        image_data = response.json()["images"][0]
        image = Image.open(BytesIO(base64.b64decode(image_data.split(",", 1)[-1])))
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        image.save(output_path)
        print(f"Generated image saved to {output_path}")
        return True
    except Exception as e:
        print(f"Failed to generate image: {e}")
        return False