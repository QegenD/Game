class FactionManager:
    def __init__(self):
        self.factions = []

    def add_faction(self, faction):
        self.factions.append(faction)

    def get_factions(self):
        return self.factions

    def get_faction_by_name(self, name):
        return next((f for f in self.factions if f["name"] == name), None)