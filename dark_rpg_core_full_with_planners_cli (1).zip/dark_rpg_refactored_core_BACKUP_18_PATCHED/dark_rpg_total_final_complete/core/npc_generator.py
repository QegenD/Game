
import random

class NPCGenerator:
    def __init__(self, world_context):
        self.world_context = world_context

    def generate_npc(self):
        base_traits = ['трусливый', 'жестокий', 'харизматичный', 'подчинённый', 'фетишист']
        base_roles = ['стражник', 'маг', 'купец', 'наёмник', 'аристократ']
        factions = self.world_context.get('factions', [])
        kingdoms = self.world_context.get('kingdoms', [])

        npc = {
            'name': self._generate_name(),
            'traits': random.sample(base_traits, k=2),
            'role': random.choice(base_roles),
            'faction': random.choice(factions) if factions else None,
            'kingdom': random.choice(kingdoms) if kingdoms else None,
            'memory': [],
        }
        return npc

    def _generate_name(self):
        return random.choice(['Аркан', 'Люциус', 'Тира', 'Мелина', 'Роан', 'Сараэль']) +                ' ' + random.choice(['Из Туманных Холмов', 'С Чёрной Реки', 'Безликий', 'Рунический'])

