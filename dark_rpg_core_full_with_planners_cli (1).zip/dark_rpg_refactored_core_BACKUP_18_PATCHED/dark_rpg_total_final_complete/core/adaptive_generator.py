
import random

class AdaptiveMemory:
    def __init__(self):
        self.interaction_log = []
        self.context_weights = {}

    def log_interaction(self, context, result):
        self.interaction_log.append((context, result))
        if context not in self.context_weights:
            self.context_weights[context] = 1
        else:
            self.context_weights[context] += 1

    def get_weighted_context(self):
        if not self.context_weights:
            return None
        return max(self.context_weights, key=self.context_weights.get)

    def adjust_behavior(self, options):
        # Приоритетное поведение по частоте
        context = self.get_weighted_context()
        if context and context in options:
            return options[context]
        return random.choice(list(options.values())) if options else None
