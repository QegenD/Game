import random
import json
from core.npc_memory import NPCMemory

class AIContentGenerator:
    def __init__(self):
        self.memory = NPCMemory()
        self.load_templates()

    def load_templates(self):
        with open("data/templates/npc_personalities.json", "r", encoding="utf-8") as f:
            self.npc_traits = json.load(f)
        with open("data/templates/rumor_templates.json", "r", encoding="utf-8") as f:
            self.rumor_templates = json.load(f)
        with open("data/templates/faction_templates.json", "r", encoding="utf-8") as f:
            self.faction_templates = json.load(f)

    def generate_npc(self):
        trait = random.choice(self.npc_traits)
        npc = {
            "name": f"{random.choice(['Ael', 'Dorn', 'Ysa', 'Mar'])}{random.randint(100, 999)}",
            "trait": trait,
            "faction": random.choice(self.faction_templates)['name']
        }
        self.memory.store_npc(npc)
        return npc

    def generate_rumor(self, player_action):
        template = random.choice(self.rumor_templates)
        return template.replace("{action}", player_action)

    def generate_faction(self):
        template = random.choice(self.faction_templates)
        return {
            "name": template["name"],
            "alignment": template["alignment"],
            "goal": template["goal"]
        }