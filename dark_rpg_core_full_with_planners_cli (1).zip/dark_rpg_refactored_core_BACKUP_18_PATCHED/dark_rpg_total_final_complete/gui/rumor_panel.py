
# rumor_panel.py
import tkinter as tk

class RumorPanel(tk.Toplevel):
    def __init__(self, master, rumors):
        super().__init__(master)
        self.title("Слухи и мир")
        self.geometry("400x300")
        tk.Label(self, text="Газетные слухи:", font=("Arial", 12, "bold")).pack(pady=5)

        self.text = tk.Text(self, wrap="word")
        self.text.pack(fill="both", expand=True, padx=10)
        self.text.insert("end", "\n".join(rumors))
        self.text.config(state="disabled")
