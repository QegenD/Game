
# nsfw_scene_panel.py
import tkinter as tk
from tkinter import ttk

class NSFWScenePanel(tk.Toplevel):
    def __init__(self, master, npc_name="???"):
        super().__init__(master)
        self.title(f"Сцена с {npc_name}")
        self.geometry("500x400")
        self.npc_name = npc_name

        self.label = tk.Label(self, text=f"Интерактивная сцена с {npc_name}")
        self.label.pack(pady=10)

        self.arousal = tk.IntVar(value=20)
        self.consent = tk.IntVar(value=50)
        self.fear = tk.IntVar(value=10)

        self.create_meter("Возбуждение", self.arousal)
        self.create_meter("Согласие", self.consent)
        self.create_meter("Страх", self.fear)

        self.text_area = tk.Text(self, height=6, wrap="word")
        self.text_area.insert("end", "NPC ждёт вашего действия...")
        self.text_area.config(state="disabled")
        self.text_area.pack(pady=10)

        self.button_frame = tk.Frame(self)
        self.button_frame.pack()

        for action in ["Доминировать", "Подчиниться", "Флиртовать", "Остановиться"]:
            b = tk.Button(self.button_frame, text=action, width=15, command=lambda a=action: self.handle_action(a))
            b.pack(side="left", padx=5)

    def create_meter(self, label_text, variable):
        frame = tk.Frame(self)
        frame.pack(fill="x", padx=20)
        label = tk.Label(frame, text=label_text, width=15)
        label.pack(side="left")
        progress = ttk.Progressbar(frame, variable=variable, maximum=100)
        progress.pack(fill="x", expand=True)

    def handle_action(self, action):
        self.text_area.config(state="normal")
        self.text_area.insert("end", f"Вы выбрали: {action}
")
        self.text_area.config(state="disabled")
        # Здесь можно вставить логику реакции NPC на основе психологии
