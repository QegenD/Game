
# player_profile_panel.py
import tkinter as tk

class PlayerProfilePanel(tk.Toplevel):
    def __init__(self, master, player_data):
        super().__init__(master)
        self.title("Профиль Игрока")
        self.geometry("400x300")

        lines = [
            f"Титулы: {', '.join(player_data['titles'])}",
            f"Карма: {player_data['karma']}",
            f"Репутация по фракциям:",
        ]
        for f, r in player_data['faction_rep'].items():
            lines.append(f"  - {f}: {r}")

        lines.append(f"Черты: {', '.join(player_data['traits'])}")
        lines.append(f"Фетиши: {', '.join(player_data['desires'])}")

        for line in lines:
            tk.Label(self, text=line, anchor="w").pack(fill="x", padx=10, pady=2)
