from PyQt6.QtWidgets import QWidget, QGridLayout, QPushButton, QLabel, QVBoxLayout
from world_generator import generate_world_map

class WorldMapPanel(QWidget):
    def __init__(self, on_enter_location):
        super().__init__()
        self.setWindowTitle("🌍 Карта мира")
        self.resize(600, 600)
        self.setStyleSheet("background-color: #111; color: #eee; font-size: 12px;")
        self.layout = QVBoxLayout()
        self.grid = QGridLayout()
        self.world = generate_world_map()
        self.on_enter_location = on_enter_location

        self.title = QLabel("Выберите локацию для путешествия:")
        self.layout.addWidget(self.title)
        self.layout.addLayout(self.grid)

        for i, row in enumerate(self.world):
            for j, loc in enumerate(row):
                btn = QPushButton(f"{i},{j}\n{loc['tag'].capitalize()}\n{loc['structure']}")
                btn.setStyleSheet("background-color: #222; color: #fff; padding: 10px;")
                btn.clicked.connect(lambda _, l=loc: self.enter_location(l))
                self.grid.addWidget(btn, i, j)

        self.setLayout(self.layout)

    def enter_location(self, location):
        self.on_enter_location(location)
        self.close()
