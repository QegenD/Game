# Конфигурация проекта RPG-песочницы

enable_visualization = False
llm_endpoint = "http://localhost:11434/api/generate"
event_log_path = "world_log.json"
update_interval_seconds = 60