
# fetish_system.py

class Fetish:
    def __init__(self, name, description):
        self.name = name
        self.description = description

class FetishSystem:
    def __init__(self):
        self.fetishes = {}

    def learn_fetish(self, npc_id, fetish_name):
        self.fetishes.setdefault(npc_id, set()).add(fetish_name)

    def get_fetishes(self, npc_id):
        return self.fetishes.get(npc_id, set())
