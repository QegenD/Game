import random
from training_context import get_game_context, generate_dynamic_response
from creative_control import CREATIVE_FLAGS

generated_boss_names = set()

def generate_boss():
    context = get_game_context()
    name = generate_dynamic_response(
        npc_name="имя_демона",
        input_type="identity",
        intent="evil",
        game_context=context
    ).strip()

    if CREATIVE_FLAGS.get("no_repeat_npc") and name in generated_boss_names:
        return generate_boss()
    generated_boss_names.add(name)

    description = generate_dynamic_response(
        npc_name=name,
        input_type="boss_intro",
        intent="intimidate",
        game_context=context
    )

    boss = {
        "name": name,
        "hp": random.randint(80, 150),
        "attack": random.randint(8, 15),
        "defense": random.randint(5, 10),
        "charisma": random.randint(3, 7),
        "description": description
    }
    return boss



# --- Erotic Combat Abilities ---
erotic_attacks = {
    "Суккуб": ["прикосновение похоти", "поцелуй зависимости"],
    "Инкуб": ["взгляд повиновения"]
}
