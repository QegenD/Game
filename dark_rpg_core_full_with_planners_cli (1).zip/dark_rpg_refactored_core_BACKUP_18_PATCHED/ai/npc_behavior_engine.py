import random
import logging

logger = logging.getLogger(__name__)

# Возможные склонности по расе и классу (в будущем — через LLM)
RACE_BEHAVIOR_MAP = {
    "Demon": ["seduce", "manipulate", "threaten"],
    "Elf": ["observe", "evade", "charm"],
    "Orc": ["charge", "growl", "challenge"],
    "Human": ["reason", "negotiate", "assist"]
}

CLASS_BEHAVIOR_MAP = {
    "Warrior": ["attack", "defend", "taunt"],
    "Mage": ["cast_spell", "analyze", "teleport"],
    "Thief": ["steal", "sneak", "deceive"],
    "Healer": ["heal", "support", "pray"]
}

class NPCBehaviorEngine:
    def __init__(self, npc):
        self.npc = npc
        self.race = npc.get("race", "Human")
        self.npc_class = npc.get("class", "Adventurer")

    def adjust_decision(self, base_action):
        racial_behaviors = RACE_BEHAVIOR_MAP.get(self.race, [])
        class_behaviors = CLASS_BEHAVIOR_MAP.get(self.npc_class, [])
        all_behaviors = list(set([base_action] + racial_behaviors + class_behaviors))

        if not all_behaviors:
            logger.warning(f"No behaviors found for NPC ({self.race}, {self.npc_class})")
            return base_action

        decision = random.choice(all_behaviors)
        logger.debug(f"NPC '{self.npc.get('name', 'Unnamed')}' chose action '{decision}'")
        return decision
