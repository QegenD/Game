from dataclasses import dataclass, field
from typing import List

@dataclass
class Goal:
    name: str
    progress: float = 0.0  # 0..100

@dataclass
class Faction:
    name: str
    goals: List[Goal] = field(default_factory=list)

    def add_goal(self, goal: str):
        self.goals.append(Goal(goal))

    def tick(self):
        for g in self.goals:
            g.progress = min(100.0, g.progress + 1.0)
