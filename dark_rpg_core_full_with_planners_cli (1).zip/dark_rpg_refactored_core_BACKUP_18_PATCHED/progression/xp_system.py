
# xp_system.py — опыт, уровни, рост после боя

class XPSystem:
    def __init__(self, npc):
        self.npc = npc
        if not hasattr(npc, 'xp'):
            npc.xp = 0
            npc.level = 1

    def award_xp(self, amount):
        self.npc.xp += amount
        print(f"{self.npc.name} gains {amount} XP.")

        while self.npc.xp >= self.xp_to_level():
            self.npc.xp -= self.xp_to_level()
            self.npc.level += 1
            self.level_up()

    def xp_to_level(self):
        return 50 + (self.npc.level - 1) * 25

    def level_up(self):
        self.npc.strength += 1
        self.npc.dexterity += 1
        self.npc.hp += 5
        print(f"{self.npc.name} leveled up to {self.npc.level}!")
