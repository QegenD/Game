
# holy_trials.py — система публичных судов и казней

import random

def run_tribunal(npc):
    if npc.get("cult_member") or npc.get("accused_of_heresy"):
        result = random.choices(
            ["execution", "imprisonment", "absolution"],
            weights=[0.4, 0.4, 0.2],
            k=1
        )[0]
        npc["trial_outcome"] = result
        if result == "execution":
            npc["status"] = "казнён"
        elif result == "imprisonment":
            npc["status"] = "в тюрьме"
        else:
            npc["status"] = "оправдан"
        return f"⚖️ Суд над {npc['name']} завершён: {result}."
    return None
