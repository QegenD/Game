from dataclasses import dataclass
from typing import List, Dict, Any, Tuple, Optional
import copy

@dataclass
class StripsAction:
    name: str
    preconditions: Dict[str, Any]
    effects: Dict[str, Any]
    params: Dict[str, Any] = None

class StripsPlanner:
    '''
    Very small STRIPS-like planner supporting simple goals like:
      {'have_item': 'potion'}, {'at': (x,y)}, {'hp_gt': 5}
    Actions are templates inferred from world capabilities (move, pick_up, use_item, attack, rest).
    The planner does optimistic planning assuming actions succeed.
    '''
    def __init__(self, world, max_depth: int = 6):
        self.world = world
        self.max_depth = max_depth

    def state_features(self, world, actor_name: str):
        a = world.entities.get(actor_name)
        feat = {}
        if a is None:
            return feat
        feat['pos'] = a.pos
        feat['hp'] = a.hp
        feat['inv'] = dict(a.inv.items)
        return feat

    def goal_satisfied(self, feat: Dict[str,Any], goal: Dict[str,Any]) -> bool:
        if 'have_item' in goal:
            iid = goal['have_item']
            return feat.get('inv', {}).get(iid, 0) > 0
        if 'at' in goal:
            return feat.get('pos') == tuple(goal['at'])
        if 'hp_gt' in goal:
            return feat.get('hp', 0) > goal['hp_gt']
        return False

    def plan(self, actor_name: str, goal: Dict[str,Any]) -> List[Dict[str,Any]]:
        # BFS over optimistic actions (not simulating failures)
        from collections import deque
        start_feat = self.state_features(self.world, actor_name)
        if self.goal_satisfied(start_feat, goal):
            return []
        q = deque()
        q.append( (start_feat, []) )
        seen = set()
        depth = 0
        while q and depth < self.max_depth:
            feat, path = q.popleft()
            # generate candidate actions heuristically
            # 1) if goal is have_item, try pick_up if on ground, or talk/trade with adjacent
            if 'have_item' in goal:
                iid = goal['have_item']
                # if already at location with item, pick_up
                ground = getattr(self.world, 'ground_items', {})
                pos = feat['pos']
                items_here = ground.get(pos, [])
                if iid in items_here:
                    new_feat = dict(feat)
                    new_inv = dict(new_feat.get('inv', {}))
                    new_inv[iid] = new_inv.get(iid,0) + 1
                    new_feat['inv'] = new_inv
                    new_path = path + [ {'name':'pick_up', 'params': {'item_id': iid}} ]
                    if self.goal_satisfied(new_feat, goal):
                        return new_path
                    key = (tuple(new_feat['pos']), tuple(sorted(new_feat['inv'].items())))
                    if key not in seen:
                        seen.add(key); q.append((new_feat, new_path))
                # try moving to nearest ground item position (naive search)
                for loc, items in ground.items():
                    if iid in items:
                        # move step towards loc (single step)
                        curx, cury = feat['pos']
                        tx, ty = loc
                        step = (curx + (1 if tx>curx else -1 if tx<curx else 0),
                                cury + (1 if ty>cury else -1 if ty<cury else 0))
                        new_feat = dict(feat); new_feat['pos'] = step
                        new_path = path + [ {'name':'move','params':{'to': step}} ]
                        key = (tuple(new_feat['pos']), tuple(sorted(new_feat.get('inv',{}).items())))
                        if key not in seen:
                            seen.add(key); q.append((new_feat, new_path))
            # 2) hp goal -> rest or use consumable
            if 'hp_gt' in goal:
                if feat.get('hp',0) <= goal['hp_gt']:
                    # try use potion if has one
                    inv = feat.get('inv',{})
                    if inv.get('potion',0) > 0:
                        new_feat = dict(feat); new_feat['inv'] = dict(inv); new_feat['inv']['potion'] -= 1; new_feat['hp'] = new_feat.get('hp',0) + 8
                        new_path = path + [ {'name':'use_item','params':{'item_id':'potion'}} ]
                        if self.goal_satisfied(new_feat, goal): return new_path
                        key = (tuple(new_feat['pos']), tuple(sorted(new_feat['inv'].items())), new_feat['hp'])
                        if key not in seen: seen.add(key); q.append((new_feat, new_path))
                    # try rest
                    new_feat = dict(feat); new_feat['hp'] = min(20, new_feat.get('hp',0) + 5)
                    new_path = path + [ {'name':'rest','params':{}} ]
                    if self.goal_satisfied(new_feat, goal): return new_path
                    key = (tuple(new_feat['pos']), tuple(sorted(new_feat.get('inv',{}).items())), new_feat['hp'])
                    if key not in seen: seen.add(key); q.append((new_feat, new_path))
            depth += 1
        return []  # failed to plan

