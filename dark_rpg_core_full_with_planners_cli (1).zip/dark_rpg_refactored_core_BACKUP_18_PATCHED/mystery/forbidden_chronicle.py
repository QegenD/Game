
# forbidden_chronicle.py — летопись запретных событий (ересь, секты, жертвоприношения)

import datetime

FORBIDDEN_EVENTS = []

def log_forbidden_event(event_type, description, npc=None):
    timestamp = datetime.datetime.now().isoformat()
    entry = {
        "time": timestamp,
        "type": event_type,
        "desc": description
    }
    if npc:
        entry["npc"] = npc.get("name", "неизвестный участник")
    FORBIDDEN_EVENTS.append(entry)
    return f"🕯️ Записано в запретную хронику: {description}"

def get_recent_forbidden_events(limit=10):
    return FORBIDDEN_EVENTS[-limit:]
