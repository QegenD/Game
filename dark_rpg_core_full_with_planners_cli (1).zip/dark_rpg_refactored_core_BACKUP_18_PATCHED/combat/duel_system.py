
# duel_system.py — дуэли за честь, ревность, политику

from combat_engine import CombatEngine
from progression.xp_system import XPSystem

def resolve_duel(npc1, npc2):
    print(f"A duel begins between {npc1.name} and {npc2.name}!")

    combat = CombatEngine(npc1, npc2)
    xp1 = XPSystem(npc1)
    xp2 = XPSystem(npc2)

    attacker, defender = npc1, npc2
    while True:
        if combat.perform_turn():
            winner = attacker
            loser = defender
            break
        attacker, defender = defender, attacker
        combat.attacker = attacker
        combat.defender = defender

    print(f"{winner.name} wins the duel against {loser.name}!")
    xp = 30 if loser.status == "dead" else 15
    XPSystem(winner).award_xp(xp)
    XPSystem(loser).award_xp(5 if loser.status != "dead" else 0)
