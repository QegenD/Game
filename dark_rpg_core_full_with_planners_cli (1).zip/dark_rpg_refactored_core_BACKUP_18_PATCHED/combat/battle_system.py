
# battle_system.py — массовые сражения фракций

import random

def resolve_battle(faction_a, faction_b):
    power_a = sum(npc.strength + npc.level for npc in faction_a.members if getattr(npc, "hp", 1) > 0)
    power_b = sum(npc.strength + npc.level for npc in faction_b.members if getattr(npc, "hp", 1) > 0)

    morale_a = random.randint(0, 10)
    morale_b = random.randint(0, 10)

    score_a = power_a + morale_a
    score_b = power_b + morale_b

    if score_a > score_b:
        winner, loser = faction_a, faction_b
    else:
        winner, loser = faction_b, faction_a

    print(f"Battle between {faction_a.name} and {faction_b.name}!")
    print(f"{winner.name} is victorious with score {score_a if winner == faction_a else score_b}!")

    for npc in loser.members:
        if random.random() < 0.3:
            npc.status = "dead"
            print(f"{npc.name} was slain in battle.")
        elif random.random() < 0.3:
            npc.status = "maimed"
            print(f"{npc.name} was maimed and fled.")

    return winner.name
