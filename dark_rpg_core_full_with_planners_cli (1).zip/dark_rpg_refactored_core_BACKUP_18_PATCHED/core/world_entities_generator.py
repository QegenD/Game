
import random

class WorldEntityGenerator:
    def __init__(self, seed=None):
        self.random = random.Random(seed)

    def generate_kingdom(self):
        names = ["Эридион", "Тар-Морас", "Фалден", "Валкирия", "Корвус"]
        traits = ["тирания", "просвещённость", "закрытость", "хаос", "ортодоксия"]
        return {
            "name": self.random.choice(names),
            "type": "королевство",
            "trait": self.random.choice(traits),
            "symbol": self.random.choice(["лев", "орёл", "дракон", "череп"]),
        }

    def generate_order(self):
        names = ["Орден Погребённого Света", "Стражи Сумерек", "Железная Длань"]
        codes = ["честь", "верность", "правосудие", "бессмертие"]
        return {
            "name": self.random.choice(names),
            "type": "рыцарский орден",
            "code": self.random.choice(codes),
            "loyal_to": self.generate_kingdom()["name"],
        }

    def generate_clan(self):
        names = ["Клык Ветра", "Песчаные Кости", "Тёмная Буря"]
        motives = ["торговля", "контрабанда", "месть", "наёмничество"]
        return {
            "name": self.random.choice(names),
            "type": "клан",
            "motive": self.random.choice(motives),
            "secret": self.random.choice(["кровная вражда", "подкуп", "древнее проклятие"]),
        }

    def generate_magic_school(self):
        focuses = ["иллюзии", "призывы", "энергия", "время", "тени"]
        traditions = ["академическая", "хаотичная", "религиозная", "варварская"]
        return {
            "name": "Школа " + self.random.choice(["Аркан", "Текли", "Малька", "Ши'Нар"]),
            "focus": self.random.choice(focuses),
            "tradition": self.random.choice(traditions),
            "location": self.random.choice(["вулкан", "остров", "долина духов", "подземный храм"]),
        }
