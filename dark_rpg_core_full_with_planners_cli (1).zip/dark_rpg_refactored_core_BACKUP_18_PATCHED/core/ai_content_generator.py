import random
import json
import logging
from pathlib import Path
from core.npc_memory import NPCMemory

logger = logging.getLogger(__name__)

TEMPLATE_PATH = Path("data/templates")

def safe_load_template(filename, fallback=[]):
    try:
        path = TEMPLATE_PATH / filename
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"Failed to load {filename}: {e}")
        return fallback

class AIContentGenerator:
    def __init__(self):
        self.memory = NPCMemory()
        self.load_templates()

    def load_templates(self):
        self.npc_traits = safe_load_template("npc_personalities.json")
        self.rumor_templates = safe_load_template("rumor_templates.json")
        self.faction_templates = safe_load_template("faction_templates.json")
        self.name_prefixes = ["Ael", "Dorn", "Ysa", "Mar", "Kael", "Thal", "Zyn", "Lir", "Vor", "Sel"]
        self.name_suffixes = ["ion", "mar", "eth", "ael", "os", "dra", "mir", "en", "oth", "ys"]

    def generate_npc(self):
        name = f"{random.choice(self.name_prefixes)}{random.choice(self.name_suffixes)}"
        trait = random.choice(self.npc_traits) if self.npc_traits else "Mysterious"
        faction = random.choice(self.faction_templates)['name'] if self.faction_templates else "Wanderers"
        npc = {
            "name": name,
            "trait": trait,
            "faction": faction
        }
        self.memory.store_npc(npc)
        logger.info(f"Generated NPC: {npc}")
        return npc

    def generate_rumor(self, player_action):
        if not self.rumor_templates:
            return f"A strange rumor spreads about '{player_action}'."
        template = random.choice(self.rumor_templates)
        rumor = template.replace("{action}", player_action)
        logger.info(f"Generated rumor: {rumor}")
        return rumor

    def generate_faction(self):
        if not self.faction_templates:
            return {"name": "Nomads", "alignment": "Neutral", "goal": "Survival"}
        template = random.choice(self.faction_templates)
        faction = {
            "name": template.get("name", "Unnamed"),
            "alignment": template.get("alignment", "Unknown"),
            "goal": template.get("goal", "Undefined")
        }
        logger.info(f"Generated faction: {faction}")
        return faction
