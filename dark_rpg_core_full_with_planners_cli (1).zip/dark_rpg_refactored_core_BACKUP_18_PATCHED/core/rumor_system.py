import random
import datetime

class Rumor:
    def __init__(self, content, region, tags=None, source_npc=None):
        self.content = content
        self.region = region
        self.tags = tags or []
        self.source_npc = source_npc
        self.timestamp = datetime.datetime.now()

    def __str__(self):
        return f"[{self.timestamp.strftime('%Y-%m-%d %H:%M')}] ({self.region}) {self.content}"

class RumorSystem:
    def __init__(self):
        self.rumors_by_region = {}

    def add_rumor(self, content, region, tags=None, source_npc=None):
        rumor = Rumor(content, region, tags, source_npc)
        if region not in self.rumors_by_region:
            self.rumors_by_region[region] = []
        self.rumors_by_region[region].append(rumor)
        print(f"New rumor added in {region}: {content}")

    def get_recent_rumors(self, region, limit=5):
        if region not in self.rumors_by_region:
            return []
        return sorted(self.rumors_by_region[region], key=lambda r: r.timestamp, reverse=True)[:limit]

    def search_by_tag(self, tag):
        results = []
        for region_rumors in self.rumors_by_region.values():
            results.extend([r for r in region_rumors if tag in r.tags])
        return results

    def broadcast_player_action(self, action, region):
        templates = [
            f"Ходят слухи, что некий герой {action}.",
            f"Местные говорят о том, как кто-то {action}.",
            f"Поговаривают, что это был игрок, кто {action}.",
            f"Люди обсуждают последнее событие: {action}."
        ]
        rumor_text = random.choice(templates)
        self.add_rumor(rumor_text, region, tags=["player_action"])
