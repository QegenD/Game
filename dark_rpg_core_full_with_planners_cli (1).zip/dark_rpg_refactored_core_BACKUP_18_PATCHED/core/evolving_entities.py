
import random

class EvolvableEntity:
    def __init__(self, name, entity_type, **kwargs):
        self.name = name
        self.type = entity_type
        self.attributes = kwargs
        self.history = []

    def evolve(self):
        event = None

        if self.type == "королевство":
            shift = random.choice(["восстание", "переход к магократии", "разделение на два княжества"])
            self.attributes["trait"] = shift
            event = f"В {self.name} произошло событие: {shift}."
        elif self.type == "рыцарский орден":
            shift = random.choice(["раскол", "ересь", "союз с магами", "враг короны"])
            self.attributes["code"] = shift
            event = f"Орден {self.name} пережил {shift}."
        elif self.type == "клан":
            shift = random.choice(["распад", "поглощение другим кланом", "смена лидера"])
            self.attributes["motive"] = shift
            event = f"Клан {self.name} изменился: {shift}."
        elif self.type == "школа магии":
            shift = random.choice(["смена фокуса", "катастрофа", "слияние с другим орденом"])
            self.attributes["focus"] = shift
            event = f"Школа {self.name} эволюционировала: {shift}."

        if event:
            self.history.append(event)

    def get_history(self):
        return self.history[-5:]
