
# visual_trigger.py — обёртка для генерации артов из любого модуля

from core.auto_image_generator import AutoImageGenerator

generator = AutoImageGenerator()

def generate_scene(description, emotion=None, nsfw=False):
    return generator.generate("scene", description, emotion=emotion, nsfw=nsfw)

def generate_npc_portrait(npc_name, emotion=None, nsfw=False):
    return generator.generate("npc", npc_name, emotion=emotion, nsfw=nsfw)

def generate_location_image(location_name, mood=None):
    return generator.generate("location", location_name, emotion=mood)

def generate_death_legacy(name, cause):
    return generator.generate("legacy", f"{name} died: {cause}", emotion="tragic")
