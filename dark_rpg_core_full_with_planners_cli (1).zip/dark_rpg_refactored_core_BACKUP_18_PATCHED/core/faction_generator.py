
import random

class FactionGenerator:
    def __init__(self):
        self.templates = [
            ('Церковь Света', 'религиозная', 'вербует через наставления и моральные убеждения'),
            ('Культ Безликого', 'тёмный культ', 'вербует через страх и ритуалы'),
            ('Скрытая Академия', 'магическая школа', 'предлагает знания и силу'),
            ('Торговая Гильдия', 'экономическая фракция', 'даёт деньги, статус и контракты')
        ]

    def generate_faction(self):
        name, ftype, recruit_method = random.choice(self.templates)
        return {
            'name': name,
            'type': ftype,
            'recruitment': recruit_method,
            'goals': random.choice(['захват власти', 'контроль региона', 'магическое превосходство', 'деньги и влияние'])
        }
