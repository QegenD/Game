
class WorldCrisisManager:
    def __init__(self):
        self.city_states = {}

    def evaluate_crisis(self, city, alert_level, recent_events):
        crisis = []
        if alert_level >= 90:
            crisis.append("мобилизация войск")
        if "заговор" in recent_events:
            crisis.append("публичная казнь")
        if "эпидемия" in recent_events:
            crisis.append("эпидемия")
        if alert_level >= 70 and "набег" in recent_events:
            crisis.append("массовые беженцы")
        self.city_states[city] = crisis

    def get_city_crisis(self, city):
        return self.city_states.get(city, [])
