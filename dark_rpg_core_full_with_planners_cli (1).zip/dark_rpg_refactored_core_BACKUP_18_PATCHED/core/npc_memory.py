
class NPCMemory:
    def __init__(self):
        self.memories = []

    def remember(self, event):
        if isinstance(event, dict):
            self.memories.append(event)
        else:
            self.memories.append({ "summary": str(event) })

    def recall_recent(self, count=5):
        return self.memories[-count:]

    def recall_by_tag(self, tag):
        return [m for m in self.memories if tag in m.get("tags", [])]

    def forget_oldest(self, limit=100):
        if len(self.memories) > limit:
            self.memories = self.memories[-limit:]

class NPC:
    def __init__(self, name, personality):
        self.name = name
        self.personality = personality
        self.memory = NPCMemory()

    def experience_event(self, event):
        self.memory.remember(event)

    def speak_from_memory(self):
        recent = self.memory.recall_recent(3)
        if not recent:
            return "Мне нечего сказать..."
        else:
            return "Я помню: " + " | ".join(e.get("summary", "неясное воспоминание") for e in recent)
