
# main_player.py — объект игрока

from ui.race_class_panel import RaceClassPanel

class Player:
    def __init__(self):
        chooser = RaceClassPanel()
        self.race, self.npc_class = chooser.choose_race_class()
        self.name = "You"
        self.stats = {
            "combat": 0,
            "rituals": 0,
            "seduction": 0,
            "manipulation": 0,
            "stealth": 0,
            "honor": 0
        }
        self.apply_class_bonuses()

    def apply_class_bonuses(self):
        from systems.race_class_system import CLASSES
        cls = CLASSES.get(self.npc_class, {})
        for skill, value in cls.get("skills", {}).items():
            self.stats[skill] = value
