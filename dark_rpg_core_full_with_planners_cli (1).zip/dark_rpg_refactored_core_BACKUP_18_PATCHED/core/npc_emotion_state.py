from core.contextual_emotion_engine import ContextualEmotionEngine

class NPCEmotionState:
    def __init__(self, npc_id):
        self.npc_id = npc_id
        self.emotion_engine = ContextualEmotionEngine()
        self.history = []

    def update(self, event):
        self.history.append(event)
        self.emotion_engine.evaluate_event(event)

    def get_state(self):
        return self.emotion_engine.emotions

    def get_dominant_emotion(self):
        return self.emotion_engine.get_emotional_state()

    def reset(self):
        self.history.clear()
        self.emotion_engine = ContextualEmotionEngine()
