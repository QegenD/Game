
import random

class EventGenerator:
    def __init__(self):
        self.templates = [
            'Нападение бандитов на караван',
            'Разрушение деревни магической бурей',
            'Пропажа члена совета фракции',
            'Появление древнего артефакта',
            'Призыв к восстанию против королевства',
        ]

    def generate_event(self, player_actions, world_state):
        context_event = random.choice(self.templates)
        impact = random.choice(['хаос', 'мобилизация фракций', 'закрытие торговых путей', 'кризис доверия', 'рост напряжения'])
        return {
            'description': context_event,
            'impact': impact,
            'triggered_by': player_actions[-1] if player_actions else 'мировые силы',
            'location': random.choice(world_state.get('locations', ['Гленмур', 'Долина Теней', 'Остров Пепла']))
        }
