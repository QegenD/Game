
class CitySecurity:
    def __init__(self):
        self.city_status = {}

    def update_status(self, city, alert_level):
        if alert_level >= 80:
            self.city_status[city] = "высокая тревога"
        elif alert_level >= 50:
            self.city_status[city] = "усиленное патрулирование"
        elif alert_level >= 30:
            self.city_status[city] = "подозрительное спокойствие"
        else:
            self.city_status[city] = "спокойствие"

    def get_response(self, city):
        status = self.city_status.get(city, "спокойствие")
        if status == "высокая тревога":
            return {
                "entry_denied": True,
                "bounty_hunters": True,
                "raids_active": True
            }
        elif status == "усиленное патрулирование":
            return {
                "entry_denied": False,
                "bounty_hunters": True,
                "raids_active": False
            }
        elif status == "подозрительное спокойствие":
            return {
                "entry_denied": False,
                "bounty_hunters": False,
                "raids_active": True
            }
        else:
            return {
                "entry_denied": False,
                "bounty_hunters": False,
                "raids_active": False
            }

    def describe_city_status(self, city):
        status = self.city_status.get(city, "спокойствие")
        return f"Сейчас в {city}: {status}"
