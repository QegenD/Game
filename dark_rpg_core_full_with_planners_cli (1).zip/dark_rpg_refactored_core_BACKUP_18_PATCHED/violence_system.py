from dataclasses import dataclass

@dataclass
class AggressionCheck:
    should_attack: bool
    reason: str

def decide_violence(hostility: float, morale: float) -> AggressionCheck:
    # hostility: -100..100, morale: 0..100
    if hostility > 50 and morale > 30:
        return AggressionCheck(True, "High hostility and sufficient morale.")
    if morale < 10:
        return AggressionCheck(False, "Too demoralized to fight.")
    return AggressionCheck(False, "No compelling reason to attack.")
