
# game_master.py

import random
from logic.hidden_goals import NPCHiddenGoal
from logic.emotion_drift import EmotionDrift
from logic.world_state import WorldState
from logic.hidden_rolls import HiddenCheck
from logic.secret_agents import SecretAgent
from logic.intrigue_system import Intrigue
from logic.world_reaction import WorldReaction
from logic.investigation_system import Investigation

class NPC:
    def __init__(self, npc_id, name):
        self.id = npc_id
        self.name = name
        self.emotions = {"страх": random.randint(0, 50), "желание": random.randint(0, 50), "ненависть": random.randint(0, 50)}
        self.goal = NPCHiddenGoal(npc_id)
        self.agent = SecretAgent(npc_id)

    def evolve_emotions(self):
        drift = EmotionDrift(self.emotions)
        self.emotions = drift.evolve()

    def get_summary(self):
        return {
            "id": self.id,
            "name": self.name,
            "эмоции": self.emotions,
            "цель": self.goal.get_goal(),
            "агент": self.agent.reveal()
        }

from logic.extensions import GameExtensions

class GameMaster:
    def __init__(self):
        self.extensions = GameExtensions()
        self.world = WorldState()
        self.reaction = WorldReaction()
        self.npcs = []
        self.intrigues = []
        self.investigation = Investigation(self.intrigues)
        self.npc_names = ["Ланис", "Мирал", "Куорт", "Эсса", "Тавар", "Саирис", "Хелион"]

    def spawn_npcs(self, count=5):
        self.npcs = []
        ids = random.sample(range(1000, 9999), count)
        names = random.sample(self.npc_names, count)
        for npc_id, name in zip(ids, names):
            self.npcs.append(NPC(npc_id, name))

    def update_world(self):
        self.world.update_phase()
        if random.random() < 0.5:
            self.world.apply_corruption(random.randint(1, 5))

    def evolve_npcs(self):
        for npc in self.npcs:
            npc.evolve_emotions()

    def simulate_intrigue(self):
        if len(self.npcs) >= 2:
            a, b = random.sample(self.npcs, 2)
            intrigue = Intrigue(a, b)
            self.intrigues.append(intrigue)
            self.investigation.start_investigation(intrigue)

    def apply_player_action(self, action):
        self.reaction.apply_action(action)

    def advance_investigations(self):
        self.investigation.advance_investigations()

    def simulate_step(self):
        self.update_world()
        self.evolve_npcs()
        if random.random() < 0.7:
            self.simulate_intrigue()
        self.advance_investigations()

    def get_world_state(self):
        return self.world.get_state()

    def get_reputation(self):
        return self.reaction.get_state()

    def get_all_npc_data(self):
        return [npc.get_summary() for npc in self.npcs]

    def get_all_intrigues(self):
        return [intrigue.describe() for intrigue in self.intrigues]

    def get_investigation_report(self):
        return {
            "прогресс": self.investigation.get_progress_report(),
            "раскрытые": self.investigation.get_results()
        }

    def travel_to(self, location):
        return self.extensions.travel(location)

    def get_location(self):
        return self.extensions.current_zone()

    def get_world_zones(self):
        return self.extensions.get_zones()

    def get_artifact(self):
        return self.extensions.get_random_artifact()

    def get_recent_events(self):
        return self.extensions.get_recent_events()

    def record_event(self, entry):
        self.extensions.log_event(entry)

    def influence_npc(self, npc_index, action, effect):
        if 0 <= npc_index < len(self.npcs):
            self.npcs[npc_index].react_to_player(action, effect)
            self.record_event(f"{self.npcs[npc_index].name} испытал эффект от {action} ({effect})")

    def get_survival_status(self):
        return self.extensions.get_survival()

    def rest(self):
        self.extensions.rest()

    def eat(self):
        self.extensions.eat()

    def drink(self):
        self.extensions.drink()

    def get_world_conditions(self):
        return self.extensions.get_world_effects()

    def update_world_conditions(self):
        self.extensions.update_world()

    def get_town_rituals(self):
        return self.extensions.get_rituals_info()

    def perform_zone_ritual(self, town):
        return self.extensions.perform_ritual_in_zone(town)

    def get_town_prices(self, town):
        return self.extensions.get_trade_prices(town)

    def get_market_status(self):
        return self.extensions.get_market_events()

    def get_black_market(self, town):
        return self.extensions.get_black_market_items(town)

    def get_caravans(self):
        return self.extensions.get_caravan_routes()

    def get_clans(self):
        return self.extensions.get_all_clans()

    def get_city_clans(self, city):
        return self.extensions.get_clans_in_city(city)

    def get_clan_reputation(self, clan_name):
        return self.extensions.get_clan_reputation(clan_name)

    def get_all_clan_reputations(self):
        return self.extensions.get_all_clan_reputation()

    def change_clan_reputation(self, clan_name, amount):
        self.extensions.adjust_clan_reputation(clan_name, amount)

    def generate_npc_with_affiliations(self, name):
        return self.extensions.generate_npc_profile(name)

    def advance_world_simulation(self):
        return self.extensions.advance_world()

    def get_recent_world_events(self, count=10):
        return self.extensions.get_world_events(count)

    def create_and_register_npc(self, name):
        return self.extensions.create_npc(name)

    def list_all_known_npcs(self):
        return self.extensions.get_all_npcs()

    def seed_world_conspiracies(self):
        self.extensions.seed_conspiracies()

    def advance_conspiracies(self):
        return self.extensions.advance_conspiracies()

    def list_active_conspiracies(self):
        return self.extensions.get_conspiracies()

    def choose_player_path(self, path):
        self.extensions.set_player_path(path)

    def player_action_on_conspiracies(self):
        return self.extensions.act_on_conspiracies()

    def apply_consequence_to_player(self):
        self.extensions.apply_player_consequence()

    def get_player_consequence_state(self):
        return self.extensions.get_player_fate()

    def tick_world(self, year):
        return self.extensions.simulate_world_tick(year)

    def get_rumors(self):
        return self.extensions.get_recent_rumors()

    def get_world_history(self):
        return self.extensions.get_recent_history()

    def list_religions(self):
        return self.extensions.list_religions()

    def generate_npc_rumor(self, npc_name):
        return self.extensions.generate_rumor_about(npc_name)

    def get_cities(self):
        return self.extensions.start_city_management()

    def city_upgrade(self, index, building):
        return self.extensions.upgrade_city_building(index, building)

    def set_city_owner(self, index, name):
        self.extensions.assign_city_owner(index, name)

    def tavern_event(self, index, event):
        return self.extensions.run_tavern_event(index, event)

    def get_tavern_info(self, index):
        return self.extensions.get_tavern_status(index)

    def magic_conflict(self):
        return self.extensions.simulate_magic_conflict()

    def list_magic_schools(self):
        return self.extensions.get_magic_school_list()

    def npc_faction_talk(self):
        return self.extensions.get_npc_faction_affiliation()

    def list_factions(self):
        return self.extensions.get_faction_info()

    def list_faction_conflicts(self):
        return self.extensions.get_faction_conflicts()

    def list_diplomatic_status(self):
        return self.extensions.get_diplomatic_status()

    def list_dynasties(self):
        return self.extensions.get_dynasty_info()

    def get_world_time(self):
        return self.extensions.get_calendar_time()

    def get_spy_network_info(self):
        return self.extensions.get_known_spies()

    def get_npc_world_reactions(self):
        return self.extensions.get_npc_reactions_to_world()

    def judge_npc_case(self, npc_name, crime_type, reputation=50):
        return self.extensions.judge_npc(npc_name, crime_type, reputation)

    def reveal_prophecy(self):
        return self.extensions.reveal_next_prophecy()

    def list_prophecies(self):
        return self.extensions.get_all_prophecies()

    def npc_trial_extended(self, npc_name, crime, reputation, bribe=False):
        return self.extensions.hold_npc_trial(npc_name, crime, reputation, bribe)

    def explore_ancient_prophecy(self):
        return self.extensions.explore_prophecy_ruin()

    def get_decoded_prophecies(self):
        return self.extensions.list_decoded_prophecies()

    def tribe_ritual(self, tribe_name):
        return self.extensions.perform_tribe_ritual(tribe_name)

    def npc_infection(self, npc_name, city):
        return self.extensions.infect_npc(npc_name, city)

    def npc_blood_arena_fight(self, npc1, npc2):
        return self.extensions.blood_arena_fight(npc1, npc2)

    def npc_immortality_attempt(self, npc_name):
        return self.extensions.npc_seeks_immortality(npc_name)

    def advance_historical_era(self):
        return self.extensions.next_era()

    def establish_dynasty(self, founder):
        return self.extensions.create_dynasty(founder)

    def transfer_title(self, parent, child):
        return self.extensions.inherit_title(parent, child)

    def get_npc_emotion(self, npc):
        return self.extensions.npc_emotion(npc)

    def summon_ghost(self, npc_name):
        return self.extensions.ghost_return(npc_name)

    def trigger_city_revolt(self, city, oppression, hunger):
        return self.extensions.check_city_revolt(city, oppression, hunger)

    def unleash_magical_beast(self, region):
        return self.extensions.summon_magical_beast(region)

    def initiate_trade_conflict(self, faction1, faction2):
        return self.extensions.trigger_trade_war(faction1, faction2)

    def apply_city_blockade(self, city):
        return self.extensions.blockade_city(city)

    def create_mage_guild(self):
        return self.extensions.define_mage_guild()

    def mage_conflict(self, guild1, guild2):
        return self.extensions.mage_guild_conflict(guild1, guild2)

    def create_secret_cult(self):
        return self.extensions.generate_cult()

    def generate_alchemical_item(self):
        return self.extensions.generate_potion()

    def smuggle_item(self, item, city):
        return self.extensions.smuggling_event(item, city)

    def execute_spy_action(self, faction):
        return self.extensions.perform_spy_action(faction)

    def migrate_npcs(self, from_city, to_city, reason):
        return self.extensions.trigger_migration(from_city, to_city, reason)

    def explore_ruins(self, region):
        return self.extensions.discover_ruins(region)

    def find_ancient_lore(self):
        return self.extensions.create_lore_item()

    def evolve_npc_behavior(self, npc, player_actions):
        npc = self.extensions.evolve_npc_traits(npc)
        npc = self.extensions.evolve_npc_job(npc)
        npc = self.extensions.update_npc_relationship(npc, player_actions)
        return npc

    def full_npc_evolution(self, npc, player_actions):
        npc = self.extensions.evolve_npc_traits(npc)
        npc = self.extensions.evolve_npc_job(npc)
        npc = self.extensions.update_npc_relationship(npc, player_actions)
        npc = self.extensions.evolve_npc_appearance(npc)
        npc = self.extensions.generate_npc_offspring(npc)
        npc = self.extensions.evolve_npc_arc(npc)
        return npc

    def process_family_dynamics(self, npc_group):
        updated = []
        for npc in npc_group:
            npc = self.extensions.assign_family(npc)
            updated.append(npc)

        if len(updated) >= 2:
            updated = self.extensions.trigger_family_conflict(updated)
        return updated

    def simulate_death_and_inheritance(self, npc_group, deceased_index):
        deceased = npc_group.pop(deceased_index)
        updated_group = self.extensions.simulate_inheritance(deceased, npc_group)
        return updated_group

    def simulate_noble_dynamics(self, noble_npcs):
        if len(noble_npcs) >= 2:
            marriage = self.extensions.attempt_marriage_alliance(noble_npcs[0], noble_npcs[1])
            if marriage:
                noble_npcs[0] = self.extensions.assign_political_claim(noble_npcs[0])
                noble_npcs[1] = self.extensions.assign_political_claim(noble_npcs[1])
        for npc in noble_npcs:
            if "family_id" in npc:
                npc["lineage"] = self.extensions.create_lineage_history(npc["family_id"])
        return noble_npcs

    def simulate_intrigue_events(self, noble_npcs):
        coup = self.extensions.trigger_coup(noble_npcs)
        assassination = self.extensions.trigger_assassination_attempt(random.choice(noble_npcs))
        for npc in noble_npcs:
                npc = self.extensions.assign_order_rank(npc)
        npc = self.extensions.assign_court_council_role(npc)
        return {"coup": coup, "assassination": assassination, "updated_nobles": noble_npcs}

# Пример использования
if __name__ == "__main__":
    gm = GameMaster()
    gm.spawn_npcs()
    gm.simulate_step()
    gm.apply_player_action("предательство")

    print("🌍 Состояние мира:", gm.get_world_state())
    print("📢 Репутация и карма:", gm.get_reputation())

    print("\n🧠 NPC:")
    for npc_data in gm.get_all_npc_data():
        print(npc_data)

    print("\n🎭 Интриги:")
    for intrigue in gm.get_all_intrigues():
        print("-", intrigue)

    print("\n🔍 Расследования:")
    report = gm.get_investigation_report()
    for k, v in report["прогресс"].items():
        print(f"[{v}%] В процессе: {k}")
    for r in report["раскрытые"]:
        print("✔", r)
